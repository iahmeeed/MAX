CONSTS = {
    SHELL_IDS_STATE_KEY = "kq_shellbuilder_shell_ids",
    SHELL_PREFIX_KEY = "kq_shellbuilder_shell_"
}