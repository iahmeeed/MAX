-- Dependency Check: Verify that the 'kq_link' resource is started.
local linkResourceState = GetResourceState("kq_link")

if linkResourceState ~= "started" then
    local errorMessage = string.format("^6[KQ_LINK MISSING] ^1kq_link is required but not running! Make sure that you've got it installed and started before %s", currentResourceName)
    error(errorMessage)
end