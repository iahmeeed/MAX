function table.contains(tbl, valueToFind)
    for _, value in ipairs(tbl) do
        if value == valueToFind then
            return true
        end
    end
    return false
end

function table.clone(originalTable)
    local memo = {}
    local function deepCopy(original)
        if type(original) ~= "table" then
            return original
        end
        if memo[original] then
            return memo[original]
        end

        local copy = {}
        memo[original] = copy

        for k, v in pairs(original) do
            copy[deepCopy(k)] = deepCopy(v)
        end

        return copy
    end
    return deepCopy(originalTable)
end

function table.length(tbl)
    local count = 0
    for _ in pairs(tbl) do
        count = count + 1
    end
    return count
end

function table.merge(destination, source)
    for key, value in pairs(source) do
        if type(value) == "table" then
            if type(destination[key]) == "table" then
                table.merge(destination[key], value)
            end
        else
            destination[key] = value
        end
    end
    return destination
end

Debug = function(...)
    if Config and Config.debug then
        print(...)
    end
end