local localeStrings = {}

--- Loads a JSON locale file from a resource and merges its contents into the main locale table.
--- @param resourceName string The name of the resource containing the locale file.
--- @param filePath string The path to the locale file within the resource.
local function loadLocale(resourceName, filePath)
    local fileContent = LoadResourceFile(resourceName, filePath)
    if not fileContent then
        print(string.format("Error: Could not load file '%s' from resource '%s'", filePath, resourceName))
        return
    end

    local success, data = pcall(json.decode, fileContent)
    if not success or not data then
        print(string.format("Error: Could not parse JSON from file '%s' in resource '%s'", filePath, resourceName))
        return
    end

    for key, value in pairs(data) do
        localeStrings[key] = value
    end
end

--- Retrieves a translated string using a key.
--- Supports nested keys (e.g., "ui.buttons.submit") and placeholder replacement.
--- @param key string The key for the desired string.
--- @param placeholders? table A table of key-value pairs for replacing placeholders (e.g., { name = "John" }).
--- @return string The translated and formatted string, or an error message if not found.
function L(key, placeholders)
    local keys = {}
    for part in string.gmatch(key, "[^%.]+") do
        table.insert(keys, part)
    end

    local current = localeStrings
    for _, part in ipairs(keys) do
        current = current[part]
        if not current then
            return "[MISSING_LOCALE] " .. key
        end
    end

    if type(current) == "string" and placeholders then
        return string.gsub(current, "{{%s*(%w+)%s*}}", function(placeholderKey)
            return placeholders[placeholderKey] or "{{" .. placeholderKey .. "}}"
        end)
    end

    return current
end

-- Load the locale file specified in the Config.
local resource = GetCurrentResourceName()
local localeFile = string.format("locales/%s.json", Config.locale or 'en')
loadLocale(resource, localeFile)