Settings = {}


Settings.timecycles = {
    ['none'] = {
        name = 'None',
        timecycle = nil,
    },
    ['warm'] = {
        name = 'Warm',
        timecycle = 'MP_lowgarage',
    },
    ['apartment'] = {
        name = 'Apartment #1',
        timecycle = 'franklinsAUNTS_new',
    },
    ['apartment2'] = {
        name = 'Apartment #2',
        timecycle = 'NewMichael',
    },
    ['garage'] = {
        name = 'Garage #1',
        timecycle = 'DLC_Casino_Garage',
    },
    ['garage2'] = {
        name = 'Garage #2',
        timecycle = 'garage',
    },
    ['vagos'] = {
        name = 'Vagos',
        timecycle = 'Vagos',
    },
    ['cops'] = {
        name = 'Cold',
        timecycle = 'cops',
    },
    ['bikers'] = {
        name = 'Bikers',
        timecycle = 'Bikers',
    },
    ['vignette'] = {
        name = 'Vignette',
        timecycle = 'Hint_cam',
    },
    ['strip'] = {
        name = 'Strip club',
        timecycle = 'V_strip_nofog',
    },
    ['bright'] = {
        name = 'Bright #1',
        timecycle = 'winning_room',
    },
    ['bright2'] = {
        name = 'Bright #2',
        timecycle = 'casino_brightroom',
    },
    ['mall'] = {
        name = 'Mall',
        timecycle = 'INT_mall',
    },
    ['desat'] = {
        name = 'Destaurated',
        timecycle = 'hud_def_desat_switch',
    },
    ['dark'] = {
        name = 'Dark',
        timecycle = 'phone_cam6',
    },
    ['superdark'] = {
        name = 'Super Dark',
        timecycle = 'MadrazoBackyard',
    },
}

Settings.walls = {
    ['0'] = {
        name = 'Brick wall',
        model = 1,
    },
    ['1'] = {
        name = 'Smooth wall',
        model = 2,
    },
    ['2'] = {
        name = 'Breeze wall',
        model = 3,
    },
    ['3'] = {
        name = 'Wooden wall #1',
        model = 4,
    },
    ['4'] = {
        name = 'Wooden wall #2',
        model = 7,
    },
    ['5'] = {
        name = 'Tiled wall',
        model = 5,
    },
    ['6'] = {
        name = 'Scuffed Tiled wall',
        model = 6,
    },
    ['7'] = {
        name = 'Concrete wall',
        model = 8,
    },
    ['8'] = {
        name = 'Leather wall',
        model = 9,
    },
    ['9'] = {
        name = 'Honeycomb Tiles wall',
        model = 10,
    },
    ['10'] = {
        name = 'Wallpaper wall #1',
        model = 11,
    },
    ['11'] = {
        name = 'Wallpaper wall #2',
        model = 12,
    },
    ['12'] = {
        name = 'Wallpaper wall #3',
        model = 13,
    },
    ['14'] = {
        name = 'Glass wall',
        model = 14,
    },
    ['15'] = {
        name = 'Wooden wall #3',
        model = 15,
    },
    ['16'] = {
        name = 'Metal wall',
        model = 16,
    },
}

Settings.floors = {
    ['none'] = {
        name = 'None',
        model = 1,
    },
    ['0'] = {
        name = 'Concrete floor #1',
        model = 1,
    },
    ['10'] = {
        name = 'Concrete floor #2',
        model = 11,
    },
    ['1'] = {
        name = 'Wooden floor #1',
        model = 2,
    },
    ['2'] = {
        name = 'Wooden floor #2',
        model = 3,
    },
    ['3'] = {
        name = 'Wooden floor #3',
        model = 4,
    },
    ['4'] = {
        name = 'Wooden floor #4',
        model = 5,
    },
    ['5'] = {
        name = 'Carpet floor #1',
        model = 6,
        offset = vec3(0, 0, 0.01)
    },
    ['14'] = {
        name = 'Carpet floor #2',
        model = 15,
        offset = vec3(0, 0, 0.01)
    },
    ['6'] = {
        name = 'Tiled floor #1',
        model = 7,
    },
    ['7'] = {
        name = 'Tiled floor #2',
        model = 8,
    },
    ['9'] = {
        name = 'Tiled floor #3',
        model = 10,
    },
    ['16'] = {
        name = 'Tiled floor #4',
        model = 17,
    },
    ['8'] = {
        name = 'Vinyl floor',
        model = 9,
    },
    ['11'] = {
        name = 'Concrete panels floor',
        model = 12,
    },
    ['12'] = {
        name = 'Honeycomb tiles floor',
        model = 13,
    },
    ['13'] = {
        name = 'Shiny smooth floor',
        model = 14,
    },
    ['15'] = {
        name = 'Metal floor',
        model = 16,
        offset = vec3(0, 0, 0.007)
    },
    ['17'] = {
        name = 'Automotive floor',
        model = 18,
        offset = vec3(0, 0, 0.007)
    },
    ['19'] = {
        name = 'Industrial floor',
        model = 19,
    },
    ['20'] = {
        name = 'Wooden floor #5',
        model = 20,
    },
    ['21'] = {
        name = 'Tiled floor #5',
        model = 21,
    },
    ['22'] = {
        name = 'Glass floor',
        model = 22,
    },
}

Settings.ceilings = {
    ['0'] = {
        name = 'Smooth ceiling',
        model = 'kq_sb_ceil',
    },
    ['1'] = {
        name = 'Panel ceiling #1',
        model = 'kq_sb_ceil_2',
    },
    ['1b'] = {
        name = 'Panel ceiling #1 (Broken A)',
        model = 'kq_sb_ceil_3',
    },
    ['1c'] = {
        name = 'Panel ceiling #1 (Broken B)',
        model = 'kq_sb_ceil_3',
        offset = {
            pos = vec3(0, 0, 0),
            rotation = vec3(0, 0, 90)
        }
    },
    ['2'] = {
        name = 'Wooden beams ceiling',
        model = 'kq_sb_ceil_4',
    },
    ['3'] = {
        name = 'Steel beams ceiling #1',
        model = 'kq_sb_ceil_5',
    },
    ['5'] = {
        name = 'Panel ceiling #2',
        model = 'kq_sb_ceil_6',
    },
    ['6'] = {
        name = 'Steel beams ceiling #2',
        model = 'kq_sb_ceil_7',
    },
    ['f1'] = {
        name = 'Concrete ceiling',
        model = 'kq_sb_tile_11',
        offset = {
            pos = vec3(0, 0, 2.997),
            rotation = vec3(180, 0, 0)
        }
    },
    ['f2'] = {
        name = 'Wooden ceiling',
        model = 'kq_sb_tile_4',
        offset = {
            pos = vec3(0, 0, 2.997),
            rotation = vec3(180, 0, 0)
        }
    },
    ['f3'] = {
        name = 'Concrete panel ceiling',
        model = 'kq_sb_tile_12',
        offset = {
            pos = vec3(0, 0, 2.997),
            rotation = vec3(180, 0, 0)
        }
    },
    ['f4'] = {
        name = 'Glass ceiling',
        model = 'kq_sb_tile_22',
        offset = {
            pos = vec3(0, 0, 2.997),
            rotation = vec3(180, 0, 0)
        }
    },
}

Settings.doorframes = {
    ['0'] = {
        name = 'Wooden Doorframe',
        model = 1,
        icon = 'wall_2',
    },
}

Settings.stairs = {
    ['0'] = {
        name = 'Wooden stairs #1',
        model = 'kq_sb_stairs_1',
    },
    ['1'] = {
        name = 'Wooden stairs #2',
        model = 'kq_sb_stairs_2',
    },
    ['2'] = {
        name = 'Wooden stairs #3',
        model = 'kq_sb_stairs_3',
    },
}


Settings.windows = {
    ['0'] = {
        name = 'Window #1',
        model = 'kq_sb_window_1',
        icon = 'kq_sb_window_1',
    },
    ['0b'] = {
        name = 'Window #1 (See-through)',
        model = 'kq_sb_window_1b',
        icon = 'kq_sb_window_1',
    },
    ['1'] = {
        name = 'Window #2',
        model = 'kq_sb_window_2',
        icon = 'kq_sb_window_2',
    },
    ['1b'] = {
        name = 'Window #2 (See-through)',
        model = 'kq_sb_window_2b',
        icon = 'kq_sb_window_2',
    },
    ['2'] = {
        name = 'Window #3',
        model = 'kq_sb_window_3',
        icon = 'kq_sb_window_3',
    },
    ['2b'] = {
        name = 'Window #3 (See-through)',
        model = 'kq_sb_window_3b',
        icon = 'kq_sb_window_3',
    },
    ['3'] = {
        name = 'Window #4',
        model = 'kq_sb_window_4',
        icon = 'kq_sb_window_4',
    },
    ['3b'] = {
        name = 'Window #4 (See-through)',
        model = 'kq_sb_window_4b',
        icon = 'kq_sb_window_4',
    },
    ['4'] = {
        name = 'Window #5',
        model = 'kq_sb_window_5',
        icon = 'kq_sb_window_5',
    },
    ['4b'] = {
        name = 'Window #5 (See-through)',
        model = 'kq_sb_window_5b',
        icon = 'kq_sb_window_5',
    },
}


Settings.exporters = {
    ['vec3'] = {
        name = '- Coords (vector3)',
        data = 'vec3({full_x}, {full_y}, {full_z})',
    },
    ['vec4'] = {
        name = '- Coords (vector4)',
        data = 'vec4({full_x}, {full_y}, {full_z}, {heading})',
    },
    ['table'] = {
        name = '- Coords (table)',
        data = '{x = {full_x}, y = {full_y}, z = {full_z}, heading = {heading}}',
    },
    ['esx_property_ipl'] = {
        name = 'esx_property (IPL)',
        data = [[
{
  label = "{name}",
  value = "kq_sbx_shell_{id}",
  positions = {
    Wardrobe = vec3({full_x}, {full_y}, {full_z}), -- Change these manually
    Storage = vec3({full_x}, {full_y}, {full_z}), -- Change these manually
  },
  type = "ipl",
  pos = vector3({full_x}, {full_y}, {full_z})
},
    ]],
    },
    ['esx_property_shell'] = {
        name = 'esx_property (Shell)',
        flipped = true,
        data = [[
{
  label = "{name}",
  value = "kq_sbx_shell_{id}",
  positions = {
    Wardrobe = vec3({x}, {y}, {z}), -- Change these manually
    Storage = vec3({x}, {y}, {z}), -- Change these manually
  },
  type = "shell",
  pos = vector3({x}, {y}, {z})
},
    ]],
    },
    ['ps_housing'] = {
        name = 'ps-housing (Shell)',
        data = [[
["{name}"] = {
    label = "{name}",
    hash = `kq_sbx_shell_{id}`,
    doorOffset = { x = {x}, y = {y}, z = {z}, h = {heading}, width = 1.5 },
    stash = {
        maxweight = 100000,
        slots = 12,
    },
    imgs = {},
},
    ]],
    },
    ['qs_housing_ipl'] = {
        name = 'qs-housing 4.0 (IPL)',
        data = [[
	{
		-- {name}
		exitCoords = vec3({full_x}, {full_y}, {full_z}),
		iplCoords = vec3({full_x}, {full_y}, {full_z}),
		stash = {
			maxweight = 1000000,
			slots = 10,
		},
	},
    ]],
    },
    ['qs_housing_shell'] = {
        name = 'qs-housing 4.0 (Shell)',
        data = [[
["{id}"] = { -- Replace with correct index
    model = `kq_sbx_shell_{id}`,
    stash = {
        maxweight = 100000,
        slots = 12,
    },
    imgs = {}
},
    ]],
    },
    ['rx_housing'] = {
        name = 'RxHousing (Shell)',
        data = [[
["kq_sbx_shell_{id}"] = {
    offsets = {
        door = vector3({x}, {y}, {z}),
        doorHeading = {heading},
        laptop = vector3({x}, {y}, {z}), -- You must change this
        laptopHeading = {heading}, -- You must change this
        stash = vector3({x}, {y}, {z}), -- You must change this
        clothing = vector3({x}, {y}, {z}), -- You must change this
    },
},
    ]],
    },
    ['origen_housing_ipl'] = {
        name = 'origen_housing (IPL)',
        data = [[
{
    model = '{name}',
    cam = vector4({full_x}, {full_y}, {full_z}, {heading}),
    enter = vector4({full_x}, {full_y}, {full_z}, {heading}),
    label = '{name}',
},
    ]],
    },
    ['origen_housing_shell'] = {
        name = 'origen_housing (Shell)',
        data = [[
{
    model = 'kq_sbx_shell_{id}',
    label = '{name}',
    offset = vector3({x}, {y}, {z})
},
    ]],
    },
    ['nolag_properties'] = {
        name = 'nolag_properties (Shell)',
        data = [[
["{name}"] = {
    label = "{name}",
    hash = `kq_sbx_shell_{id}`,
    doorOffset = { x = {x}, y = {y}, z = {z}, h = {heading}, width = 2.0 },
    stash = {
        maxweight = 80000000,
        slots = 120,
    },
    imgs = {}
},
    ]],
    },
    ['loaf_housing_shell'] = {
        name = 'loaf-housing (Shell)',
        data = [[
["{name}"] = {
    object = `kq_sbx_shell_{id}`,
    category = "highend_house", -- Change to fit
    doorOffset = vector3({z}, {y}, {z}),
    doorHeading = {heading},
},
    ]],
    },
    ['loaf_housing_ipl'] = {
        name = 'loaf-housing (IPL)',
        data = [[
["{name}"] = {
    label = "{name}",
    coords = vector3({full_x}, {full_y}, {full_z}),
    ipl = "kq_sbx_shell_{id}",
    disableFurnishing = false,
    lockpick = 1,
    locations = {
        -- Set the storage locations to fit
        ["location_1"] = {
            coords = vector3({full_x}, {full_y}, {full_z}),
            scale = vector3(2.0, 2.0, 0.5),
            storage = true,
            wardrobe = false,
            weight = 50000,
        },
    },
},
    ]],
    },
    ['bcs_housing_ipl'] = {
        name = 'bcs-housing (IPL)',
        data = [[
{
    label = "{name}",
    name = "kq_sbx_shell_{id}",
    entry = vec4({full_x}, {full_y}, {full_z}, {heading}),
},
    ]],
    },
    ['bcs_housing_shell'] = {
        name = 'bcs-housing (Shell)',
        data = [[
["kq_sbx_shell_{id}"] = vec4({x}, {y}, {z}, {heading}),
    ]],
    },
    ['ak47_shell'] = {
        name = 'ak47_housing (Shell)',
        data = [[
["kq_sbx_shell_{id}"] = {
    name = "{name}",
    price = {minimum = 1000, maximum = 5000}, -- Change these,
    weight = {minimum = 100, maximum = 5000}, -- Change these,
},
    ]],
    },
    ['vms_housing_shell'] = {
        name = 'vms_housing (Shell)',
        data = [[
['kq_sbx_shell_{id}'] = {
    label = '{name}',

    tags = {'empty', 'kuzquality'},
    rooms = 1, -- Change this

    model = 'kq_sbx_shell_{id}',

    doors = {
        x = {x},
        y = {y},
        z = {z},
        heading = {heading},
    },

    images = {},
},
    ]],
    },
    ['kq_weed_growop'] = {
        name = 'kq_weed (Grow Op)',
        data = [[
    ['kq_sbx_shell_{id}'] = {
        interior = {
            model = 'kq_sbx_shell_{id}',
            offset = vec3({x}, {y}, {z}),
            rotation = vec3(0, 0, {heading})
        },

        shellZOffset = 1400.0,

        locations = {
            {
                coords = vec3(2515.96, 4220.33, 38.93), -- CHANGE ME
                rotation = vec3(0, 0, 57), -- CHANGE ME
                color = 0,
            },
            -- ADD MORE LOCATIONS HERE AS NEEDED
        },

       -- use `/kq_weed:tableOffset` while inside the grow op to easily retrieve the offset coordinates
        tables = {
            {
                coords = vec3(0, 7, -5.25), -- CHANGE ME
                rotation = vec3(0, 0, 0),
            },
            -- ADD MORE TABLES HERE AS NEEDED
        },
       -- use `/kq_weed:pressOffset` while inside the grow op to easily retrieve the offset coordinates
        presses = {
            {
                coords = vec3(0, 9, -5.25), -- CHANGE ME
                rotation = vec3(0, 0, 0),
            },
            -- ADD MORE PRESSES HERE AS NEEDED
        },
        -- use `/kq_weed:potOffset` while inside the grow op to easily retrieve the offset coordinates
        pots = {
            { optimal = true, showTent = false, autoWatering = true, coords = vec3(0, 5, -5.25), rotation = vec3(0, 0, 0) }, -- CHANGE ME
            -- ADD MORE POTS HERE AS NEEDED
        },
    },
        ]]
    },
}

Settings.decor = {
    ['lamp_1'] = {
        name = 'Spotlight',
        model = 'kq_sb_light_1',
        tag = 'Lights',
        colorPicker = true,
    },
    ['lamp_2'] = { -- x
        name = 'Industrial light',
        model = 'xs_prop_x18_hangar_light_c',
        offset = {
            pos = vec3(0, 0, 2.98),
        },
        tag = 'Lights',
        colorPicker = true,
    },
    ['lamp_3'] = { -- x
        name = 'Pendant light',
        model = 'xs_prop_x18_hangar_light_b',
        offset = {
            pos = vec3(0, 0, 2.98),
        },
        tag = 'Lights',
        colorPicker = true,
    },
    ['lamp_4'] = { -- x
        name = 'Halogen light',
        model = 'h4_prop_x17_sub_lampa_small_blue',
        offset = {
            pos = vec3(0, 0, 2.98),
        },
        tag = 'Lights',
        colorPicker = true,
    },
    ['lamp_5'] = {
        name = 'Tube lights',
        model = 'kq_sb_light_2',
        tag = 'Lights',
        colorPicker = true,
    },
    ['lamp_6'] = {
        name = 'Light panel',
        model = 'kq_sb_light_3',
        tag = 'Lights',
        colorPicker = true,
        offset = {
            pos = vec3(0, 0, -0.02),
        },
    },

    ['wall_trim'] = {
        name = 'Wall trim',
        model = 'kq_sb_trim',
        tag = 'Wall extras',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
        colorPicker = true,
    },
    ['wall_trimt'] = {
        name = 'Wall trim upper',
        model = 'kq_sb_trim',
        tag = 'Wall extras',
        offset = {
            pos = vec3(0, 0, 2.91),
            heading = 270,
        },
        colorPicker = true,
    },
    ['wall_trim_d'] = {
        name = 'Wall trim (door)',
        model = 'kq_sb_trim_door',
        tag = 'Wall extras',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
        colorPicker = true,
    },
    ['wall_panel_1'] = {
        name = 'Wall siding - Breeze',
        model = 'kq_sb_quartwall_3',
        tag = 'Wall extras',
        offset = {
            pos = vec3(0, -0.01, 0.02),
            heading = 270,
        },
        colorPicker = true,
    },
    ['wall_panel_2'] = {
        name = 'Wall siding - Wood',
        model = 'kq_sb_quartwall_4',
        tag = 'Wall extras',
        offset = {
            pos = vec3(0, -0.015, 0.02),
            heading = 270,
        },
        colorPicker = true,
    },
    ['shower'] = {
        name = 'Shower',
        model = 'kq_sb_shower',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 90,
        },
    },
    ['bar_1'] = {
        name = 'Bar counter',
        model = 'kq_sb_bar_tile_1',
        tag = 'Counters',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 90,
        },
        colorPicker = true,
    },
    ['bar_1_edge'] = {
        name = 'Bar counter corner',
        model = 'kq_sb_bar_edge_1',
        tag = 'Counters',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 90,
        },
        colorPicker = true,
    },
    ['kitch_1'] = {
        name = 'Kitchen counter',
        model = 'kq_sb_kitchen_counter',
        tag = 'Counters',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
        colorPicker = true,
    },
    ['kitch_cook_1'] = {
        name = 'Kitchen cooker',
        model = 'kq_sb_kitchen_cooker',
        tag = 'Counters',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
        colorPicker = true,
    },
    ['kitch_corner_1'] = {
        name = 'Kitchen corner',
        model = 'kq_sb_kitchen_corner',
        tag = 'Counters',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
        colorPicker = true,
    },
    ['kitch_fridge_1'] = {
        name = 'Kitchen fridge',
        model = 'kq_sb_kitchen_fridge',
        tag = 'Counters',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
        colorPicker = true,
    },
    ['kitch_sink_1'] = {
        name = 'Kitchen sink',
        model = 'kq_sb_kitchen_sink',
        tag = 'Counters',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
        colorPicker = true,
    },
    ['shelf_1'] = { -- x
        name = 'Store shelves #1',
        model = 'v_ind_cf_shelf',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.54, 0),
            heading = 0,
        },
    },
    ['shelf_2'] = {
        name = 'Store shelves #2',
        model = 'v_ret_fh_shelf_04',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.54, 0),
            heading = 0,
        },
    },
    ['shelf_3'] = { -- x
        name = 'Store shelves #3',
        model = 'v_ret_ml_shelfrk',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.69, 1),
            heading = 0,
        },
    },
    ['shelf_4'] = { -- x
        name = 'Store shelves #4',
        model = 'v_ret_ml_liqshelfe',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.69, 1),
            heading = 0,
        },
    },
    ['shelf_5'] = { -- x
        name = 'Store shelves #5',
        model = 'apa_mp_h_str_shelffreel_01',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['shelf_6'] = { -- x
        name = 'Store shelves #6',
        model = 'v_corp_offshelfclo',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['shelf_7'] = { -- x
        name = 'Store shelves #7',
        model = 'v_corp_offshelf',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['shelf_8'] = {
        name = 'Store shelves #8',
        model = 'v_ret_ml_liqshelfa',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.72, 1),
            heading = 0,
        },
    },
    ['shelf_9'] = {
        name = 'Store shelves #9',
        model = 'v_ret_ml_liqshelfc',
        tag = 'Shelves',
        offset = {
            pos = vec3(0, 0.72, 1),
            heading = 0,
        },
    },
    ['desk_1'] = {
        name = 'Desk #1', -- x
        model = 'tr_prop_tr_officedesk_01a',
        tag = 'Office',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['desk_2'] = {
        name = 'Desk #2',
        model = 'xm_prop_base_staff_desk_01',
        tag = 'Office',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['desk_3'] = { -- x
        name = 'Desk #3',
        model = 'v_corp_officedesk2',
        tag = 'Office',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['desk_4'] = { -- x
        name = 'Desk #4',
        model = 'v_corp_deskseta',
        tag = 'Office',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['server_rack'] = { -- x
        name = 'Server rack',
        model = 'm23_1_prop_m31_server_01a',
        tag = 'Office',
        offset = {
            pos = vec3(0, 0.72, 0),
            heading = 0,
        },
    },
    ['rack_1'] = {
        name = 'Storage Rack #1',
        model = 'imp_prop_impexp_rack_01a',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, -0.3, 0),
            heading = 270,
        },
    },
    ['rack_2'] = {
        name = 'Storage Rack #2',
        model = 'imp_prop_impexp_parts_rack_05a',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, -0.2, 0),
            heading = 270,
        },
    },
    ['rack_3'] = {
        name = 'Storage Rack #3',
        model = 'imp_prop_impexp_parts_rack_01a',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, -0.2, 0),
            heading = 270,
        },
    },
    ['rack_4'] = {
        name = 'Storage Rack #4',
        model = 'imp_prop_impexp_parts_rack_02a',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, -0.3, 0),
            heading = 270,
        },
    },
    ['car_rack'] = {
        name = 'Car Lift Rack',
        model = 'imp_prop_impexp_carrack',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, -0.3, 0),
            heading = 0,
        },
    },
    ['t_rack'] = { -- x
        name = 'Tire Rack',
        model = 'v_ret_csr_tyresale',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.44, 1.1),
            heading = 0,
        },
    },
    ['w_drawers'] = { -- x
        name = 'Workshop drawers #1',
        model = 'xs_prop_x18_tool_draw_01e',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.5, 0),
            heading = 0,
        },
    },
    ['w_drawers2'] = {
        name = 'Workshop drawers #2',
        model = 'prop_toolchest_05',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.5, 0),
            heading = 0,
        },
    },
    ['workbench_1'] = { -- x
        name = 'Workbench #1',
        model = 'xm3_prop_xm3_bench_04b',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.5, 0),
            heading = 0,
        },
    },
    ['workbench_2'] = { -- x
        name = 'Workbench #2',
        model = 'xm3_prop_xm3_bench_03b',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.5, 0),
            heading = 0,
        },
    },
    ['garage_door_1'] = {
        name = 'Garage door #1',
        model = 'v_ilev_spraydoor',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.92, 1.26),
            heading = 0,
        },
    },
    ['garage_door_2'] = {
        name = 'Garage door #2',
        model = 'prop_sc1_21_g_door_01',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.94, 1.22),
            heading = 0,
        },
    },
    ['garage_door_3'] = {
        name = 'Garage door #3',
        model = 'prop_cs4_10_tr_gd_01',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.94, 1.15),
            heading = 0,
        }
    },
    ['garage_door_4'] = {
        name = 'Garage door #4',
        model = 'v_ilev_finale_shut01',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.92, 1.18),
            heading = 0,
        }
    },
    ['garage_door_5'] = {
        name = 'Garage door #5',
        model = 'prop_ch2_07b_20_g_door',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.945, 1.315),
            heading = 0,
        }
    },
    ['garage_door_6'] = {
        name = 'Garage door #6',
        model = 'v_ilev_carmod3door',
        tag = 'Workshop',
        offset = {
            pos = vec3(0, 0.945, 1.89),
            heading = 0,
        }
    },
    ['pot_rack'] = {
        name = 'Hanging pots',
        model = 'prop_pot_rack',
        tag = 'Ceiling decor',
        offset = {
            pos = vec3(0, 0.5, 2.48),
            heading = 90,
        }
    },
    --['bugzap'] = { -- Not reliable
    --    name = 'Bug zapper',
    --    model = 'v_ind_cf_bugzap',
    --    tag = 'Wall decor',
    --    offset = {
    --        pos = vec3(0, 0.852, 2.35),
    --        heading = 0,
    --    },
    --    colorPicker = true,
    --},
    --['socket'] = { -- Not reliable
    --    name = 'Wall plug',
    --    model = 'v_res_tre_plugsocket',
    --    tag = 'Wall decor',
    --    offset = {
    --        pos = vec3(0, 0.93, 0.25),
    --        heading = 0,
    --    }
    --},
    ['wvent'] = {
        name = 'Wall vent low',
        model = 'prop_wall_vent_03',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.93, 0.33),
            heading = 0,
        }
    },
    ['wvent_H'] = {
        name = 'Wall vent high',
        model = 'prop_wall_vent_03',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.93, 2.64),
            heading = 0,
        }
    },
    ['elevator_door'] = { -- x
        name = 'Elevator Door',
        model = 'm23_2_prop_m32_door_elev_01a',
        tag = 'Wall extras',
        offset = {
            pos = vec3(0, 0.8, 0),
            heading = 0,
        }
    },
    ['fusebox'] = { -- x
        name = 'Fusebox',
        model = 'ch_prop_ch_fuse_box_01a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.87, 1.65),
            heading = 0,
        }
    },
    ['elecbox'] = { -- x
        name = 'Electric box',
        model = 'm23_1_prop_m31_electricbox_01a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.81, 0.32),
            heading = 0,
        }
    },
    ['dartboard'] = {
        name = 'Dartboard',
        model = 'prop_dart_bd_cab_01',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.94, 1.65),
            heading = 0,
        }
    },
    --['radiator'] = { -- Not reliable
    --    name = 'Wall radiator',
    --    model = 'v_ret_fh_radiator',
    --    tag = 'Wall decor',
    --    offset = {
    --        pos = vec3(0, 0.775, 0.44),
    --        heading = 0,
    --    }
    --},
    ['coat_hook'] = {
        name = 'Coat hanger #1',
        model = 'prop_coathook_01',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.87, 1.4),
            heading = 0,
        }
    },
    ['whips_hang'] = { -- x
        name = 'Whips',
        model = 'v_res_d_whips',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.88, 1.4),
            heading = 0,
        }
    },
    ['neon_blarneys'] = {
        name = 'Neon Blarneys',
        model = 'v_ret_neon_blarneys',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.91, 2.1),
            heading = 0,
        },
        colorPicker = true,
    },
    ['neon_logg'] = {
        name = 'Neon Logger',
        model = 'prop_loggneon',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.935, 1.9),
            heading = 0,
        },
        colorPicker = true,
    },
    ['neon_rag'] = {
        name = 'Neon Palm Beer',
        model = 'prop_ragganeon',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.93, 1.9),
            heading = 0,
        },
        colorPicker = true,
    },
    ['dimmer'] = { -- x
        name = 'Wall Dimmer',
        model = 'h4_prop_club_dimmer',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.93, 1.4),
            heading = 0,
        },
    },
    ['control_panel'] = { -- x
        name = 'Control Panel',
        model = 'm23_1_prop_m31_control_panel_01a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.93, 1.4),
            heading = 0,
        },
    },
    ['tp_roll'] = { -- x
        name = 'Toilet paper roll #1',
        model = 'v_res_m_wctoiletroll',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.93, 0.9),
            heading = 0,
        },
    },
    ['tp_roll_2'] = {
        name = 'Toilet paper roll #2',
        model = 'prop_toilet_roll_02',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.93, 0.9),
            heading = 0,
        },
    },
    ['toilet_1'] = {
        name = 'Toilet #1',
        model = 'prop_toilet_01',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.62, 0),
            heading = 0,
        },
    },
    ['toilet_2'] = {
        name = 'Toilet #2',
        model = 'prop_toilet_02',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.62, 0),
            heading = 0,
        },
    },
    ['toilet_3'] = {
        name = 'Toilet Nasty',
        model = 'prop_ld_toilet_01',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.58, 0.33),
            heading = 0,
        },
    },
    ['towel_rail'] = {
        name = 'Towel rail',
        model = 'prop_towel_rail_02',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.93, 0.9),
            heading = 0,
        },
    },
    ['sink_1'] = {
        name = 'Sink #1',
        model = 'prop_sink_05',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.93, 0.9),
            heading = 0,
        },
    },
    ['sink_2'] = {
        name = 'Sink #2',
        model = 'v_res_mbsink',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.73, 0.9),
            heading = 0,
        },
    },
    ['sink_3'] = { -- x
        name = 'Sink #3',
        model = 'v_ind_sinkhand',
        tag = 'Bathroom',
        offset = {
            pos = vec3(0, 0.63, 0),
            heading = 0,
        },
    },
    ['whiteboard'] = { -- x
        name = 'Whiteboard',
        model = 'ch_prop_whiteboard',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.45),
            heading = 0,
        },
    },
    ['chalkboard'] = {
        name = 'Chalkboard',
        model = 'prop_b_board_blank',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.45),
            heading = 0,
        },
    },
    ['cig_disp'] = {
        name = 'Cigarette dispenser',
        model = 'prop_vend_fags_01',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.8, 1.45),
            heading = 0,
        },
    },
    ['parking_sign'] = { -- x
        name = 'Parking sign',
        model = 'reh_prop_reh_plague_sf_01a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1),
            heading = 0,
        },
    },
    ['floor_hatch'] = { -- x
        name = 'Floor hatch',
        model = 'm23_2_prop_m32_hatch_01a',
        tag = 'Floor decor',
    },
    ['rug_1'] = {
        name = 'Rug #1',
        model = 'apa_mp_h_acc_rugwools_01',
        tag = 'Floor decor',
    },
    ['rug_2'] = {
        name = 'Rug #2',
        model = 'apa_mp_h_acc_rugwools_03',
        tag = 'Floor decor',
    },
    ['rug_3'] = {
        name = 'Rug #3',
        model = 'ex_mp_h_acc_rugwoolm_04',
        tag = 'Floor decor',
    },
    ['cctv'] = {
        name = 'CCTV Camera',
        model = 'prop_cctv_cam_06a',
        tag = 'Ceiling decor',
        offset = {
            pos = vec3(0, 0.65, 2.92),
            heading = 0,
        },
    },
    ['painting_1'] = { -- x
        name = 'Painting #1',
        model = 'ch_prop_vault_painting_01e',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.2),
            heading = 0,
        },
    },
    ['painting_2'] = { -- x
        name = 'Painting #2',
        model = 'ch_prop_vault_painting_01j',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.2),
            heading = 0,
        },
    },
    ['painting_3'] = { -- x
        name = 'Painting #3',
        model = 'ch_prop_vault_painting_01f',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.2),
            heading = 0,
        },
    },
    ['painting_4'] = { -- x
        name = 'Painting #4',
        model = 'ch_prop_vault_painting_01h',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.2),
            heading = 0,
        },
    },
    ['painting_5'] = { -- x
        name = 'Painting #5',
        model = 'ch_prop_vault_painting_01g',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.2),
            heading = 0,
        },
    },
    ['painting_6'] = { -- x
        name = 'Painting #6',
        model = 'ch_prop_vault_painting_01d',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.2),
            heading = 0,
        },
    },
    ['painting_7'] = {
        name = 'Painting #7',
        model = 'v_res_picture_frame',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_1'] = { -- x
        name = 'Wall Art #1',
        model = 'vw_prop_vw_wallart_57a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_2'] = { -- x
        name = 'Wall Art #2',
        model = 'vw_prop_vw_wallart_141a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_3'] = { -- x
        name = 'Wall Art #3',
        model = 'vw_prop_vw_wallart_156a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_4'] = { -- x
        name = 'Wall Art #4',
        model = 'vw_prop_vw_wallart_111a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_5'] = { -- x
        name = 'Wall Art #5',
        model = 'vw_prop_vw_wallart_20a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_6'] = { -- x
        name = 'Wall Art #6',
        model = 'vw_prop_vw_wallart_129a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_7'] = {
        name = 'Wall Art #7',
        model = 'v_med_p_wallhead',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 2),
            heading = 0,
        },
    },
    ['wart_8'] = { -- x
        name = 'Wall Art #8',
        model = 'vw_prop_vw_wallart_137a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['wart_9'] = { -- x
        name = 'Wall Art #9',
        model = 'vw_prop_vw_wallart_131a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.7),
            heading = 0,
        },
    },
    ['pic_1'] = { -- x
        name = 'Picture #1',
        model = 'v_med_wallpicture2',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.89, 1.6),
            heading = 0,
        },
    },
    ['pic_2'] = { -- x
        name = 'Picture #2',
        model = 'vw_prop_vw_wallart_134a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['pic_3'] = { -- x
        name = 'Picture #3',
        model = 'vw_prop_vw_wallart_132a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['pic_4'] = {
        name = 'Picture #4',
        model = 'prop_cs_photoframe_01',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['post_1'] = { -- x
        name = 'Poster #1',
        model = 'm23_2_prop_m32_poster_01a',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['post_2'] = {
        name = 'Poster #2',
        model = 'hei_prop_dlc_heist_map',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0.91, 1.65),
            heading = 180,
        },
    },
    ['spill_1'] = {
        name = 'Spill 1',
        model = 'kq_dirt_spill_1',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_2'] = {
        name = 'Spill 2',
        model = 'kq_dirt_spill_2',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_3'] = {
        name = 'Spill 3',
        model = 'kq_dirt_spill_3',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_4'] = {
        name = 'Spill 4',
        model = 'kq_dirt_spill_4',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_5'] = {
        name = 'Spill 5',
        model = 'kq_dirt_spill_5',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_6'] = {
        name = 'Spill 6',
        model = 'kq_dirt_spill_6',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_7'] = {
        name = 'Spill 7',
        model = 'kq_dirt_spill_7',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_8'] = {
        name = 'Spill 8',
        model = 'kq_dirt_spill_8',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['spill_9'] = {
        name = 'Spill 9',
        model = 'kq_dirt_spill_9',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['dedge_1'] = {
        name = 'Wall dirt edge #1',
        model = 'kq_sb_dirt_edge_1',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
    },
    ['dedge_2'] = {
        name = 'Wall dirt edge #2',
        model = 'kq_sb_dirt_edge_2',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
    },
    ['dedge_3'] = {
        name = 'Wall dirt edge #3',
        model = 'kq_sb_dirt_edge_3',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0, -0.04),
            heading = 270,
        },
    },
    ['wspill_1'] = {
        name = 'Wall Spill 1',
        model = 'kq_dirt_spill_1',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 0.7),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_2'] = {
        name = 'Wall Spill 2',
        model = 'kq_dirt_spill_2',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 2.1),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_3'] = {
        name = 'Wall Spill 3',
        model = 'kq_dirt_spill_3',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 1.1),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_4'] = {
        name = 'Wall Spill 4',
        model = 'kq_dirt_spill_4',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 2.2),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_5'] = {
        name = 'Wall Spill 5',
        model = 'kq_dirt_spill_5',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 1.7),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_6'] = {
        name = 'Wall Spill 6',
        model = 'kq_dirt_spill_6',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 1.5),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_7'] = {
        name = 'Wall Spill 7',
        model = 'kq_dirt_spill_7',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 1.2),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_8'] = {
        name = 'Wall Spill 8',
        model = 'kq_dirt_spill_8',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 0.5),
            rot = vec3(90, 0, 0),
        },
    },
    ['wspill_9'] = {
        name = 'Wall Spill 9',
        model = 'kq_dirt_spill_9',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.93, 1),
            rot = vec3(90, 0, 0),
        },
    },
    ['litter_1'] = {
        name = 'Litter 1',
        model = 'prop_rub_litter_04b',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['litter_2'] = {
        name = 'Litter 2',
        model = 'prop_rub_litter_07',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['litter_3'] = {
        name = 'Litter 3',
        model = 'prop_rub_litter_02',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['litter_4'] = {
        name = 'Litter 4',
        model = 'prop_rub_litter_03b',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['litter_5'] = {
        name = 'Litter 5',
        model = 'prop_rub_litter_01',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['litter_6'] = {
        name = 'Litter 6',
        model = 'v_res_tt_litter3',
        tag = 'Clutter',
        offset = {
            pos = vec3(0.3, 0, 0.02),
            heading = 0,
        },
    },
    ['litter_7'] = {
        name = 'Litter 7',
        model = 'proc_litter_02',
        tag = 'Clutter',
        randomizeOffset = true,
    },
    ['wdecal_1'] = { -- x
        name = 'Wall clutter #1',
        model = 'xm3_prop_xm3_board_decal_01a',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.91, 1.35),
            heading = 0,
        },
    },
    ['wdecal_2'] = { -- x
        name = 'Wall clutter #2',
        model = 'ba_prop_club_dressing_posters_01',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['wdecal_3'] = { -- x
        name = 'Wall clutter #3',
        model = 'ba_prop_club_dressing_posters_02',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['wdecal_4'] = { -- x
        name = 'Wall clutter #4',
        model = 'ba_prop_club_dressing_poster_01',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['wdecal_5'] = { -- x
        name = 'Wall clutter #5',
        model = 'ba_prop_club_dressing_poster_02',
        tag = 'Clutter',
        offset = {
            pos = vec3(0, 0.92, 1.6),
            heading = 0,
        },
    },
    ['banner_1'] = {
        name = 'Wall banner #1',
        model = 'kq_sb_banner_1',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, -0.5),
            heading = 270,
        },
    },
    ['banner_2'] = {
        name = 'Wall banner #2',
        model = 'kq_sb_banner_2',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, -0.5),
            heading = 270,
        },
    },
    ['banner_3'] = {
        name = 'Wall banner #3',
        model = 'kq_sb_banner_3',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, -0.5),
            heading = 270,
        },
    },
    ['banner_4'] = {
        name = 'Wall banner #4',
        model = 'kq_sb_banner_4',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, -0.5),
            heading = 270,
        },
    },
    ['graff_1'] = {
        name = 'Graffiti #1',
        model = 'kq_sb_graffiti_1',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
    },
    ['graff_2'] = {
        name = 'Graffiti #2',
        model = 'kq_sb_graffiti_2',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
    },
    ['graff_3'] = {
        name = 'Graffiti #3',
        model = 'kq_sb_graffiti_3',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
    },
    ['graff_4'] = {
        name = 'Graffiti #4',
        model = 'kq_sb_graffiti_4',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
    },
    ['graff_5'] = {
        name = 'Graffiti #5',
        model = 'kq_sb_graffiti_5',
        tag = 'Wall decor',
        offset = {
            pos = vec3(0, 0, 0),
            heading = 270,
        },
    },
}

Settings.doors = {
    ['0'] = {
        name = 'Apartment door #1',
        model = 'v_ilev_j2_door',
    },
    ['1'] = {
        name = 'Apartment door #2',
        model = 'v_ilev_ra_door2',
    },
    ['2'] = {
        name = 'Apartment door #3',
        model = 'v_ilev_housedoor1',
        flipped = true,
    },
    ['3'] = {
        name = 'Apartment door #4',
        model = 'ex_p_mp_door_office_door01',
        flipped = true,
    },
    ['4'] = {
        name = 'Apartment door #5',
        model = 'sum_p_mp_yacht_door_01',
        flipped = true,
    },
    ['5'] = {
        name = 'Apartment door #6',
        model = 'ex_p_mp_door_apart_door_black',
        flipped = true,
    },
    ['6'] = {
        name = 'White door #1',
        model = 'v_ilev_janitor_frontdoor',
    },
    ['7'] = {
        name = 'Hi-sec Door',
        model = 'v_ilev_gtdoor02',
    },
    ['8'] = {
        name = 'Glass door #1',
        model = 'v_ilev_ph_gendoor002',
        flipped = true,
    },
    ['9'] = {
        name = 'Glass door #2',
        model = 'xm_prop_facility_door_01',
    },
    ['10'] = {
        name = 'Padded Door',
        model = 'ba_prop_door_club_edgy_generic',
    },
    ['11'] = {
        name = 'Bathroom Door',
        model = 'ba_prop_door_club_trad_wc',
    },
    ['12'] = {
        name = 'Bathroom Door #2',
        model = 'h4_prop_door_club_glam_wc',
    },
    ['13'] = {
        name = 'Scuffed Door #1',
        model = 'v_ilev_ss_door02',
        flipped = true,
    },
    ['14'] = {
        name = 'Scuffed Door #2',
        model = 'v_ilev_vagostoiletdoor',
    },
    ['15'] = {
        name = 'Scuffed Door #3',
        model = 'v_ilev_trev_doorfront',
        flipped = true,
    },
    ['16'] = {
        name = 'Staff Door',
        model = 'vw_prop_vw_casino_door_01c',
    },
    ['17'] = {
        name = 'Private Door',
        model = 'v_ilev_mldoor02',
        flipped = true,
    },

    ['18'] = {
        name = 'Workshop Door',
        model = 'xs_prop_x18_garagedoor02',
    },
    ['19'] = {
        name = 'Black Door',
        model = 'tr_prop_tr_door3',
        flipped = true,
    },
    ['20'] = {
        name = 'Generic Door',
        model = 'ba_prop_door_club_trad_generic',
    },
    ['21'] = {
        name = 'Scuffed Door #4',
        model = 'prop_ret_door_02',
        flipped = true,
    },
}
