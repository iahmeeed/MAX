CUSTOMS_LOADED = false
local _INITIALIZING = false

if Config.disableCustomTextures then
    CUSTOMS_LOADED = true
    return
end

-- Configuration and state variables
local ORIGINAL_TXD_NAME = "kq_shellbuilder_custom"
local RUNTIME_TXD_NAME = "kq_shellbuilder_custom_runtime"
local runtimeTxd = CreateRuntimeTxd(RUNTIME_TXD_NAME)
local MAX_CUSTOM_TEXTURES = 51

local textureTypes = {
    diffuse = { suffix = "_d", filename = "diffuse." },
    normal = { suffix = "_n", filename = "normal." },
    spec = { suffix = "_s", filename = "spec." }
}

local fallbackTextures = {
    walls = { normal = "kq_sb_wall_tx_2_n", spec = "kq_sb_wall_tx_2_s" },
    floors = { normal = "kq_sb_tile_2_n", spec = "kq_sb_tile_2_s" }
}

local wallArchetypeNames = {
    "kq_sb_arch_xcustom_%d",
    "kq_sb_doorway_xcustom_%d",
    "kq_sb_halfwall_xcustom_%d",
    "kq_sb_quartwall_xcustom_%d",
    "kq_sb_wall_xcustom_%d",
    "kq_sb_wall_window_xcustom_%d"
}

local floorArchetypeNames = {
    "kq_sb_tile_xcustom_%d"
}

local registeredTextures = {}
local validCustomIndices = {
    walls = {},
    floors = {}
}

--- Checks if a custom texture file exists within the resource.
--- @param filePath string The path to the texture file.
--- @return boolean True if the file exists and is not empty.
local function fileExists(filePath)
    local content = LoadResourceFile(resourceName, filePath)
    return content ~= nil and content ~= ""
end

--- Creates a runtime texture from an image file.
--- @param textureName string The name for the new texture in the runtime TXD.
--- @param imagePath string The path to the source image file.
--- @param fallbackName? string The name of a fallback texture to use if the image is missing.
--- @return boolean True if the texture was created or a fallback was used successfully.
local function createRuntimeTexture(textureName, imagePath, fallbackName)
    if registeredTextures[textureName] then
        return true
    end

    if fileExists(imagePath) then
        local success, result = pcall(CreateRuntimeTextureFromImage, runtimeTxd, textureName, imagePath)
        if success and result then
            Debug(string.format("✓ Created texture: %s from %s", textureName, imagePath))
            registeredTextures[textureName] = true
            return true
        else
            Debug(string.format("✗ Failed to create texture: %s from %s", textureName, imagePath))
            return false
        end
    elseif fallbackName then
        Debug(string.format("» Using fallback texture %s for missing %s", fallbackName, imagePath))
        registeredTextures[textureName] = true
        return true
    else
        Debug(string.format("✗ Missing required texture: %s", imagePath))
        return false
    end
end

--- Loads all texture maps (diffuse, normal, spec) for a specific custom item.
--- @param category string "walls" or "floors".
--- @param index number The index of the custom texture (e.g., 1 for custom_1).
--- @return boolean True if the diffuse texture (required) was loaded successfully.
local function initializeTexturesForCategory(category, index)
    if not runtimeTxd then return false end

    local basePath = string.format("custom_textures/%s/%d/", category, index)
    local pngPath = basePath .. "diffuse.png"
    local ddsPath = basePath .. "diffuse.dds"

    if not fileExists(ddsPath) and not fileExists(pngPath) then
        return false
    end

    local allTexturesValid = true
    for texType, data in pairs(textureTypes) do
        local ddsFile = basePath .. data.filename .. "dds"
        local pngFile = basePath .. data.filename .. "png"
        local finalPath = fileExists(ddsFile) and ddsFile or pngFile

        local texNamePrefix = (category == "walls") and "wall_tx" or "tile"
        local newTexName = string.format("kq_sb_%s_%d%s", texNamePrefix, index, data.suffix)
        local fallback = (texType ~= "diffuse") and fallbackTextures[category][texType] or nil

        local success = createRuntimeTexture(newTexName, finalPath, fallback)
        if not success and texType == "diffuse" then
            allTexturesValid = false
            break
        end
        Citizen.Wait(10)
    end
    return allTexturesValid
end

--- Builds the archetype definitions for new custom models.
--- @param category string "walls" or "floors".
--- @param validIndices table A list of valid texture indices for this category.
--- @return table A list of archetype definition tables.
local function buildArchetypes(category, validIndices)
    local archetypes = {}
    local modelNameTemplates = (category == "walls") and wallArchetypeNames or floorArchetypeNames

    for _, index in ipairs(validIndices) do
        for _, modelTemplate in ipairs(modelNameTemplates) do
            local modelName = string.format(modelTemplate, index)
            if not IsModelValid(modelName) then
                local archetype = {
                    flags = 0,
                    name = modelName,
                    textureDictionary = RUNTIME_TXD_NAME,
                    physicsDictionary = modelName,
                    assetName = modelName,
                    assetType = "ASSET_TYPE_DRAWABLE",
                    lodDist = 60.0,
                    hdTextureDist = 40.0,
                    specialAttribute = 0
                }
                if category == "walls" then
                    archetype.bbMin = vector3(-1.0, -1.0746, -0.025)
                    archetype.bbMax = vector3(-0.9249, 1.0746, 0.7052)
                    archetype.bsCentre = vector3(-0.9624, 0.0, 0.3401)
                    archetype.bsRadius = 1.1355
                else -- floors
                    archetype.bbMin = vector3(-1.02, -1.02, -0.02)
                    archetype.bbMax = vector3(1.02, 1.02, 0.0087)
                    archetype.bsCentre = vector3(0.0, 0.0, -0.0056)
                    archetype.bsRadius = 1.4425
                end
                table.insert(archetypes, archetype)
            end
        end
    end
    return archetypes
end

--- Registers new archetypes with the game and updates the global Settings table.
--- @param category string "walls" or "floors".
--- @param validIndices table A list of valid texture indices for this category.
--- @return boolean True on success.
local function registerArchetypesForCategory(category, validIndices)
    if #validIndices == 0 then
        Debug(string.format("No valid indices found for %s", category))
        return false -- Not an error, just nothing to do.
    end

    local newArchetypes = buildArchetypes(category, validIndices)
    if #newArchetypes == 0 then
        Debug(string.format("No new archetypes to register for %s", category))
        return true -- Not an error, already registered.
    end

    Debug(string.format("Registering %d %s archetypes in batch...", #newArchetypes, category))

    local success, err = pcall(RegisterArchetypes, function() return newArchetypes end)

    if success then
        Debug(string.format("✓ Successfully registered %d %s archetypes", #newArchetypes, category))
        for _, index in ipairs(validIndices) do
            local settingKey = "custom_" .. index
            if category == "walls" then
                Settings.walls[settingKey] = {
                    name = L("custom.walls." .. index),
                    model = "xcustom_" .. index,
                    customIndex = index
                }
            else -- floors
                Settings.floors[settingKey] = {
                    name = L("custom.floors." .. index),
                    model = "xcustom_" .. index,
                    customIndex = index
                }
                Settings.ceilings[settingKey] = {
                    name = L("custom.ceilings." .. index),
                    model = "kq_sb_tile_xcustom_" .. index,
                    customIndex = index,
                    offset = { pos = vec3(0, 0, 2.983), rotation = vec3(180, 0, 0) }
                }
            end
        end
        return true
    else
        Debug(string.format("✗ Failed to register %s archetypes: %s", category, tostring(err)))
        return false
    end
end

--- Re-applies all custom texture replacements.
function ActivateAllReplaceTextures()
    if not CUSTOMS_LOADED then
        Debug("Cannot activate textures - customs not loaded yet")
        return
    end

    CreateThread(function()
        Wait(2000)

        if not HasStreamedTextureDictLoaded(ORIGINAL_TXD_NAME) then
            RequestStreamedTextureDict(ORIGINAL_TXD_NAME, false)
            while not HasStreamedTextureDictLoaded(ORIGINAL_TXD_NAME) do
                Debug("Waiting for original texture dictionary to load...")
                Wait(100)
            end
            Debug("Original texture dictionary loaded")
        end

        if not HasStreamedTextureDictLoaded(RUNTIME_TXD_NAME) then
            RequestStreamedTextureDict(RUNTIME_TXD_NAME, false)
            while not HasStreamedTextureDictLoaded(RUNTIME_TXD_NAME) do
                Debug("Waiting for runtime texture dictionary to load...")
                Wait(100)
            end
            Debug("Runtime texture dictionary loaded")
        end

        local replaceCount = 0
        for textureName, _ in pairs(registeredTextures) do
            AddReplaceTexture(ORIGINAL_TXD_NAME, textureName, RUNTIME_TXD_NAME, textureName)
            replaceCount = replaceCount + 1
            Wait(10)
        end
        Debug(string.format("✓ Activated %d texture replacements", replaceCount))
    end)
end

--- The main function to process all custom textures and archetypes.
function InitializeCustomTextures()
    if CUSTOMS_LOADED then
        Debug("Customs already loaded.")
        return
    end
    if _INITIALIZING then
        Debug("Already initializing customs...")
        return
    end

    _INITIALIZING = true
    Debug("Processing custom textures...")

    for i = 1, MAX_CUSTOM_TEXTURES do
        if initializeTexturesForCategory("walls", i) then
            table.insert(validCustomIndices.walls, i)
        end
        if initializeTexturesForCategory("floors", i) then
            table.insert(validCustomIndices.floors, i)
        end
        Citizen.Wait(10)
    end

    Debug(string.format("Found %d valid wall indices and %d valid floor indices", #validCustomIndices.walls, #validCustomIndices.floors))

    local wallsRegistered = registerArchetypesForCategory("walls", validCustomIndices.walls)
    Citizen.Wait(150)
    local floorsRegistered = registerArchetypesForCategory("floors", validCustomIndices.floors)

    if wallsRegistered and floorsRegistered then
        CUSTOMS_LOADED = true
        Debug("✓ Custom texture initialization completed successfully")
        Citizen.SetTimeout(3000, ActivateAllReplaceTextures)
    else
        Debug("✗ Custom texture initialization failed")
    end
    _INITIALIZING = false
end

function IsPlayerFullyLoaded()
    local ped = PlayerPedId()
    return HasCollisionLoadedAroundEntity(ped)
        and IsEntityVisible(ped)
        and not IsPlayerSwitchInProgress()
        and IsScreenFadedIn()
end

-- Initialization triggers
AddEventHandler("playerSpawned", function()
    Citizen.SetTimeout(6500, function()
        while not IsPlayerFullyLoaded() do
            Debug("Waiting for player to be fully loaded...")
            Citizen.Wait(1000)
        end
        if not CUSTOMS_LOADED and not _INITIALIZING then
            Debug("Start InitializeCustomTextures from playerSpawned event")
            InitializeCustomTextures()
        end
    end)
end)

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == 'kq_shellbuilder' and CUSTOMS_LOADED then
        Debug("Shell builder restarted, re-applying custom textures...")
        Citizen.SetTimeout(2000, ActivateAllReplaceTextures)
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        for texName, _ in pairs(registeredTextures) do
            RemoveReplaceTexture(ORIGINAL_TXD_NAME, texName)
        end
        if HasStreamedTextureDictLoaded(RUNTIME_TXD_NAME) then
            SetStreamedTextureDictAsNoLongerNeeded(RUNTIME_TXD_NAME)
        end
    end
end)

Debug("Customs file loaded")