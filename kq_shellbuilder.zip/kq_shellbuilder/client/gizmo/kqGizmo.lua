Gizmo = {
    _threadRunning = false
}

local gizmoConfig = {
    arrowLength = 0.55,
    arrowHeadSize = 0.05,
    rotationRingRadius = 0.35,
    rotationRingSegments = 24,
    lineThicknessPx = 1.25,
    planeSize = 0.24,
    planeOffset = 0.09,
    lineAlpha = {
        normal = 150,
        hover = 200,
        active = 200,
    },
    colors = {
        x = {
            normal = { 227, 39, 18 },
            hover = { 255, 255, 0 },
            active = { 255, 255, 255 },
        },
        y = {
            normal = { 16, 224, 37 },
            hover = { 255, 255, 0 },
            active = { 255, 255, 255 },
        },
        z = {
            normal = { 17, 77, 237 },
            hover = { 255, 255, 0 },
            active = { 255, 255, 255 },
        },
        xy = {
            normal = { 111, 141, 189 },
            hover = { 255, 255, 0 },
            active = { 255, 255, 255 },
        },
        xz = {
            normal = { 136, 181, 129 },
            hover = { 255, 255, 0 },
            active = { 255, 255, 255 },
        },
        yz = {
            normal = { 181, 129, 129 },
            hover = { 255, 255, 0 },
            active = { 255, 255, 255 },
        },
        dragLine = { 178, 243, 0 },
    },
    sensitivity = {
        translation = 0.025,
        rotation = 1.5,
        rotationDrag = 1.0,
    },
    screenPickThreshold = 0.015,
    dragLineLength = 100.0,
}

--------------------------------------------------------------------------------
-- Math and Vector Helpers
--------------------------------------------------------------------------------
local function sign(n)
    if n > 0 then return 1 end
    if n < 0 then return -1 end
    return 0
end

local function normalize(v)
    local len = #(v)
    if len > 0 then
        return v / len
    end
    return v
end

local function dot(v1, v2)
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
end

local function cross(v1, v2)
    return vector3(
        v1.y * v2.z - v1.z * v2.y,
        v1.z * v2.x - v1.x * v2.z,
        v1.x * v2.y - v1.y * v2.x
    )
end

local function project(v, onNormal)
    return onNormal * dot(v, onNormal)
end

local function angleBetweenVectors(v1, v2, planeNormal)
    local proj1 = normalize(project(v1, planeNormal))
    local proj2 = normalize(project(v2, planeNormal))

    local angle = math.acos(math.max(-1, math.min(1, dot(proj1, proj2))))
    if dot(cross(proj1, proj2), planeNormal) < 0 then
        angle = -angle
    end
    return angle
end

local function pxToScreen(px)
    local _, screenH = GetActiveScreenResolution()
    return (px or 3.0) / screenH
end

local function drawLine2D(p1, p2, r, g, b, a, width)
    local resW, resH = GetActiveScreenResolution()
    local x1, y1 = GetScreenCoordFromWorldCoord(p1.x, p1.y, p1.z)
    local x2, y2 = GetScreenCoordFromWorldCoord(p2.x, p2.y, p2.z)

    if x1 and x2 then
        DrawLine(x1, y1, x2, y2, r, g, b, a) -- Note: FiveM's DrawLine doesn't support width
    end
end

local function getEntityMatrix(entity)
    return GetEntityMatrix(entity)
end

local function worldToLocal(entity, worldPos)
    local right, fwd, up, pos = getEntityMatrix(entity)
    local relPos = worldPos - pos
    return vector3(dot(relPos, right), dot(relPos, fwd), dot(relPos, up))
end

local function localToWorld(entity, localPos)
    local right, fwd, up, pos = getEntityMatrix(entity)
    local worldPos = pos + (right * localPos.x) + (fwd * localPos.y) + (up * localPos.z)
    return worldPos
end

local function getCameraDirections()
    local rot = GetFinalRenderedCamRot(2)
    local radX = math.rad(rot.x)
    local radZ = math.rad(rot.z)

    local fwd = normalize(vector3(-math.sin(radZ) * math.cos(radX), math.cos(radZ) * math.cos(radX), math.sin(radX)))
    local up = normalize(vector3(math.cos(radZ), math.sin(radZ), 0.0))
    local right = normalize(cross(up, fwd))

    return GetFinalRenderedCamCoord(), fwd, up, right
end

local function screenToWorld(screenX, screenY)
    local camPos, camFwd, camUp, camRight = getCameraDirections()
    local fov = GetFinalRenderedCamFov()
    local tanHalfFov = math.tan(math.rad(fov * 0.5))
    local resW, resH = GetActiveScreenResolution()
    local aspectRatio = resW / resH

    local viewX = (screenX - 0.5) * 2.0
    local viewY = (0.5 - screenY) * 2.0

    local rayDir = normalize(camFwd + (camRight * viewX * tanHalfFov * aspectRatio) + (camUp * viewY * tanHalfFov))
    return camPos, rayDir
end

local function intersectPlane(rayOrigin, rayDir, planeOrigin, planeNormal)
    local denom = dot(rayDir, planeNormal)
    if math.abs(denom) < 0.000001 then return nil end

    local t = dot(planeOrigin - rayOrigin, planeNormal) / denom
    if t < 0 then return nil end

    return rayOrigin + rayDir * t
end

--------------------------------------------------------------------------------
-- Gizmo State and Functions
--------------------------------------------------------------------------------

function Gizmo.start(entity, updateCallback)
    Gizmo.enabled = true
    Gizmo.entity = entity
    Gizmo.mode = "translate"
    Gizmo.space = "global"
    Gizmo.activeAxis = nil
    Gizmo.hoveredAxis = nil
    Gizmo.isDragging = false
    Gizmo.lastMousePos = { x = 0, y = 0 }
    Gizmo.originalAlpha = GetEntityAlpha(entity)
    Gizmo.dragPlane = nil
    Gizmo.dragStartPos = nil
    Gizmo.updateCallback = updateCallback or function() return true end

    if not Gizmo._threadRunning then
        Citizen.CreateThread(function()
            Gizmo._threadRunning = true
            while Gizmo.entity and DoesEntityExist(Gizmo.entity) do
                Citizen.Wait(1)
                -- Controls to disable while gizmo is active
                local controlsToDisable = { 24, 25, 22, 21, 44, 45, 47, 37, 140, 141, 142, 12, 13, 14, 15, 16, 17, 18, 19, 23, 75, 38, 200, 210, 243 }
                for _, control in ipairs(controlsToDisable) do
                    DisableControlAction(0, control, true)
                end
                Gizmo.update()
            end
            Gizmo._threadRunning = false
        end)
    end
end

function Gizmo.stop()
    Gizmo.enabled = false
    Gizmo.entity = nil
    Gizmo.activeAxis = nil
    Gizmo.hoveredAxis = nil
    Gizmo.isDragging = false
    Gizmo.dragPlane = nil
    Gizmo.dragAxis = nil
    Gizmo.updateCallback = nil
end

function Gizmo.getSpeedModifier()
    return IsDisabledControlPressed(0, 210) and 0.1 or 1.0
end

function Gizmo.getMousePosition()
    local mouseX, mouseY = GetNuiCursorPosition()
    local resW, resH = GetActiveScreenResolution()
    if mouseX > 1.0 or mouseY > 1.0 then
        mouseX = mouseX / resW
        mouseY = mouseY / resH
    end
    return mouseX, mouseY
end

function Gizmo.getAxisDirection(axis, ignoreCamera)
    local direction
    if Gizmo.space == "global" then
        if axis == "x" then direction = vector3(1, 0, 0)
        elseif axis == "y" then direction = vector3(0, 1, 0)
        else direction = vector3(0, 0, 1) end
    else
        local right, fwd, up = getEntityMatrix(Gizmo.entity)
        if axis == "x" then direction = right
        elseif axis == "y" then direction = fwd
        else direction = up end
    end

    if not ignoreCamera then
        local camPos = GetFinalRenderedCamCoord()
        local entPos = GetEntityCoords(Gizmo.entity)
        if dot(direction, normalize(camPos - entPos)) < 0 then
            direction = -direction
        end
    end
    return direction
end

function Gizmo.getPlaneNormal(plane)
    if Gizmo.space == "global" then
        if plane == "xy" then return vector3(0, 0, 1)
        elseif plane == "xz" then return vector3(0, 1, 0)
        else return vector3(1, 0, 0) end
    else
        local right, fwd, up = getEntityMatrix(Gizmo.entity)
        if plane == "xy" then return up
        elseif plane == "xz" then return fwd
        else return right end
    end
end

function Gizmo.getColorAlpha(axis, normalColor)
    local alpha = gizmoConfig.lineAlpha.normal
    if Gizmo.hoveredAxis == axis then
        alpha = gizmoConfig.lineAlpha.hover
    elseif Gizmo.activeAxis == axis then
        alpha = gizmoConfig.lineAlpha.active
    end
    return normalColor[1], normalColor[2], normalColor[3], alpha
end

--------------------------------------------------------------------------------
-- Drawing Functions
--------------------------------------------------------------------------------

function Gizmo.drawArrow(origin, axis, colorSet)
    local dir = Gizmo.getAxisDirection(axis, false)
    local tip = origin + dir * gizmoConfig.arrowLength
    local r, g, b, a = Gizmo.getColorAlpha(axis, colorSet.normal)

    if Gizmo.hoveredAxis == axis then r, g, b = unpack(colorSet.hover)
    elseif Gizmo.activeAxis == axis then r, g, b = unpack(colorSet.active) end

    drawLine2D(origin, tip, r, g, b, 255, gizmoConfig.lineThicknessPx)

    local headSize = gizmoConfig.arrowHeadSize
    local base = tip - dir * headSize
    local camFwd = normalize(GetFinalRenderedCamCoord() - base)

    local side1 = normalize(cross(dir, camFwd))
    if #(side1) < 0.0001 then side1 = normalize(cross(dir, vector3(0,0,1))) end
    if #(side1) < 0.0001 then side1 = normalize(cross(dir, vector3(1,0,0))) end
    local side2 = normalize(cross(dir, side1))

    local p1 = tip
    local p2 = base + side1 * (headSize * 0.3)
    local p3 = base - side1 * (headSize * 0.3)
    drawLine2D(p1, p2, r, g, b, 255, 1.0)
    drawLine2D(p1, p3, r, g, b, 255, 1.0)
end

function Gizmo.drawPlaneSquare(origin, plane, colorSet, isFacing)
    local r, g, b, a = Gizmo.getColorAlpha(plane, colorSet.normal)
    if Gizmo.hoveredAxis == plane then r, g, b = unpack(colorSet.hover)
    elseif Gizmo.activeAxis == plane then r, g, b = unpack(colorSet.active) end

    local size = gizmoConfig.planeSize
    local offset = gizmoConfig.planeOffset
    local thickness = gizmoConfig.lineThicknessPx

    if isFacing then
        thickness = thickness * 1.5
        a = math.min(255, a * 1.3)
    end

    local u, v = (function()
        local right, fwd, up = Gizmo.getDisplayBasis()
        if plane == "xy" then return right, fwd
        elseif plane == "xz" then return right, up
        else return fwd, up end
    end)()

    local center = origin + (u * offset) + (v * offset)
    local p1 = center + (u * size)
    local p2 = center + (u * size) + (v * size)
    local p3 = center + (v * size)

    drawLine2D(center, p1, r, g, b, a, 1)
    drawLine2D(p1, p2, r, g, b, a, 1)
    drawLine2D(p2, p3, r, g, b, a, 1)
    drawLine2D(p3, center, r, g, b, a, 1)
end

function Gizmo.drawRotationRing(origin, axis, colorSet, _dist)
    local r, g, b, a = Gizmo.getColorAlpha(axis, colorSet.normal)
    if Gizmo.hoveredAxis == axis then r, g, b = unpack(colorSet.hover)
    elseif Gizmo.activeAxis == axis then r, g, b = unpack(colorSet.active) end

    local radius = gizmoConfig.rotationRingRadius
    local segments = gizmoConfig.rotationRingSegments
    local thickness = gizmoConfig.lineThicknessPx

    local u, v = (function()
        if Gizmo.space == "global" then
            if axis == 'x' then return vector3(0, 1, 0), vector3(0, 0, 1)
            elseif axis == 'y' then return vector3(1, 0, 0), vector3(0, 0, 1)
            else return vector3(1, 0, 0), vector3(0, 1, 0) end
        else
            local right, fwd, up = getEntityMatrix(Gizmo.entity)
            if axis == 'x' then return fwd, up
            elseif axis == 'y' then return right, up
            else return right, fwd end
        end
    end)()

    local lastPoint
    for i = 0, segments do
        local angle = (i / segments) * math.pi * 2.0
        local point = origin + (u * math.cos(angle) + v * math.sin(angle)) * radius
        if lastPoint then
            drawLine2D(lastPoint, point, r, g, b, a, thickness)
        end
        lastPoint = point
    end
end

--------------------------------------------------------------------------------
-- Update and Interaction Logic
--------------------------------------------------------------------------------

function Gizmo.update()
    if not DoesEntityExist(Gizmo.entity) then return end
    SetMouseCursorActiveThisFrame()
    local mouseX, mouseY = Gizmo.getMousePosition()

    Gizmo.updateHover(mouseX, mouseY)

    if IsDisabledControlJustPressed(0, 24) then -- Left Mouse Button
        Gizmo.lastCoords = GetEntityCoords(Gizmo.entity)
        if Gizmo.hoveredAxis then
            Gizmo.isDragging = true
            Gizmo.activeAxis = Gizmo.hoveredAxis
            Gizmo.lastMousePos = { x = mouseX, y = mouseY }

            if Gizmo.mode == "translate" then
                if Gizmo.activeAxis:find("z") or Gizmo.activeAxis:find("y") or Gizmo.activeAxis:find("x") then
                    if #Gizmo.activeAxis == 2 then -- It's a plane
                        Gizmo.beginPlaneDrag(Gizmo.activeAxis, mouseX, mouseY)
                        Gizmo.dragAxis = nil
                    else -- It's an axis
                        Gizmo.beginAxisDrag(Gizmo.activeAxis, mouseX, mouseY)
                        Gizmo.dragPlane = nil
                    end
                else -- center
                    Gizmo.dragPlane = nil
                    Gizmo.dragAxis = nil
                end
            elseif Gizmo.mode == "rotate" then
                Gizmo.beginRotationDrag(Gizmo.activeAxis, mouseX, mouseY)
            end
        end
    end

    if IsDisabledControlJustReleased(0, 24) then
        Gizmo.isDragging = false
        Gizmo.activeAxis = nil
        Gizmo.dragPlane = nil
        Gizmo.dragAxis = nil
        Gizmo.rotationCenter = nil
    end

    if Gizmo.isDragging and Gizmo.activeAxis then
        local deltaX = mouseX - Gizmo.lastMousePos.x
        local deltaY = mouseY - Gizmo.lastMousePos.y

        if Gizmo.mode == "translate" then
            if Gizmo.dragAxis then
                Gizmo.updateAxisDrag(mouseX, mouseY)
            elseif Gizmo.dragPlane then
                Gizmo.updatePlaneDrag(mouseX, mouseY)
            else -- center
                Gizmo.handleTranslation(deltaX, deltaY)
            end
        elseif Gizmo.mode == "rotate" then
            Gizmo.updateRotationDrag(mouseX, mouseY)
        end
        Gizmo.lastMousePos = { x = mouseX, y = mouseY }
    end
    Gizmo.draw()
end

-- Keybinds and Commands
RegisterCommand("+kqGizmoTranslation", function() if Gizmo.entity then Gizmo.mode = "translate" end end, false)
RegisterCommand("-kqGizmoTranslation", function() end, false)
RegisterKeyMapping("+kqGizmoTranslation", L("keybinds.mode_translate"), "keyboard", "W")

RegisterCommand("+kqGizmoRotation", function() if Gizmo.entity then Gizmo.mode = "rotate" end end, false)
RegisterCommand("-kqGizmoRotation", function() end, false)
RegisterKeyMapping("+kqGizmoRotation", L("keybinds.mode_rotate"), "keyboard", "R")

RegisterCommand("+kqGizmoLocal", function()
    if not Gizmo.entity then return end
    Gizmo.space = (Gizmo.space == "global") and "local" or "global"
end, false)
RegisterCommand("-kqGizmoLocal", function() end, false)
RegisterKeyMapping("+kqGizmoLocal", L("keybinds.space_toggle"), "keyboard", "Q")