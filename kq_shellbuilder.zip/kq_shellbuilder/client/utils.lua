COOLDOWN = 0

function IsCooldown(duration)
    local cooldownTime = duration or 1500
    return (COOLDOWN + cooldownTime) > GetGameTimer()
end

function SetCooldown()
    COOLDOWN = GetGameTimer()
end

function FadeInEntity(entity, duration)
    local stepDuration = math.ceil((duration or 500) / 5)
    SetEntityAlpha(entity, 50)
    Citizen.Wait(stepDuration)
    SetEntityAlpha(entity, 101)
    Citizen.Wait(stepDuration)
    SetEntityAlpha(entity, 152)
    Citizen.Wait(stepDuration)
    SetEntityAlpha(entity, 203)
    Citizen.Wait(stepDuration)
    ResetEntityAlpha(entity)
    Citizen.Wait(stepDuration)
end

function FadeOutEntity(entity, duration)
    local stepDuration = math.ceil((duration or 500) / 5)
    SetEntityAlpha(entity, 203)
    Citizen.Wait(stepDuration)
    SetEntityAlpha(entity, 152)
    Citizen.Wait(stepDuration)
    SetEntityAlpha(entity, 101)
    Citizen.Wait(stepDuration)
    SetEntityAlpha(entity, 50)
    Citizen.Wait(stepDuration)
    SetEntityAlpha(entity, 0)
    Citizen.Wait(stepDuration)
end

function GetPlayersInRange(maxDistance)
    local nearbyPlayers = {}
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)

    for _, playerId in ipairs(GetActivePlayers()) do
        local targetPed = GetPlayerPed(playerId)
        local targetCoords = GetEntityCoords(targetPed)
        if #(playerCoords - targetCoords) <= maxDistance then
            table.insert(nearbyPlayers, GetPlayerServerId(playerId))
        end
    end
    return nearbyPlayers
end

function GetPlayerCoords()
    return UseCache("GetPlayerCoords", function()
        return GetEntityCoords(PlayerPedId())
    end, 1000)
end

function GetNearestVehicle(radius)
    local vehicle, distance = UseCache("GetNearestVehicle" .. radius, function()
        local playerCoords = GetEntityCoords(PlayerPedId())
        local closestDistance = radius
        local closestVehicle = nil
        for _, veh in pairs(GetGamePool("CVehicle")) do
            local dist = #(playerCoords - GetEntityCoords(veh))
            if closestDistance > dist then
                closestDistance = dist
                closestVehicle = veh
            end
        end
        return closestVehicle, closestDistance
    end, 1000)

    if not DoesEntityExist(vehicle) then
        return nil, distance
    end
    return vehicle, distance
end

function GetNetworkedVehiclesInRange(radius, coords)
    return UseCache("GetNetworkedVehiclesInRange" .. radius .. json.encode(coords or {}), function()
        local vehicleList = {}
        local searchCoords = coords or GetEntityCoords(PlayerPedId())
        for _, veh in pairs(GetGamePool("CVehicle")) do
            if NetworkGetEntityIsNetworked(veh) then
                if #(searchCoords - GetEntityCoords(veh)) < radius then
                    table.insert(vehicleList, veh)
                end
            end
        end
        return vehicleList
    end, 1000)
end

function GetClosestVehicleWithModel(modelName, maxDistance)
    local vehicle, distance = UseCache("GetClosestVehicleWithModel" .. modelName .. maxDistance, function()
        local playerCoords = GetEntityCoords(PlayerPedId())
        local modelHash = GetHashKey(modelName)
        local closestDistance = maxDistance
        local closestVehicle = nil
        for _, veh in pairs(GetGamePool("CVehicle")) do
            if GetEntityModel(veh) == modelHash then
                local dist = #(playerCoords - GetEntityCoords(veh))
                if closestDistance > dist then
                    closestDistance = dist
                    closestVehicle = veh
                end
            end
        end
        return closestVehicle, closestDistance
    end, 1000)

    if not DoesEntityExist(vehicle) then
        return nil, distance
    end
    return vehicle, distance
end

function SyncWalkToCoords(coords, heading, timeout)
    local playerPed = PlayerPedId()
    TaskGoStraightToCoord(playerPed, coords, 1.0, timeout, heading, 0.45)
    local distance = #(GetEntityCoords(playerPed) - coords)
    local endTime = GetGameTimer() + timeout
    while distance > 0.4 and GetGameTimer() < endTime do
        distance = #(GetEntityCoords(playerPed) - coords)
        Citizen.Wait(50)
    end
end

function SetEntitySize(entity, size)
    local right, fwd, up, pos = GetEntityMatrix(entity)
    local min, max = GetModelDimensions(GetEntityModel(entity))
    local zOffset = (max.z - min.z) * (size - 1) / 2
    local isOrientedCorrectly = false
    if size > 1.0 and up.z <= 1.0 then isOrientedCorrectly = true end
    if size < 1.0 and up.z >= 1.0 then isOrientedCorrectly = true end

    if isOrientedCorrectly then
        right = right * size
        fwd = fwd * size
        up = up * size
        pos = pos + vector3(0.0, 0.0, zOffset)
    end
    SetEntityMatrix(entity, right, fwd, up, pos)
end

function PlayAnim(animDict, animName, flag, ped)
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Citizen.Wait(100)
    end
    local targetPed = ped or PlayerPedId()
    local animFlag = flag or 1
    TaskPlayAnim(targetPed, animDict, animName, 1.4, 1.4, 5.0, animFlag, 1.0, false, false, false)
    RemoveAnimDict(animDict)
end

function DoRequestModel(model)
    local modelHash = model
    if type(model) ~= "number" then
        modelHash = GetHashKey(model)
    end

    RequestModel(modelHash)
    local timeout = 5000
    while not HasModelLoaded(modelHash) and timeout > 0 do
        Citizen.Wait(50)
        RequestModel(modelHash)
        timeout = timeout - 50
    end

    if timeout <= 0 then
        print(("^1Requesting of a model timed out \"%s:%s\". Let an admin know about this\n^0The prop %s is invalid or can not be streamed. Consider removing it from the config/shell"):format(modelHash, model, model))
        return false
    end
    return true
end

function SmoothTeleport(entity, coords, heading, callback)
    local resourceName = GetCurrentResourceName()
    TriggerEvent(resourceName .. ":client:teleporting", coords)
    TriggerServerEvent(resourceName .. ":server:teleporting", coords)

    Citizen.CreateThread(function()
        local entityToTeleport = entity
        if IsEntityAPed(entityToTeleport) and IsPedInAnyVehicle(entityToTeleport) then
            entityToTeleport = GetVehiclePedIsUsing(entityToTeleport)
        end

        DoScreenFadeOut(500)
        Citizen.Wait(600)

        FreezeEntityPosition(entityToTeleport, true)
        SetEntityCoordsNoOffset(entityToTeleport, coords, true, false, false)
        if heading then
            SetEntityHeading(entityToTeleport, heading)
        end
        if callback then
            callback()
        end
        Citizen.Wait(600)
        FreezeEntityPosition(entityToTeleport, false)

        DoScreenFadeIn(500)

        if IsEntityAVehicle(entityToTeleport) then
            SetVehicleOnGroundProperly(entityToTeleport)
            if #(GetEntityCoords(entityToTeleport) - coords) >= 2.0 then
                SetEntityCoordsNoOffset(entityToTeleport, coords, true, false, false)
                SetEntityHeading(entityToTeleport, heading)
            end
        end
    end)
end

function DeleteNearestOfType(coords, modelHash, radius)
    local searchRadius = radius or 2.0
    local object = GetClosestObjectOfType(coords.x, coords.y, coords.z, searchRadius, modelHash, false, false, false)
    while object ~= 0 do
        SetEntityAsMissionEntity(object, true, true)
        DeleteEntity(object)
        object = GetClosestObjectOfType(coords.x, coords.y, coords.z, searchRadius, modelHash, false, false, false)
        Citizen.Wait(10)
    end
end

function ClearAreaOfObjects(coords, radius)
    for _, obj in pairs(GetGamePool("CObject")) do
        if #(GetEntityCoords(obj) - coords) <= radius then
            SetEntityAsMissionEntity(obj, true, true)
            DeleteEntity(obj)
        end
    end
end

function FaceCoordinates(coords)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local targetHeading = GetHeadingFromVector_2d(coords.x - playerCoords.x, coords.y - playerCoords.y)
    local currentHeading = GetEntityHeading(playerPed)

    if currentHeading > (targetHeading + 25.0) or currentHeading < (targetHeading - 25.0) then
        TaskTurnPedToFaceCoord(playerPed, coords, 1000)
        Citizen.Wait(1200)
    end
end

function RemoveHandWeapons()
    SetCurrentPedWeapon(PlayerPedId(), GetHashKey("WEAPON_UNARMED"), true)
end