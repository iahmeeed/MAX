Nui = {
    loaded = false
}

--- Toggles the main shell selection menu.
--- @param visible boolean Whether to show or hide the menu.
--- @param policyData table Data containing player's permissions for shells.
function Nui.toggleMenu(visible, policyData)
    SendNUIMessage({ type = "set-styling", colors = Config.uiStyling or {} })
    SendNUIMessage({ type = "display", value = visible, page = "/" })

    if visible then
        local displayableShells = {}
        for _, shell in pairs(GetGlobalShells()) do
            if policyData.shells[shell.id] and policyData.shells[shell.id].view then
                shell.policy = policyData.shells[shell.id] or {}
                table.insert(displayableShells, shell)
            end
        end

        SendNUIMessage({
            type = "set-shells",
            value = displayableShells,
            coords = GetEntityCoords(PlayerPedId()),
            heading = GetEntityHeading(PlayerPedId()),
            canCreate = policyData.canCreate
        })
    end

    SetNuiFocusKeepInput(false)
    SetNuiFocus(visible, visible)
end

--- Toggles the builder UI.
--- @param visible boolean Whether to show or hide the builder.
function Nui.toggleBuilder(visible)
    SendNUIMessage({ type = "display", value = visible, page = "/builder" })
    SetNuiFocusKeepInput(false)
    SetNuiFocus(false, visible) -- Cursor only, no input lock
end

--- Sends all necessary settings from config files to the NUI.
function Nui.setSettings()
    -- Send Colors
    SendNUIMessage({ type = "set-colors", value = Settings.colors })

    -- Send Timecycles
    local timecycles = {}
    for _, tc in pairs(Settings.timecycles) do
        table.insert(timecycles, { value = tc.timecycle, label = tc.name })
    end
    SendNUIMessage({ type = "set-timecycles", value = timecycles })

    -- Send Exporters
    local exporters = {}
    for value, data in pairs(Settings.exporters) do
        exporters[value] = { value = value, name = data.name, data = data.data, flipped = data.flipped, order = index }
    end
    SendNUIMessage({ type = "set-exporters", value = exporters })

    -- Send Decorations
    local decorations = {}
    local categories = { "walls", "floors", "doors", "doorframes", "windows", "ceilings", "stairs", "decor" }
    local tags = { "Walls", "Floors", "Doors", "Doorframes", "Windows", "Ceilings", "Stairs", "Decor" }
    local values = { "WALL_DECOR", "FLOOR_DECOR", "DOOR", "DOORFRAME", "WALL_WINDOW", "CEILING", "STAIR", "DECOR" }

    for i, category in ipairs(categories) do
        for key, item in pairs(Settings[category]) do
            local iconName = item.icon or item.model
            if item.customIndex then
                local folder = (category == "ceilings") and "floors" or category
                iconName = string.format("%s/%s/diffuse.png", folder, item.customIndex)
            end

            table.insert(decorations, {
                value = values[i],
                tag = item.tag or tags[i],
                title = item.name,
                texture = key,
                iconName = iconName,
                colorPicker = item.colorPicker or false,
                dyed = item.dyed or false
            })
        end
    end
    SendNUIMessage({ type = "set-decorations", value = decorations })
    Nui.loaded = true
    Debug("NUI settings sent.")
end

--- Updates the NUI with the current state of the shell being edited.
--- @param state table The current shell state.
function Nui.setState(state)
    Debug("New state id", state.id)
    SendNUIMessage({
        type = "set-state",
        id = state.id,
        title = state.title,
        timecycle = state.timecycle,
        hideVoid = state.hideVoid
    })
end

--- Updates the prop count display in the NUI.
--- @param count number The current number of props.
function Nui.setPropCount(count)
    SendNUIMessage({
        type = "set-prop-count",
        value = count,
        maxCount = Settings.maxPropCount
    })
end

local compressedImageResult = nil
RegisterNuiCallback("imageResponse", function(data, cb)
    Debug("imageResponse received")
    cb({})
    compressedImageResult = data.data
end)

--- Requests the NUI to resize and compress an image for a thumbnail.
--- @param imageData string The base64 encoded image data.
--- @return string The compressed image data, or nil on timeout.
function Nui.resizeImage(imageData)
    compressedImageResult = nil
    SendNUIMessage({ type = "resize-image", data = imageData })

    local timeout = GetGameTimer() + 2500
    while not compressedImageResult and GetGameTimer() < timeout do
        Citizen.Wait(20)
    end

    Debug("Compressed image size", compressedImageResult and #compressedImageResult or "N/A")
    return compressedImageResult
end

-- NUI Event Handlers
RegisterNuiCallback("nuiLoaded", function(data, cb)
    Citizen.SetTimeout(2000, function()
        local timeout = GetGameTimer() + 20000
        while not CUSTOMS_LOADED and GetGameTimer() < timeout do
            Citizen.Wait(500)
            if Config.debug then
                -- DrawMissionText("~g~Shell Creator ~w~initializing. Please wait...")
            end
        end
        Nui.setSettings()
    end)
end)

RegisterNuiCallback("fetch-locale", function(data, cb)
    cb({ success = true, data = L("ui") })
end)

RegisterNetEvent("kq_shellbuilder:client:openEditor")
AddEventHandler("kq_shellbuilder:client:openEditor", function(policyData)
    if Builder.active then return end

    while not Nui.loaded do
        print("^3NUI did not finish loading, retrying...")
        -- DrawMissionText("~g~Shell Creator ~w~initializing. Please wait...")
        Citizen.Wait(1000)
    end
    Nui.toggleMenu(true, policyData)
end)

RegisterNUICallback("close", function(data, cb)
    Nui.toggleMenu(false)
    cb({})
end)

RegisterNUICallback("buildNewShell", function(data, cb)
    Debug("buildNewShell")
    Builder.init()
    cb({})
end)

RegisterNUICallback("editShell", function(data, cb)
    Debug("editShell")
    Builder.editShell(data.id)
    cb({})
end)

RegisterNUICallback("setNuiFocus", function(data, cb)
    Debug("setNuiFocus", data)
    Builder.setNuiFocus(data)
    cb({})
end)

RegisterNUICallback("setDemoMode", function(data, cb)
    Debug("setDemoMode", data.enabled)
    Builder.setDemoMode(data.enabled)
    cb({})
end)

RegisterNUICallback("setWallsMode", function(data, cb)
    Debug("setWallsMode", data.enabled)
    Builder.setWallsMode(data.enabled)
    cb({})
end)

RegisterNUICallback("setMode", function(data, cb)
    Debug("setMode", data.mode)
    Builder.setMode(data.mode)
    cb({})
end)

RegisterNUICallback("setColor", function(data, cb)
    Debug("setColor", data.color)
    Builder.setColor(data.color)
    cb({})
end)

RegisterNUICallback("setTexture", function(data, cb)
    Debug("setTexture", data.texture)
    Builder.setTexture(data.texture)
    cb({})
end)

RegisterNUICallback("undo", function(data, cb)
    Debug("undo")
    Builder.undo()
    cb({})
end)

RegisterNUICallback("redo", function(data, cb)
    Debug("redo")
    Builder.redo()
    cb({})
end)

RegisterNUICallback("levelUp", function(data, cb)
    Debug("levelUp")
    if Builder.options.level >= Builder.config.maxLevels - 1 then
        exports.kq_link:Notify(L("builder.levels.cant_up"), "warning")
        return
    end
    Builder.setLevel(Builder.options.level + 1)
    cb({})
end)

RegisterNUICallback("levelDown", function(data, cb)
    Debug("levelDown")
    if Builder.options.level == 0 then
        exports.kq_link:Notify(L("builder.levels.cant_down"), "warning")
        return
    end
    Builder.setLevel(Builder.options.level - 1)
    cb({})
end)

RegisterNUICallback("openPreview", function(data, cb)
    Debug("openPreview")
    cb({})
    if Builder.options.testMode then
        Builder.exitTestMode()
    else
        Builder.enterTestMode()
    end
end)

RegisterNUICallback("teleportToShell", function(data, cb)
    Debug("teleportToShell")
    cb({})
    Spawner.teleportToShell(data.id)
end)

RegisterNUICallback("updateCoords", function(data, cb)
    Debug("updateCoords")
    cb({})
    Spawner.updateCoords(data.id, vec3(tonumber(data.x), tonumber(data.y), tonumber(data.z)))
end)

RegisterNUICallback("timecycleChanged", function(data, cb)
    Debug("timecycleChanged", data.timecycle)
    cb({})
    ClearTimecycleModifier()
    Wait(50)
    if data.timecycle and data.timecycle ~= "" then
        SetTimecycleModifier(data.timecycle)
    end
end)

RegisterNUICallback("updateTeleporter", function(data, cb)
    Debug("updateTeleporter", json.encode(data))
    cb({})
    Spawner.updateTeleporter(
        data.id,
        data.active,
        vec4(tonumber(data.x or 0), tonumber(data.y or 0), tonumber(data.z or 0), tonumber(data.w or 0)),
        tonumber(data.vehicles)
    )
end)

RegisterNUICallback("deleteShell", function(data, cb)
    Debug("deleteShell")
    cb({})
    TriggerServerEvent("kq_shellbuilder:server:deleteShell", data.id)
end)

RegisterNUICallback("saveShell", function(data, cb)
    Debug("saveShell")
    cb({})
    Builder.save({
        title = data.title,
        timecycle = data.timecycle,
        hideVoid = data.hideVoid or 0
    })
end)

RegisterNUICallback("quitBuilder", function(data, cb)
    Debug("quitBuilder")
    cb({})
    Builder.quit()
end)

function IsPlayerFullyLoaded()
    local ped = PlayerPedId()
    return HasCollisionLoadedAroundEntity(ped)
        and IsEntityVisible(ped)
        and not IsPlayerSwitchInProgress()
        and IsScreenFadedIn()
end

CreateThread(function()
    if PlayerPedId() <= 0 then
        Debug("Non-restart detected, script will not auto-initialize.")
        return
    end

    while not IsPlayerFullyLoaded() do
        Debug("Waiting for player to be fully loaded before initializing customs...")
        Citizen.Wait(1000)
    end

    Citizen.Wait(5500)
    if not CUSTOMS_LOADED and not _INITIALIZING then
        Debug("Start InitializeCustomTextures from initial timer")
        InitializeCustomTextures()
    end
end)