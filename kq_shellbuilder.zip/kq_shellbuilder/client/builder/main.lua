local Builder = {}

Builder.centerCoords = vec3(0, -2500, 900)

Builder.modes = {
    FLOOR = "floor",
    WALL = "wall",
    HALF_WALL = "half_wall",
    QUART_WALL = "quart_wall",
    ARCHWAY = "archway",
    DOORWAY = "doorway",
    WALL_WINDOW = "wall_window",
    WALL_HOLE = "wall_hole",
    DOORFRAME = "doorframe",
    DOOR = "door",
    CEILING = "ceiling",
    WALL_DECOR = "wall_decor",
    FLOOR_DECOR = "floor_decor",
    DECOR = "decor",
    STAIR = "STAIR",
    SPAWNPOINT = "SPAWNPOINT",
}

Builder.mode = Builder.modes.FLOOR

function Builder.setDefaults()
    Builder.saving = false
    Builder.id = nil
    Builder.active = false
    Builder.tiles = {}
    Builder.matrix = {}
    Builder.camera = nil
    Builder.takingThumbnail = false
    Builder.options = {
        wallFading = false,
        demolition = false,
        testMode = false,
        color = 0,
        texture = 0,
        level = 0,
        lastLevel = 0,
        nuiFocus = false,
    }
    Builder.queue = {
        undo = {},
        redo = {},
    }
    Builder.storage = {
        initPlayerCoords = nil,
        propCount = 0,
    }
    Builder.settings = {
        shellName = "New shell",
        timecycle = 0,
        spawnPoint = {
            tile = nil,
            heading = 0.0,
        },
    }
    Builder.defaultConfig = {
        maxLevels = 4,
        depth = 21,
        width = 21,
    }
    Builder.config = {
        maxLevels = 4,
        depth = 7,
        width = 5,
    }
end

Builder.setDefaults()

function Builder.setConfig(maxLevels, depth, width)
    Builder.config = {
        maxLevels = maxLevels or Builder.defaultConfig.maxLevels,
        depth = depth or Builder.defaultConfig.depth,
        width = width or Builder.defaultConfig.width,
    }
end

function Builder.init(maxLevels, depth, width)
    Builder.setDefaults()
    Builder.setConfig(maxLevels, depth, width)
    Builder.active = true
    Builder.cleanUp()
    Builder.prepare()

    Nui.toggleMenu(false)
    local playerPed = PlayerPedId()
    FreezeEntityPosition(playerPed, true)
    SetEntityVisible(playerPed, false, 0)
    SetEntityInvincible(playerPed, true)
    NetworkSetEntityInvisibleToNetwork(playerPed, true)

    Builder.startCamera()
    Builder.thread()

    Nui.setState({
        id = nil,
        title = Builder.settings.shellName,
        timecycle = Builder.settings.timecycle,
        hideVoid = Builder.settings.hideVoid,
    })

    Builder.setLevel(0)
    InitializeCustomTextures()
    Nui.toggleBuilder(true)
end

function Builder.quit()
    Builder.active = false
    Builder.cleanUp()

    Nui.toggleMenu(false)
    Nui.toggleBuilder(false)

    local playerPed = PlayerPedId()
    FreezeEntityPosition(playerPed, false)
    SetEntityVisible(playerPed, true, 0)
    SetEntityInvincible(playerPed, false)
    NetworkSetEntityInvisibleToNetwork(playerPed, false)
end

function Builder.prepare()
    Builder.spawnVoid()
    Builder.buildTiles()
end

function Builder.thread()
    Citizen.CreateThread(function()
        while Builder.active do
            local wait = 100
            SetRainLevel(0.0)

            if not Builder.options.testMode then
                wait = 1
                DisableControlAction(0, 24, true) -- Attack
                DisableControlAction(0, 25, true) -- Aim
                DisableControlAction(0, 140, true) -- Melee Attack
                DisablePlayerFiring(PlayerId(), true)
                HideHudAndRadarThisFrame()

                if Builder.mode == Builder.modes.SPAWNPOINT then
                    Builder.renderSpawnPoint()
                end

                local tile, pos, normal = Builder.getInteractionTile()
                if tile then
                    tile:handleInteraction(pos, normal)
                end
            else
                DrawMissionText(L("builder.preview.exit"), 600)
                wait = 1
                SetPlayerVisibleLocally(PlayerId(), true)
                if IsControlPressed(0, 47) then -- G Key
                    Citizen.Wait(500)
                    if IsControlPressed(0, 47) then
                        Builder.exitTestMode()
                    end
                end
            end
            Citizen.Wait(wait)
        end
        SetRainLevel(-1.0)
    end)
end

function Builder.cleanUp()
    ClearAreaOfObjects(Builder.centerCoords, 70.0)
    if Builder.void and DoesEntityExist(Builder.void) then
        DeleteEntity(Builder.void)
    end
    Builder.killCamera()
end

function Builder.save(data)
    local thumbnail = nil
    Builder.saving = true

    if Config.thumbnails.enabled and GetResourceState("screenshot-basic") == "started" then
        Builder.takingThumbnail = true
        Builder.setThumbnailCamera()
        Builder.setWallsMode(true)
        Builder.setMode(Builder.modes.WALL)

        Citizen.Wait(50)

        exports["screenshot-basic"]:requestScreenshot({
            quality = 0.5,
            encoding = "webp"
        }, function(screenshotData)
            thumbnail = screenshotData
        end)

        local timeout = GetGameTimer() + 1500
        while not thumbnail and GetGameTimer() < timeout do
            Citizen.Wait(20)
        end
        
        Citizen.Wait(50)

        if thumbnail then
            thumbnail = Nui.resizeImage(thumbnail)
        end
        
        Citizen.Wait(50)

        Builder.setWallsMode(false)
        Builder.setMode(Builder.modes.FLOOR)
        Builder.takingThumbnail = false
    end

    Builder.refresh(true, true)
    Citizen.Wait(100)

    local shellPayload = {
        id = Builder.id,
        title = data.title,
        builderData = Builder.getShellData(),
        settings = {
            timecycle = data.timecycle,
            hideVoid = data.hideVoid,
        },
        spawnData = Builder.getSpawnData(),
        thumbnail = thumbnail,
    }

    if Config.useLatentEvents then
        TriggerLatentServerEvent("kq_shellbuilder:server:saveShell", -1, shellPayload)
    else
        TriggerServerEvent("kq_shellbuilder:server:saveShell", shellPayload)
    end
end

function Builder.editShell(shellId, maxLevels, depth, width)
    local shell = FindGlobalShellById(shellId)
    if not shell then
        print("Shell not found", shellId)
        return
    end

    Builder.init(maxLevels, depth, width)
    Builder.id = shellId
    Builder.settings.shellName = shell.title
    Builder.settings.timecycle = shell.settings.timecycle or 0
    Builder.settings.hideVoid = shell.settings.hideVoid or 0

    Nui.setState({
        id = shell.id,
        title = shell.title,
        timecycle = shell.settings.timecycle,
        hideVoid = shell.settings.hideVoid or 0,
    })

    Builder.loadShellData(shell.builderData)
end

RegisterNetEvent("kq_shellbuilder:client:quit")
AddEventHandler("kq_shellbuilder:client:quit", function()
    Builder.quit()
end)

exports("OpenShellEditor", function(shellId, maxLevels, depth, width)
    Debug("OpenShellEditor export called", shellId, GetInvokingResource())
    if shellId then
        Builder.editShell(tonumber(shellId), tonumber(maxLevels), tonumber(depth), tonumber(width))
    else
        Builder.init(tonumber(maxLevels), tonumber(depth), tonumber(width))
    end
end)