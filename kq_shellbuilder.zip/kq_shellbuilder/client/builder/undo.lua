function Builder:saveUndoState()
    local currentState = self:getShellData()
    table.insert(self.queue.undo, 1, currentState)
    self.queue.undo[10] = nil
end

function Builder:undo()
    if IsCooldown(500) then
        return
    end
    SetCooldown()

    local undoState = self.queue.undo[1]
    if not undoState then
        exports.kq_link:Notify("You can't undo anymore", "error")
        return
    end

    self:saveRedoState()
    self:loadShellData(undoState)
    table.remove(self.queue.undo, 1)
end

function Builder:saveRedoState()
    local currentState = self:getShellData()
    table.insert(self.queue.redo, 1, currentState)
    self.queue.redo[10] = nil
end

function Builder:redo()
    if IsCooldown(500) then
        return
    end
    SetCooldown()

    local redoState = self.queue.redo[1]
    if not redoState then
        exports.kq_link:Notify("You can't redo anymore", "error")
        return
    end

    self:saveUndoState()
    self:loadShellData(redoState)
    table.remove(self.queue.redo, 1)
end