local isNuiFocused = false

function Builder:getInteractionTile()
    return UseCache("getInteractionTile", function()
        local hitCoords, screenX, _, hitEntity = GetCursorHitCoords()

        if screenX > 0.75 or (self.options and self.options.nuiFocus) then
            if not isNuiFocused then
                SetNuiFocus(true, true)
                SetNuiFocusKeepInput(false)
                isNuiFocused = true
            end
            return
        else
            if isNuiFocused then
                SetNuiFocusKeepInput(true)
                isNuiFocused = false
            end
        end

        if not hitCoords then
            return nil
        end

        if not self.options.demolition then
            if self.storage.propCount >= Settings.maxPropCount then
                return
            end
        end

        if hitEntity then
            local tileId = Entity(hitEntity).state.kq_sb_tile
            if tileId then
                local tile = self.tiles[tileId]
                if tile and self.options.level == tile.z then
                    return tile, hitCoords, hitEntity
                end
            end
        end

        for _, tile in pairs(self.tiles) do
            if tile:isInteractable(hitCoords) then
                return tile, hitCoords
            end
        end

        return nil
    end, 100)
end