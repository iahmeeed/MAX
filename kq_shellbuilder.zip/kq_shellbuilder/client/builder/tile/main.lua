Tile = {}
Tile.__index = Tile

local previewTemplate = {
    tile = nil,
    top = nil,
    bottom = nil,
    left = nil,
    right = nil
}

local wallElementTemplate = {
    active = false,
    type = nil,
    color = 0,
    texture = 0,
    entity = nil,
    extras = {
        doorframe = { active = false, entity = nil, texture = 0, color = 0 },
        door = { active = false, entity = nil, texture = 0 },
        window = { active = false, entity = nil, texture = 0 },
        outside = { active = false, entity = nil, texture = 0 }
    }
}

local function isLeftMouseButtonPressed(allowHold)
    if IsControlJustReleased(0, 24) or IsDisabledControlJustReleased(0, 24) then
        return true
    end
    if allowHold or (Config and Config.allowMouseHoldToEdit) then
        if IsControlPressed(0, 24) or IsDisabledControlPressed(0, 24) then
            return true
        end
    end
    return false
end

local function isRightMouseButtonPressed(allowHold)
    if IsControlJustReleased(0, 25) or IsDisabledControlJustReleased(0, 25) then
        return true
    end
    if allowHold or (Config and Config.allowMouseHoldToEdit) then
        if IsControlPressed(0, 25) or IsDisabledControlPressed(0, 25) then
            return true
        end
    end
    return false
end

function Tile:new(x, y, z, coords, index)
    local instance = setmetatable({}, self)
    instance.index = index
    instance.id = math.random(0, 999999)
    instance.hidden = false
    instance.x = x
    instance.y = y
    instance.z = z
    instance.coords = coords
    instance.elements = {
        tile = { active = false, entity = nil, texture = "0", color = 0 },
        stairs = { active = false, entity = nil, texture = "0", color = 0, side = "top" },
        decor = { top = {}, bottom = {}, left = {}, right = {} },
        ceiling = { active = false, entity = nil, texture = "0", color = 0 },
        walls = {
            top = table.clone(wallElementTemplate),
            bottom = table.clone(wallElementTemplate),
            left = table.clone(wallElementTemplate),
            right = table.clone(wallElementTemplate)
        }
    }
    instance.preview = table.clone(previewTemplate)
    instance:thread()
    return instance
end

function Tile:thread()
    Citizen.CreateThread(function()
        local lastCamRot = vec3(0, 0, 0)
        local needsRefresh = false
        while self.x and Builder.active do
            local waitTime = 2000
            if Builder.camera and (Builder.options.wallFading or needsRefresh) and not self.hidden then
                waitTime = 500
                local camRot = GetCamRot(Builder.camera)
                if camRot ~= lastCamRot or needsRefresh then
                    needsRefresh = self:refreshWallVisibility()
                    if needsRefresh then
                        waitTime = 20
                    end
                end
                lastCamRot = camRot
            end
            Citizen.Wait(waitTime)
        end
    end)
end

function Tile:debugThread()
    Citizen.CreateThread(function()
        while self.x and Builder.active do
            local waitTime = 200
            if self.elements.tile.active then
                waitTime = 1
                local coords = GetEntityCoords(self.elements.tile.entity)
                local wallDataJson = json.encode(self.elements.walls, { indent = true })

                SetTextScale(0.18, 0.18)
                SetTextFont(4)
                SetTextProportional(true)
                SetTextDropshadow(1, 1, 1, 1, 255)
                SetTextEdge(2, 0, 0, 0, 150)
                SetTextDropShadow()
                SetTextOutline()
                SetTextCentre(false)

                local entryName = "kq_tile_text" .. self.id
                AddTextEntry(entryName, wallDataJson)
                SetTextEntry(entryName)
                SetDrawOrigin(coords, 0)
                DrawText(0.0, 0.0)
                ClearDrawOrigin()
            end
            Citizen.Wait(waitTime)
        end
    end)
end

function Tile:refreshWallVisibility(force)
    if self.hidden then return end
    local camRot = GetCamRot(Builder.camera)
    local isFading = false
    local alphaChange = force and 255 or 50

    for _, wall in pairs(self.elements.walls) do
        if wall.entity then
            local wallRot = GetEntityRotation(wall.entity)
            local wallAlpha = GetEntityAlpha(wall.entity)

            if IsRotationWithinRange(camRot.z, wallRot.z - 90.0, 100) then
                if Builder.options.wallFading then
                    if wallAlpha >= 0 then
                        isFading = true
                        SetEntityAlpha(wall.entity, math.max(0, wallAlpha - alphaChange), false)
                        SetEntityCompletelyDisableCollision(wall.entity, false, false)
                    end
                end
            else
                if not Builder.options.wallFading then
                    ResetEntityAlpha(wall.entity)
                else
                    SetEntityAlpha(wall.entity, math.min(140, wallAlpha + alphaChange), false)
                    if wallAlpha >= 140 then
                        SetEntityAlpha(wall.entity, 140, false)
                        SetEntityCompletelyDisableCollision(wall.entity, true, false)
                    else
                        isFading = true
                    end
                end
            end
        end
    end
    return isFading
end

function Tile:refresh(fullRefresh)
    self:refreshFloorPreview()
    self:refreshWalls()
    if fullRefresh then
        self:refreshFloor()
        self:refreshCeiling()
    end
    if self.hidden then
        self:hideEntities(self.elements)
    end
end

function Tile:isInteractable(hitCoords)
    local tilePos2D = vec3(self.coords.x, self.coords.y, 0.0)
    local hitPos2D = vec3(hitCoords.x, hitCoords.y, 0.0)
    return #(hitPos2D - tilePos2D) < 1.0
end

function Tile:handleInteraction(hitCoords, hitEntity)
    local mode = Builder.mode
    local modes = Builder.modes

    if mode == modes.CEILING then
        if self.elements.tile.active and not Builder.options.demolition then
            self:indicateCeilingInteraction()
            if isLeftMouseButtonPressed(true) then
                Builder:saveUndoState()
                self:setCeilingData(Builder.options.texture, Builder.options.color)
                Builder:refresh()
                Citizen.Wait(50)
            end
        end
        return
    end

    if mode == modes.FLOOR then
        if self.elements.tile.active ~= Builder.options.demolition then
            self:indicateFloorInteraction()
            if isLeftMouseButtonPressed(true) then
                Builder:saveUndoState()
                self:setActive(not self.elements.tile.active)
                self:setTileColor(0, 0)
                Builder:refresh()
                Citizen.Wait(50)
            end
        end
        return
    end

    local wallModes = { modes.WALL, modes.ARCHWAY, modes.HALF_WALL, modes.QUART_WALL, modes.WALL_HOLE, modes.DOORWAY }
    if table.contains(wallModes, mode) then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide then return end
            local wall = self.elements.walls[wallSide]
            if wall.border and mode ~= modes.DOORWAY then return end

            local isDifferentType = wall.type ~= mode
            if Builder.options.demolition == wall.active or (isDifferentType and not Builder.options.demolition) then
                if not Builder.options.demolition then
                    self:indicateSmallWallInteraction(wallSide)
                end
                self:indicateWallInteraction(wallSide)
                if isLeftMouseButtonPressed(true) then
                    Builder:saveUndoState()
                    self:setWallData(wallSide, false, nil)
                    if Builder.options.demolition then
                        self:wipeWall(wallSide)
                        self:setWallData(wallSide, false, nil)
                    else
                        self:setWallData(wallSide, true, mode)
                    end
                    Builder:refresh()
                    Citizen.Wait(50)
                end
            end
        end
        return
    end

    if mode == modes.WALL_WINDOW then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide or not self.elements.walls[wallSide].border then return end
            if (self.elements.walls[wallSide].type == modes.WALL_WINDOW) ~= Builder.options.demolition then return end
            self:indicateWallInteraction(wallSide)
            if isLeftMouseButtonPressed() then
                Builder:saveUndoState()
                if Builder.options.demolition then
                    self:wipeWall(wallSide, true)
                    self:setWallData(wallSide, true, modes.WALL, false, true)
                else
                    self:setWallData(wallSide, true, mode, false, true)
                    self:setWindow(wallSide, true, Builder.options.texture)
                end
                Builder:refresh()
                Citizen.Wait(50)
            end
        end
        return
    end

    if mode == modes.STAIR then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide then return end
            if Builder.options.demolition then
                if not self.elements.stairs.active then return end
                self:indicateStairInteraction(self.elements.stairs.side)
            else
                self:indicateSmallWallInteraction(wallSide)
                self:indicateStairInteraction(wallSide)
            end

            if isLeftMouseButtonPressed() then
                Builder:saveUndoState()
                self:setStairsData(not Builder.options.demolition, Builder.options.texture, Builder.options.color, wallSide)
                Builder:refresh()
                Citizen.Wait(50)
            end
        end
        return
    end

    if mode == modes.DOORFRAME then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide then return end
            local wall = self.elements.walls[wallSide]
            if (not wall.active and not wall.border) or wall.type ~= modes.DOORWAY then return end
            if wall.extras.doorframe.color == Builder.options.color then return end
            local neighbor = self:getNeighbors()[wallSide]
            if neighbor and neighbor.elements.walls[self:flipWallSideTag(wallSide)].extras.doorframe.active then return end

            self:indicateWallInteraction(wallSide)
            if isLeftMouseButtonPressed() then
                Builder:saveUndoState()
                self:setDoorframe(wallSide, true, Builder.options.texture, Builder.options.color)
                Citizen.Wait(50)
            end
        end
        return
    end

    if mode == modes.DOOR then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide then return end
            local wall = self.elements.walls[wallSide]
            if not wall.active and not wall.border then return end
            local neighbor = self:getNeighbors()[wallSide]
            if neighbor and neighbor.elements.walls[self:flipWallSideTag(wallSide)].extras.door.active then return end

            local door = wall.extras.door
            if door.texture == Builder.options.texture and Builder.options.demolition == door.active then return end

            self:indicateWallInteraction(wallSide)
            if isLeftMouseButtonPressed() then
                Builder:saveUndoState()
                if not Builder.options.demolition and wall.type ~= modes.DOORWAY then
                    self:setWallData(wallSide, true, modes.DOORWAY)
                end
                self:setDoor(wallSide, not Builder.options.demolition, Builder.options.texture)
                Citizen.Wait(50)
            end
        end
        return
    end

    if mode == modes.FLOOR_DECOR then
        if not self.elements.tile.active or self.elements.tile.color == Builder.options.color then return end
        self:indicateFloorInteraction(true)
        if isLeftMouseButtonPressed(true) then
            Builder:saveUndoState()
            if not Builder.options.demolition then
                self:setTileColor(Builder.options.color, Builder.options.texture)
            else
                self:setTileColor(0, 0)
            end
            Builder:refresh()
            Citizen.Wait(50)
        end
        return
    end

    if mode == modes.WALL_DECOR then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide then return end
            local wall = self.elements.walls[wallSide]
            if not wall.active and not wall.border then return end

            if hitEntity and Entity(hitEntity).state.kq_sb_tile_outside then
                self:indicateOuterWallInteraction(wallSide, true)
                if isLeftMouseButtonPressed(true) then
                    Builder:saveUndoState()
                    if not Builder.options.demolition then
                        self:setOuterWallColor(wallSide, Builder.options.color, Builder.options.texture, false)
                    else
                        self:setOuterWallColor(wallSide, 0, 0, false)
                    end
                    Builder:refresh()
                    Citizen.Wait(50)
                end
            elseif wall.color ~= Builder.options.color then
                self:indicateWallInteraction(wallSide, true)
                if isLeftMouseButtonPressed(true) then
                    Builder:saveUndoState()
                    if not Builder.options.demolition then
                        self:setWallColor(wallSide, Builder.options.color, Builder.options.texture, false)
                    else
                        self:setWallColor(wallSide, 0, 0, false)
                    end
                    Builder:refresh()
                    Citizen.Wait(50)
                end
            end
        end
        return
    end

    if mode == modes.DECOR then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide then return end
            if not Gizmo.enabled then
                if not Builder.options.demolition then
                    self:indicateSmallWallInteraction(nil)
                    self:indicateDecorInteractionDetailed(wallSide, Builder.options.texture)
                elseif self:hasDecor(wallSide) then
                    self:indicateDecorInteraction(wallSide)
                else
                    return
                end
            end
            if isLeftMouseButtonPressed() then
                if not Gizmo.enabled then
                    Builder:saveUndoState()
                    self:setDecorData(not Builder.options.demolition, Builder.options.texture, Builder.options.color, wallSide)
                    Builder:refresh()
                    Citizen.Wait(50)
                end
            end
            if isRightMouseButtonPressed() then
                if hitEntity and Entity(hitEntity).state.kq_sb_decor then
                    Builder:saveUndoState()
                    if Gizmo.enabled then
                        Gizmo.stop()
                        Citizen.Wait(100)
                    else
                        Gizmo.start(hitEntity, function(newPos, newRot)
                            if #(newPos.xy - self.coords.xy) >= 1.75 then return false end
                            local extra = Entity(hitEntity).state.kq_sb_extra
                            if extra then
                                local offsets = {
                                    pos = self.coords - (GetEntityCoords(hitEntity) or vec3(0, 0, 0)),
                                    rot = GetEntityRotation(hitEntity) or vec3(0, 0, 0)
                                }
                                self:setCustomOffsets(extra.side, extra.texture, offsets)
                            end
                            return true
                        end)
                        Citizen.CreateThread(function()
                            while Gizmo.enabled do
                                DrawKeybinds(("[~y~%s~w~] Position move\n[~y~%s~w~] Rotation mode"):format(GetKeyLabel("+kqGizmoTranslation"), GetKeyLabel("+kqGizmoRotation")), -1)
                                if self then self:indicateFloorInteraction(true) end
                                Citizen.Wait(1)
                            end
                        end)
                    end
                else
                    Gizmo.stop()
                end
                Citizen.Wait(50)
            end
        end
        return
    end

    if mode == modes.SPAWNPOINT then
        if self.elements.tile.active then
            local wallSide = self:getClosestWallInteraction(hitCoords)
            if not wallSide then return end

            self:indicateSmallWallInteraction(wallSide)
            self:indicateDecorInteraction(wallSide)

            if isLeftMouseButtonPressed() then
                Builder:saveUndoState()
                local headings = { top = 0.0, bottom = 180.0, left = 90.0, right = 270.0 }
                Builder:setSpawnPoint(self, headings[wallSide])
                Builder:refresh()
                Citizen.Wait(50)
            end
        end
        return
    end
end

function Tile:delete()
    self.x = nil
    self:deletePreview()
    self:wipeWalls()
    self:deleteCeiling()
    self:deleteEntity()
    self:deleteStairs()
    self:deleteDecor()
end

function Tile:getSaveData()
    local saveData = {}
    local currentElements = table.clone(self.elements)

    if currentElements.tile.active then
        saveData.tile = currentElements.tile
        saveData.tile.active = nil
        saveData.tile.entity = nil
    end

    if currentElements.stairs and currentElements.stairs.active then
        saveData.stairs = currentElements.stairs
        saveData.stairs.active = nil
        saveData.stairs.entity = nil
    end

    saveData.ceiling = currentElements.ceiling
    saveData.ceiling.entity = nil
    saveData.ceiling.active = nil

    saveData.decor = {}
    for side, decors in pairs(currentElements.decor) do
        for key, decorItem in pairs(decors) do
            if decorItem.active then
                if not saveData.decor[side] then saveData.decor[side] = {} end
                saveData.decor[side][key] = decorItem
                decorItem.active = nil
                decorItem.entity = nil
            end
        end
    end
    if table.length(saveData.decor) == 0 then saveData.decor = nil end

    saveData.walls = {}
    for side, wall in pairs(currentElements.walls) do
        if wall.active or wall.border then
            saveData.walls[side] = {
                active = nil,
                border = wall.border,
                type = wall.type,
                color = wall.color,
                texture = wall.texture,
                extras = {}
            }
            if wall.extras.doorframe.active then
                saveData.walls[side].extras.doorframe = wall.extras.doorframe
                saveData.walls[side].extras.doorframe.active = nil
                saveData.walls[side].extras.doorframe.entity = nil
            end
            if wall.extras.door.active then
                saveData.walls[side].extras.door = wall.extras.door
                saveData.walls[side].extras.door.entity = nil
                saveData.walls[side].extras.door.active = nil
            end
            if wall.extras.window.active then
                saveData.walls[side].extras.window = wall.extras.window
                saveData.walls[side].extras.window.entity = nil
                saveData.walls[side].extras.window.active = nil
            end
            if wall.extras.outside.active then
                saveData.walls[side].extras.outside = wall.extras.outside
                saveData.walls[side].extras.outside.entity = nil
                saveData.walls[side].extras.outside.active = nil
            end
            if table.length(saveData.walls[side].extras) == 0 then
                saveData.walls[side].extras = nil
            end
        end
    end
    if table.length(saveData.walls) == 0 then saveData.walls = nil end

    return saveData
end

function Tile:setData(data)
    self:deletePreview()
    self:wipeWalls()
    self:deleteEntity()

    local newData = table.clone(data)
    if newData.tile then newData.tile.active = true end
    if newData.stairs then newData.stairs.active = true end
    if newData.ceiling then newData.ceiling.active = true end

    for _, wall in pairs(newData.walls or {}) do
        if not wall.border then wall.active = true end
        if wall.extras then
            if wall.extras.doorframe then wall.extras.doorframe.active = true end
            if wall.extras.door then wall.extras.door.active = true end
            if wall.extras.window then wall.extras.window.active = true end
            if wall.extras.outside then wall.extras.outside.active = true end
        end
    end
    for _, decors in pairs(newData.decor or {}) do
        for _, decorItem in pairs(decors or {}) do
            decorItem.active = true
        end
    end

    table.merge(self.elements, newData)
    self:recursiveWipeEntityIds(self.elements)
end