function Tile:recursiveWipeEntityIds(data)
    for key, value in pairs(data) do
        if type(value) == "table" then
            self:recursiveWipeEntityIds(value)
        end
        if key == "entity" then
            data[key] = nil
        end
    end
    return data
end

function Tile:getAllEntities(elements)
    local entities = {}
    for key, value in pairs(elements) do
        if type(value) == "table" then
            local subEntities = self:getAllEntities(value)
            for _, entity in ipairs(subEntities) do
                table.insert(entities, entity)
            end
        elseif key == "entity" and value and DoesEntityExist(value) then
            table.insert(entities, value)
        end
    end
    return entities
end

function Tile:hideEntities()
    self.hidden = true
    local allEntities = self:getAllEntities(self.elements)
    for _, entity in ipairs(allEntities) do
        ResetEntityAlpha(entity)
        SetEntityVisible(entity, false, 0)
        SetEntityCollision(entity, false, true)
    end
    if Builder.options.level + 1 == self.z and Builder.mode == Builder.modes.STAIR then
        SetEntityVisible(self.elements.tile.entity, true)
        SetEntityAlpha(self.elements.tile.entity, 80, 1)
    end
    self:refreshFloorPreview()
end

function Tile:showEntities()
    self.hidden = false
    local allEntities = self:getAllEntities(self.elements)
    for _, entity in ipairs(allEntities) do
        ResetEntityAlpha(entity)
        SetEntityVisible(entity, true, 0)
        SetEntityCollision(entity, true, true)
    end
    if self.elements.tile.active and self.elements.tile.texture == "none" then
        SetEntityAlpha(self.elements.tile.entity, 0)
    end
    self:refreshCeiling()
    self:refreshFloorPreview()
end

function Tile:getSpawnData(onlyTile)
    local entitiesToProcess
    if onlyTile then
        entitiesToProcess = self:getAllEntities({ self.elements.tile })
    else
        local elementsClone = table.clone(self.elements)
        elementsClone.tile = nil
        entitiesToProcess = self:getAllEntities(elementsClone)
    end

    local spawnData = {}
    for _, entity in ipairs(entitiesToProcess) do
        local textureVariation = GetObjectTextureVariation(entity)

        local relativeCoordsVec = CompressVector(GetEntityCoords(entity) - Builder.centerCoords)
        if relativeCoordsVec.x and math.abs(relativeCoordsVec.x) < 0.001 then relativeCoordsVec.x = nil end
        if relativeCoordsVec.y and math.abs(relativeCoordsVec.y) < 0.001 then relativeCoordsVec.y = nil end
        if relativeCoordsVec.z and math.abs(relativeCoordsVec.z) < 0.001 then relativeCoordsVec.z = nil end
        local positionString = table.concat({ relativeCoordsVec.x or 0, relativeCoordsVec.y or 0, relativeCoordsVec.z or 0 }, ",")
        local position = (positionString == "0,0,0") and 0 or positionString

        local rotationVec = CompressVector(GetEntityRotation(entity))
        if rotationVec.z and math.abs(rotationVec.z) < 0.001 then rotationVec.z = nil end
        local rotationString = table.concat({ rotationVec.x or 0, rotationVec.y or 0, rotationVec.z or 0 }, ",")
        local rotation = (rotationString == "0,0,0") and 0 or rotationString
        
        local isPositionFrozen, isRotationFrozen = IsEntityPositionFrozen(entity)

        table.insert(spawnData, {
            GetEntityModel(entity),
            textureVariation,
            position,
            rotation,
            isPositionFrozen,
            isRotationFrozen
        })
    end
    return spawnData
end

function Tile:hasAnyNeighbors()
    local neighbors = self:getNeighbors()
    for _, neighborTile in pairs(neighbors) do
        if neighborTile and neighborTile.elements.tile.active then
            return true
        end
    end
    return false
end

function Tile:getNeighbors()
    local x, y, z = self.x, self.y, self.z
    local neighbors = {}
    neighbors.top = Builder.findTile(x, y + 1, z) or false
    neighbors.bottom = Builder.findTile(x, y - 1, z) or false
    neighbors.right = Builder.findTile(x + 1, y, z) or false
    neighbors.left = Builder.findTile(x - 1, y, z) or false
    return neighbors
end

function Tile:getTileUnder()
    return Builder.findTile(self.x, self.y, self.z - 1) or false
end

function Tile:getTileAbove()
    return Builder.findTile(self.x, self.y, self.z + 1) or false
end

function Tile:flipWallSideTag(side)
    local opposites = {
        top = "bottom",
        bottom = "top",
        left = "right",
        right = "left"
    }
    return opposites[side]
end

function Tile:isStairTile()
    if self.elements.stairs.active then
        return true
    end
    local neighborTile, neighborSide = self:getNeighborWithStairs()
    if neighborTile and neighborTile.elements.stairs.active then
        return neighborTile.elements.stairs.side == self:flipWallSideTag(neighborSide)
    end
    return false
end

function Tile:getNeighborWithStairs()
    local neighbors = self:getNeighbors()
    for side, tile in pairs(neighbors) do
        if tile and tile.elements.stairs.active then
            return tile, side
        end
    end
    return false
end

function Tile:getClosestWallInteraction(position)
    local interactionPoints = {
        top = self.coords + vector3(0, 1, 0),
        bottom = self.coords + vector3(0, -1, 0),
        left = self.coords + vector3(-1, 0, 0),
        right = self.coords + vector3(1, 0, 0)
    }

    local minDistance = 1.5
    local closestSide = nil
    for side, pointCoords in pairs(interactionPoints) do
        local distance = #(pointCoords.xy - position.xy)
        if minDistance > distance then
            minDistance = distance
            closestSide = side
        end
    end
    return closestSide, minDistance
end

function Tile:getClosestDecorInteraction(position)
    local decorPoints = {
        top_l = self.coords + vector3(-0.5, 1, 0),
        top_m = self.coords + vector3(0, 1, 0),
        top_r = self.coords + vector3(0.5, 1, 0),
        bottom_l = self.coords + vector3(0.5, -1, 0),
        bottom_m = self.coords + vector3(0, -1, 0),
        bottom_r = self.coords + vector3(-0.5, -1, 0),
        left_l = self.coords + vector3(-1, -0.5, 0),
        left_m = self.coords + vector3(-1, 0, 0),
        left_r = self.coords + vector3(-1, 0.5, 0),
        right_l = self.coords + vector3(1, 0.5, 0),
        right_m = self.coords + vector3(1, 0, 0),
        right_r = self.coords + vector3(1, -0.5, 0)
    }

    local minDistance = 1.0
    local closestPointName = nil
    for pointName, pointCoords in pairs(decorPoints) do
        local distance = #(pointCoords.xy - position.xy)
        if minDistance > distance then
            minDistance = distance
            closestPointName = pointName
        end
    end

    local closestPointCoords = decorPoints[closestPointName]
    return closestPointName, minDistance, closestPointCoords
end