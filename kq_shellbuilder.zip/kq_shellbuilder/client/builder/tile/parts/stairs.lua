function Tile:setStairsData(isActive, texture, color, side)
    local stairs = self.elements.stairs
    stairs.active = isActive
    stairs.texture = texture
    stairs.color = color
    stairs.side = side

    self:refreshStairs()

    local tileAbove = self:getTileAbove()
    if tileAbove then
        tileAbove:refreshFloor()
        for _, neighbor in pairs(tileAbove:getNeighbors()) do
            if neighbor then
                neighbor:refresh(true)
            end
        end
    else
        Debug("no tile above found")
    end
end

function Tile:refreshStairs()
    if self.elements.stairs.active then
        self:createStairs()
    else
        self:deleteStairs()
    end
end

function Tile:createStairs()
    self:deleteStairs()

    local stairsInfo = Settings.stairs[tostring(self.elements.stairs.texture)]
    local model = stairsInfo.model or "kq_sb_stairs_1"

    DoRequestModel(model)
    local stairObj = CreateObjectNoOffset(model, self.coords, false, true, false)
    Entity(stairObj).state.kq_sb_tile = self.index

    local headings = {
        top = 0.0,
        bottom = 180.0,
        right = 270.0,
        left = 90.0
    }

    SetEntityInvincible(stairObj, true)
    local heading = headings[self.elements.stairs.side] or 0.0
    SetEntityHeading(stairObj, heading)

    local color = self.elements.stairs.color or 0
    SetObjectTextureVariation(stairObj, color)
    FreezeEntityPosition(stairObj, true)
    self.elements.stairs.entity = stairObj
end

function Tile:deleteStairs()
    local stairEntity = self.elements.stairs.entity
    if stairEntity and DoesEntityExist(stairEntity) then
        DeleteEntity(stairEntity)
    end
    self.elements.stairs.entity = nil
end