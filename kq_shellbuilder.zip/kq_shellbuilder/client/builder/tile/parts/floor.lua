function Tile:setCeilingData(texture, color)
    self.elements.ceiling.color = color
    self.elements.ceiling.texture = texture
    self:refreshCeiling()
end

function Tile:setTileColor(color, texture)
    self.elements.tile.color = color
    self.elements.tile.texture = texture
    Debug("call from Tile:setTileColor")
    self:refreshFloor()
end

function Tile:setActive(isActive)
    self.elements.tile.active = isActive
    Debug("call from Tile:setActive")
    if not isActive then
        self.elements.tile.color = 0
        self:refreshFloor(true)
    end
end

function Tile:refreshFloor(forceNeighborUpdate)
    if not self.elements.tile.active then
        self:deleteEntity()
        self:deleteCeiling()
        for side, _ in pairs(self.elements.walls) do
            self.elements.walls[side].active = false
            local neighbor = self:getNeighbors()[side]
            local oppositeSide = self:flipWallSideTag(side)
            if neighbor and neighbor.elements.walls[oppositeSide].active and forceNeighborUpdate then
                Debug("Call A from Tile:refreshFloor")
                neighbor:setWallData(oppositeSide, false, nil, true, false)
            end
        end
    else
        self:deleteEntity()
        if self:shouldHaveFloor() then
            self:createFloor()
        end
        self:refreshCeiling()
    end

    for side, _ in pairs(self.elements.walls) do
        local neighbor = self:getNeighbors()[side]
        local oppositeSide = self:flipWallSideTag(side)
        if neighbor and neighbor.elements.walls[oppositeSide].active and not self.elements.walls[side].active then
            Debug("Call B from Tile:refreshFloor")
            local wallType = neighbor.elements.walls[oppositeSide].type
            neighbor:setWallData(oppositeSide, true, wallType, false, false)
        end
    end
end

function Tile:refreshCeiling()
    if self.elements.tile.active then
        if self:shouldHaveCeiling() then
            self:createCeiling()
        else
            self:deleteCeiling()
        end
    else
        self:deleteCeiling()
    end
end

function Tile:shouldHaveFloor()
    if self.elements.tile.texture == "none" then
        if not Builder.options.testMode and not Builder.saving then
            return true
        end
        return false
    end
    local tileUnder = self:getTileUnder()
    return not tileUnder or not tileUnder:shouldHaveCeiling()
end

function Tile:shouldHaveCeiling()
    local tileAbove = self:getTileAbove()
    if not tileAbove or not tileAbove.elements.tile.active then
        return true
    end
    if tileAbove.elements.tile.texture == "none" then
        return false
    end
    return not self:isStairTile()
end

function Tile:createFloor()
    local textureId = tostring(self.elements.tile.texture or 0)
    local floorSettings = Settings.floors[textureId]
    local modelName = "kq_sb_tile_" .. floorSettings.model

    DoRequestModel(modelName)
    self:deleteEntity()

    local spawnPos = self.coords + (floorSettings.offset or vec3(0, 0, 0))
    local entity = CreateObjectNoOffset(modelName, spawnPos, false, true, false)

    SetEntityHeading(entity, 90.0)
    SetEntityInvincible(entity, true)
    FreezeEntityPosition(entity, true)
    SetObjectTextureVariation(entity, self.elements.tile.color or 0)

    Entity(entity).state.kq_sb_tile = self.index

    if self.elements.tile.texture == "none" then
        SetEntityVisible(entity, false, 0)
    end

    self.elements.tile.entity = entity
end

function Tile:createCeiling()
    local textureId = tostring(self.elements.ceiling.texture or "0")
    local ceilingSettings = Settings.ceilings[textureId]
    local modelName = ceilingSettings.model or "kq_sb_ceil"
    local offset = ceilingSettings.offset or { pos = vec3(0, 0, 0), rotation = vec3(0, 0, 0) }

    DoRequestModel(modelName)
    self:deleteCeiling()

    local spawnPos = self.coords + offset.pos + vec3(0, 0, -0.01)
    local entity = CreateObjectNoOffset(modelName, spawnPos, false, true, false)

    SetEntityHeading(entity, 90.0)
    SetEntityRotation(entity, offset.rotation)
    SetEntityInvincible(entity, true)
    FreezeEntityPosition(entity, true)
    SetObjectTextureVariation(entity, self.elements.ceiling.color)

    Entity(entity).state.kq_sb_tile = self.index
    self.elements.ceiling.entity = entity

    local isVisible = not (not Builder.options.testMode and not Builder.saving and not Builder.takingThumbnail)
    SetEntityVisible(entity, isVisible, 0)
    SetEntityCollision(entity, isVisible, 0)
end

function Tile:deleteEntity()
    local entity = self.elements.tile.entity
    if entity and DoesEntityExist(entity) then
        DeleteEntity(entity)
    end
end

function Tile:deleteCeiling()
    local entity = self.elements.ceiling.entity
    if entity and DoesEntityExist(entity) then
        DeleteEntity(entity)
    end
end