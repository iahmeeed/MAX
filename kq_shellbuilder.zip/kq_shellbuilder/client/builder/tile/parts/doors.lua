function Tile:setDoorframe(side, isActive, texture, color)
    local doorframe = self.elements.walls[side].extras.doorframe
    doorframe.active = isActive
    if texture then
        doorframe.texture = texture
    end
    if color then
        doorframe.color = color
    end
    Debug("set frame", isActive)
    self:refreshExtras()
end

function Tile:setDoor(side, isActive, texture)
    local door = self.elements.walls[side].extras.door
    door.active = isActive
    door.texture = texture
    Debug("set door", isActive)
    self:refreshExtras()
end

function Tile:setWindow(side, isActive, texture)
    local window = self.elements.walls[side].extras.window
    window.active = isActive
    window.texture = texture
    Debug("set window", isActive)
    self:refreshExtras()
end

function Tile:refreshExtras()
    for side, wall in pairs(self.elements.walls) do
        if wall.extras.doorframe.active then
            if wall.texture ~= "14" then
                self:createDoorframe(side)
            end
        else
            self:deleteDoorframe(side)
        end

        if wall.extras.door.active then
            self:createDoor(side)
        else
            self:deleteDoor(side)
        end

        if wall.extras.window.active then
            self:createWindow(side)
        else
            self:deleteWindow(side)
        end
    end
end

function Tile:createDoorframe(side)
    self:deleteDoorframe(side)
    local headings = { top = 270.0, bottom = 90.0, left = 0.0, right = 180.0 }
    local model = "kq_sb_doorframe_1"
    DoRequestModel(model)

    local pos = self.coords + vec3(0.0, 0.0, -0.01)
    local doorframeObj = CreateObjectNoOffset(model, pos, false, true, false)

    Entity(doorframeObj).state.kq_sb_tile = self.index
    SetEntityInvincible(doorframeObj, true)
    SetEntityHeading(doorframeObj, headings[side])

    local color = self.elements.walls[side].extras.doorframe.color or 0
    Debug(color)
    SetObjectTextureVariation(doorframeObj, color)
    FreezeEntityPosition(doorframeObj, true)
    self.elements.walls[side].extras.doorframe.entity = doorframeObj
end

function Tile:deleteDoorframe(side)
    self:deleteDoor(side)
    local doorframe = self.elements.walls[side].extras.doorframe
    if doorframe.entity and DoesEntityExist(doorframe.entity) then
        DeleteEntity(doorframe.entity)
    end
    doorframe.entity = nil
end

function Tile:createDoor(side)
    self:deleteDoor(side)
    local headings = { top = 0.0, bottom = 180.0, left = 90.0, right = 270.0 }
    local offsets = {
        top = vec3(-0.65, 1.0, 0.01),
        bottom = vec3(0.65, -1.0, 0.01),
        left = vec3(-1.0, -0.65, 0.01),
        right = vec3(1.0, 0.65, 0.01)
    }

    local doorTextureId = tostring(self.elements.walls[side].extras.door.texture)
    local doorInfo = Settings.doors[doorTextureId]
    local model = doorInfo.model or "v_ilev_janitor_frontdoor"

    if doorInfo.flipped then
        offsets = {
            top = vec3(0.65, 1.0, 0.006),
            bottom = vec3(-0.65, -1.0, 0.006),
            left = vec3(-1.0, 0.65, 0.006),
            right = vec3(1.0, -0.65, 0.006)
        }
    end

    DoRequestModel(model)
    local pos = self.coords + offsets[side]
    local doorObj = CreateObject(model, pos, false, true, false)

    if self.elements.walls[side].border then
        FreezeEntityPosition(doorObj, true)
    else
        local doorId = self:getUniqueDoorId(headings[side])
        AddDoorToSystem(doorId, GetEntityModel(doorObj), GetEntityCoords(doorObj))
        DoorSystemSetDoorState(doorId, 0, false, true)
        Entity(doorObj).state.kq_door_id = doorId
    end

    Entity(doorObj).state.kq_sb_tile = self.index
    SetEntityInvincible(doorObj, true)
    SetEntityHeading(doorObj, headings[side])
    self.elements.walls[side].extras.door.entity = doorObj
end

function Tile:deleteDoor(side)
    local door = self.elements.walls[side].extras.door
    if door.entity and DoesEntityExist(door.entity) then
        DeleteEntity(door.entity)
    end
    door.entity = nil
end

function Tile:getUniqueDoorId(heading)
    local prefix = 0
    if self.x <= 0 then prefix = 200 end
    if self.y <= 0 then prefix = tonumber(prefix .. "200") end

    local idString = (4000 + self.index) .. math.abs(self.x) .. math.abs(self.y) .. heading
    return math.floor(tonumber(idString))
end

function Tile:createWindow(side)
    self:deleteWindow(side)
    local headings = { top = 270.0, bottom = 90.0, left = 0.0, right = 180.0 }
    local windowTextureId = tostring(self.elements.walls[side].extras.window.texture)
    local model = Settings.windows[windowTextureId].model or "kq_sb_window_2"

    DoRequestModel(model)
    local windowObj = CreateObjectNoOffset(model, self.coords, false, true, false)
    Entity(windowObj).state.kq_sb_tile = self.index
    SetEntityInvincible(windowObj, true)
    SetEntityHeading(windowObj, headings[side])
    SetEntityCoords(windowObj, GetOffsetFromEntityInWorldCoords(windowObj, vec3(-0.001, 0.0, 0.0)))
    FreezeEntityPosition(windowObj, true)
    self.elements.walls[side].extras.window.entity = windowObj
end

function Tile:deleteWindow(side)
    local window = self.elements.walls[side].extras.window
    if window.entity and DoesEntityExist(window.entity) then
        DeleteEntity(window.entity)
    end
    window.entity = nil
end