function Tile:setDecorData(isActive, textureName, colorIndex, side, offsets)
    if not isActive then
        local wasActive = false
        for name, data in pairs(self.elements.decor[side]) do
            if name == textureName and data.active then
                data.active = false
                data.offsets = nil
                wasActive = true
            end
        end
        if not wasActive then
            for name, data in pairs(self.elements.decor[side]) do
                data.active = false
                data.offsets = nil
            end
        end
    else
        if not self.elements.decor[side][textureName] then
            self.elements.decor[side][textureName] = {}
        end
        local decorData = self.elements.decor[side][textureName]
        decorData.active = true
        decorData.color = colorIndex
        decorData.offsets = offsets
    end
    self:refreshDecor()
end

function Tile:setCustomOffsets(side, textureName, offsets)
    self.elements.decor[side][textureName].offsets = offsets
end

function Tile:refreshDecor()
    for side, sideDecor in pairs(self.elements.decor) do
        for textureName, decorData in pairs(sideDecor) do
            if decorData and decorData.active then
                self:createDecor(side, textureName)
            else
                self:deleteDecor(side, textureName)
            end
        end
    end
end

function Tile:hasDecor(side)
    for _, decorData in pairs(self.elements.decor[side]) do
        if decorData.active then
            return true
        end
    end
    return false
end

function Tile:createDecor(side, textureName)
    local decorSettings = Settings.decor[textureName]
    self:deleteDecor(side, textureName)
    if not decorSettings then return end

    local modelHash = decorSettings.model
    if not DoRequestModel(modelHash) then return end

    local headings = { top = 0.0, bottom = 180.0, right = 270.0, left = 90.0 }
    local customOffsets = self.elements.decor[side][textureName].offsets
    local entity

    if customOffsets then
        customOffsets.pos = vec3(customOffsets.pos.x, customOffsets.pos.y, customOffsets.pos.z)
        customOffsets.rot = vec3(customOffsets.rot.x, customOffsets.rot.y, customOffsets.rot.z)
        local spawnPos = self.coords - (customOffsets.pos or vec3(0, 0, 0))
        entity = CreateObjectNoOffset(modelHash, spawnPos, false, true, false)
        SetEntityRotation(entity, customOffsets.rot or vec3(0, 0, 0))
    else
        local offset = decorSettings.offset or { pos = vec3(0, 0, 0), heading = 0 }
        if decorSettings.randomizeOffset then
            math.randomseed(tonumber(self.x + self.y + self.z))
            offset.pos = offset.pos + vec3(math.random(-40, 40) / 100, math.random(-40, 40) / 100, 0.01)
            offset.heading = offset.heading + math.random(-30, 30)
        end
        local correctedOffset = GetCorrectedOffset(offset.pos or vec3(0, 0, 0), side)
        local spawnPos = self.coords + correctedOffset
        entity = CreateObjectNoOffset(modelHash, spawnPos, false, true, false)

        if offset.rot then
            local baseRotation = offset.rot + vec3(0, 0, headings[side] or 0.0)
            SetEntityRotation(entity, baseRotation)
        else
            local totalHeading = (headings[side] or 0.0) + (offset.heading or 0.0)
            SetEntityHeading(entity, totalHeading)
        end
    end

    local entityState = Entity(entity).state
    entityState.kq_sb_tile = self.index
    entityState.kq_sb_decor = true
    entityState.kq_sb_extra = { side = side, texture = textureName }

    SetEntityInvincible(entity, true)
    local colorIndex = self.elements.decor[side][textureName].color
    SetObjectTextureVariation(entity, colorIndex)
    local colorRgb = Settings.colors[colorIndex]
    SetObjectLightColor(entity, 1, colorRgb.r, colorRgb.g, colorRgb.b)
    FreezeEntityPosition(entity, true)
    self.elements.decor[side][textureName].entity = entity
    SetModelAsNoLongerNeeded(modelHash)
end

function Tile:deleteDecor(side, textureName)
    if not side then
        for sideName, _ in pairs(self.elements.decor) do
            self:deleteDecor(sideName)
        end
        return
    end

    if not textureName then
        for name, _ in pairs(self.elements.decor[side]) do
            self:deleteDecor(side, name)
        end
        return
    end

    local decorData = self.elements.decor[side] and self.elements.decor[side][textureName]
    if not decorData then return end

    local entity = decorData.entity
    if entity and DoesEntityExist(entity) then
        DeleteEntity(entity)
    end

    if decorData.entity then
        decorData.entity = nil
    end
end