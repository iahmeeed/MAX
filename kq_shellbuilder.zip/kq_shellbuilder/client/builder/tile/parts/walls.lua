function Tile:refreshWalls()
    if not self.elements.tile.active then
        self:wipeWalls()
        return
    end

    local neighbors = self:getNeighbors()
    local borderStatus = {}
    for side, neighborTile in pairs(neighbors) do
        borderStatus[side] = not neighborTile or not neighborTile.elements.tile.active
    end

    local headings = { top = 270.0, bottom = 90.0, left = 0.0, right = 180.0 }
    for side, wallData in pairs(self.elements.walls) do
        if wallData.active or borderStatus[side] then
            self:deleteWall(side)

            local textureId = tostring(wallData.texture or 0)
            local wallSettings = Settings.walls[textureId] or Settings.walls["1"]
            local modelName = self:getWallModel(wallData.type, wallSettings.model)

            DoRequestModel(modelName)
            local entity = CreateObjectNoOffset(modelName, self.coords, false, true, false)

            SetObjectTextureVariation(entity, wallData.color or 0)
            Entity(entity).state.kq_sb_tile = self.index
            SetEntityInvincible(entity, true)
            SetEntityHeading(entity, headings[side])
            FreezeEntityPosition(entity, true)

            wallData.entity = entity
            wallData.border = borderStatus[side]
        else
            if wallData.entity then
                self:wipeWall(side)
            end
        end
    end

    self:refreshWallVisibility(true)
    self:refreshExtras()
end

function Tile:setWallColor(side, color, texture)
    local wallData = self.elements.walls[side]
    wallData.color = color
    wallData.texture = texture
    self:refreshWalls()
end

function Tile:setWallData(side, isActive, wallType, isRecursiveCall, isBorder)
    if not isActive and not isBorder then
        self:wipeWall(side)
    end

    local wallData = self.elements.walls[side]
    if isBorder then
        wallData.border = true
        wallData.active = false
    else
        wallData.active = isActive
    end
    wallData.type = wallType

    if not isRecursiveCall then
        local neighbor = self:getNeighbors()[side]
        if neighbor then
            local oppositeSide = self:flipWallSideTag(side)
            neighbor:setWallData(oppositeSide, isActive, wallType, true, isBorder)
            local neighborWall = neighbor.elements.walls[oppositeSide]
            neighbor:setWallColor(oppositeSide, neighborWall.color, neighborWall.texture)
        end
    end

    self:refreshWalls()

    if not isRecursiveCall then
        if wallType == Builder.modes.DOORWAY then
            self:setDoorframe(side, isActive)
        else
            self:setDoorframe(side, false)
        end
    end
end

function Tile:deleteWall(side)
    local wall = self.elements.walls[side]
    if wall and wall.entity and DoesEntityExist(wall.entity) then
        DeleteEntity(wall.entity)
    end
end

function Tile:wipeWall(side, preserveData)
    self:deleteWall(side)
    
    local wallData = self.elements.walls[side]
    for extraName, extraData in pairs(wallData.extras) do
        self:deleteWindow(side)
        self:deleteDoorframe(side)
        self:deleteDoor(side)
        if extraData.entity and DoesEntityExist(extraData.entity) then
            DeleteEntity(extraData.entity)
        end
        extraData.active = false
        extraData.entity = nil
        if not preserveData then
            extraData.color = 0
            extraData.texture = nil
        end
    end

    if wallData.entity and DoesEntityExist(wallData.entity) then
        DeleteEntity(wallData.entity)
    end
    
    wallData.entity = nil
    wallData.border = false
    wallData.active = false
    if not preserveData then
        wallData.color = 0
        wallData.texture = nil
        wallData.type = Builder.modes.WALL
    end
end

function Tile:wipeWalls()
    for side, _ in pairs(self.elements.walls) do
        self:wipeWall(side)
    end
end

function Tile:getWallModel(wallType, modelId)
    local prefixes = {
        [Builder.modes.WALL] = "kq_sb_wall_",
        [Builder.modes.ARCHWAY] = "kq_sb_arch_",
        [Builder.modes.DOORWAY] = "kq_sb_doorway_",
        [Builder.modes.HALF_WALL] = "kq_sb_halfwall_",
        [Builder.modes.QUART_WALL] = "kq_sb_quartwall_",
        [Builder.modes.WALL_WINDOW] = "kq_sb_wall_window_",
        [Builder.modes.WALL_HOLE] = "kq_sb_wall_window_"
    }
    local type = wallType or Builder.modes.WALL
    local modelName = (prefixes[type] or "kq_sb_wall_") .. modelId

    if not IsModelValid(modelName) then
        return "kq_sb_wall_1"
    end
    return modelName
end

function Tile:createOuterWall(side)
    self:deleteOuterWall(side)

    local headings = { top = 90.0, bottom = 270.0, left = 180.0, right = 0.0 }
    local outsideExtra = self.elements.walls[side].extras.outside
    local textureId = tostring(outsideExtra.texture or 0)
    local wallSettings = Settings.walls[textureId] or Settings.walls["1"]
    local modelName = self:getWallModel(self.elements.walls[side].type, wallSettings.model)

    DoRequestModel(modelName)
    local entity = CreateObjectNoOffset(modelName, self.coords, false, true, false)

    SetObjectTextureVariation(entity, outsideExtra.color or 0)
    Entity(entity).state.kq_sb_tile = self.index
    Entity(entity).state.kq_sb_tile_outside = true
    SetEntityInvincible(entity, true)
    SetEntityHeading(entity, headings[side])
    SetEntityCoords(entity, GetOffsetFromEntityInWorldCoords(entity, vec3(2.001, 0, 0)))
    FreezeEntityPosition(entity, true)

    outsideExtra.entity = entity
    outsideExtra.active = true
end

function Tile:setOuterWallColor(side, color, texture)
    local outsideExtra = self.elements.walls[side].extras.outside
    outsideExtra.color = color
    outsideExtra.texture = texture
end

function Tile:deleteOuterWall(side)
    local outsideExtra = self.elements.walls[side].extras.outside
    if outsideExtra.entity and DoesEntityExist(outsideExtra.entity) then
        DeleteEntity(outsideExtra.entity)
    end
    outsideExtra.entity = nil
    outsideExtra.active = false
end