function Tile:refreshFloorPreview()
    if self:shouldTileBePreview() then
        if not self.preview.tile then
            local model = "kq_sb_tile_transp"
            DoRequestModel(model)
            local previewObj = CreateObjectNoOffset(model, self.coords, false, true, false)
            FreezeEntityPosition(previewObj, true)
            self.preview.tile = previewObj
            SetObjectTextureVariation(previewObj, 0)
            SetEntitySize(previewObj, 0.9)
        end
    else
        if self.preview.tile then
            self:deletePreview()
        end
    end
end

function Tile:deletePreview()
    if self.preview.tile and DoesEntityExist(self.preview.tile) then
        DeleteEntity(self.preview.tile)
        self.preview.tile = nil
    end
end

function Tile:shouldTileBePreview()
    if Builder.mode == Builder.modes.FLOOR and Builder.options.level == self.z then
        return not self.elements.tile.active
    end
    return false
end

function Tile:indicateFloorInteraction(isFull)
    local color = { 0, 255, 25, 150 }
    if Builder.options.demolition then
        color = { 255, 0, 0, 155 }
    end

    local size = isFull and 1.0 or 0.9
    local minCoords = self.coords + vec3(-size, -size, -0.02)
    local maxCoords = self.coords + vec3(size, size, 0.02)

    DrawBox(minCoords, maxCoords, table.unpack(color))
end

function Tile:indicateCeilingInteraction()
    local color = { 0, 255, 25, 150 }
    if Builder.options.demolition then
        color = { 255, 0, 0, 155 }
    end

    local minCoords = self.coords + vec3(-1.0, -1.0, 2.95)
    local maxCoords = self.coords + vec3(1.0, 1.0, 3.15)

    DrawBox(minCoords, maxCoords, table.unpack(color))
end

function Tile:indicateLightInteraction()
    local color = { 0, 255, 25, 150 }
    if Builder.options.demolition then
        color = { 255, 0, 0, 155 }
    end
    local size = 0.2

    local minCoords = self.coords + vec3(-size, -size, 3.0)
    local maxCoords = self.coords + vec3(size, size, 3.0)

    DrawBox(minCoords, maxCoords, table.unpack(color))
end

function Tile:indicateWallInteraction(side, isSmall)
    local thickness = isSmall and 0.11 or 0.2
    local heightMultiplier = 1.0
    local wall = self.elements.walls[side]

    if (wall and wall.type == Builder.modes.HALF_WALL) or (not Builder.options.demolition and Builder.mode == Builder.modes.HALF_WALL) then
        heightMultiplier = 0.43
    end
    if (wall and wall.type == Builder.modes.QUART_WALL) or (not Builder.options.demolition and Builder.mode == Builder.modes.QUART_WALL) then
        heightMultiplier = 0.3
    end

    local boxes = {
        top = { self.coords + vec3(1.1, 0.9 + thickness, 0.0), self.coords + vec3(-1.1, 0.9, 3.1 * heightMultiplier) },
        bottom = { self.coords + vec3(-1.1, - (0.9 + thickness), 0.0), self.coords + vec3(1.1, -0.9, 3.1 * heightMultiplier) },
        left = { self.coords + vec3(- (0.9 + thickness), -1.1, 0.0), self.coords + vec3(-0.9, 1.1, 3.1 * heightMultiplier) },
        right = { self.coords + vec3(0.9 + thickness, 1.1, 0.0), self.coords + vec3(0.9, -1.1, 3.1 * heightMultiplier) }
    }

    local color = { 0, 255, 25, 150 }
    if Builder.options.demolition then
        color = { 255, 0, 0, 155 }
    end

    DrawBox(boxes[side][1], boxes[side][2], table.unpack(color))
end

function Tile:indicateOuterWallInteraction(side, isSmall)
    local thickness = isSmall and 0.11 or 0.2
    local heightMultiplier = 1.0
    local wall = self.elements.walls[side]

    if (wall and wall.type == Builder.modes.HALF_WALL) or (not Builder.options.demolition and Builder.mode == Builder.modes.HALF_WALL) then
        heightMultiplier = 0.43
    end
    if (wall and wall.type == Builder.modes.QUART_WALL) or (not Builder.options.demolition and Builder.mode == Builder.modes.QUART_WALL) then
        heightMultiplier = 0.3
    end

    local boxes = {
        top = { self.coords + vec3(1.1, 1.1 + thickness, 0.0), self.coords + vec3(-1.1, 1.1, 3.1 * heightMultiplier) },
        bottom = { self.coords + vec3(-1.1, - (1.1 + thickness), 0.0), self.coords + vec3(1.1, -1.1, 3.1 * heightMultiplier) },
        left = { self.coords + vec3(- (1.1 + thickness), -1.1, 0.0), self.coords + vec3(-1.1, 1.1, 3.1 * heightMultiplier) },
        right = { self.coords + vec3(1.1 + thickness, 1.1, 0.0), self.coords + vec3(1.1, -1.1, 3.1 * heightMultiplier) }
    }

    local color = { 0, 255, 25, 150 }
    if Builder.options.demolition then
        color = { 255, 0, 0, 155 }
    end

    DrawBox(boxes[side][1], boxes[side][2], table.unpack(color))
end

function Tile:indicateSmallWallInteraction(side)
    local color = { 0, 255, 0, 40 }
    local boxes = {
        top = { self.coords + vec3(0.8, 1.1, 0.0), self.coords + vec3(-0.8, 0.9, 0.2) },
        bottom = { self.coords + vec3(-0.8, -1.1, 0.0), self.coords + vec3(0.8, -0.9, 0.2) },
        left = { self.coords + vec3(-1.1, -0.8, 0.0), self.coords + vec3(-0.9, 0.8, 0.2) },
        right = { self.coords + vec3(1.1, 0.8, 0.0), self.coords + vec3(0.9, -0.8, 0.2) }
    }

    for boxSide, coords in pairs(boxes) do
        local wall = self.elements.walls[boxSide]
        if boxSide ~= side and not (wall.border or wall.active) then
            DrawBox(coords[1], coords[2], table.unpack(color))
        end
    end
end

function Tile:indicateStairInteraction(side)
    local boxes = {
        top = { { self.coords + vec3(1.0, 3.0, 0.0), self.coords + vec3(-1.0, -1.0, 1.5) }, { self.coords + vec3(1.0, 3.0, 1.5), self.coords + vec3(-1.0, 1.0, 3.0) } },
        bottom = { { self.coords + vec3(-1.0, -3.0, 0.0), self.coords + vec3(1.0, 1.0, 1.5) }, { self.coords + vec3(-1.0, -3.0, 1.5), self.coords + vec3(1.0, -1.0, 3.0) } },
        left = { { self.coords + vec3(-3.0, -1.0, 0.0), self.coords + vec3(1.0, 1.0, 1.5) }, { self.coords + vec3(-3.0, -1.0, 1.5), self.coords + vec3(-1.0, 1.0, 3.0) } },
        right = { { self.coords + vec3(3.0, 1.0, 0.0), self.coords + vec3(-1.0, -1.0, 1.5) }, { self.coords + vec3(3.0, 1.0, 1.5), self.coords + vec3(1.0, -1.0, 3.0) } }
    }
    local color = { 0, 255, 25, 150 }
    if Builder.options.demolition then
        color = { 255, 0, 0, 155 }
    end

    for _, boxCoords in pairs(boxes[side]) do
        DrawBox(boxCoords[1], boxCoords[2], table.unpack(color))
    end
end

function Tile:indicateDecorInteraction(side)
    local thickness = 0.25
    local heightMultiplier = 1.05
    local boxes = {
        top = { self.coords + vec3(0.9, 0.5 + thickness, 0.0), self.coords + vec3(-0.9, 0.25, 3.1 * heightMultiplier) },
        bottom = { self.coords + vec3(-0.9, -(0.5 + thickness), 0.0), self.coords + vec3(0.9, -0.25, 3.1 * heightMultiplier) },
        left = { self.coords + vec3(-(0.5 + thickness), -0.7, 0.0), self.coords + vec3(-0.25, 0.9, 3.1 * heightMultiplier) },
        right = { self.coords + vec3(0.5 + thickness, 0.7, 0.0), self.coords + vec3(0.25, -0.9, 3.1 * heightMultiplier) }
    }
    local color = { 0, 255, 25, 150 }
    if Builder.options.demolition then
        color = { 255, 0, 0, 155 }
    end
    DrawBox(boxes[side][1], boxes[side][2], table.unpack(color))
end

function Tile:indicateDecorInteractionDetailed(side, decorId)
    local decorInfo = Settings.decor[decorId]
    if not decorInfo then return end

    local model = decorInfo.model
    if not DoRequestModel(model) then return end

    local offset = decorInfo.offset or { pos = vec3(0, 0, 0), heading = 0 }
    if decorInfo.randomizeOffset then
        math.randomseed(tonumber(self.x + self.y + self.z))
        offset.pos = offset.pos + vec3(math.random(-40, 40) / 100, math.random(-40, 40) / 100, 0.01)
        offset.heading = offset.heading + math.random(-30, 30)
    end

    local headings = { top = 0.0, bottom = 180.0, right = 270.0, left = 90.0 }
    local baseHeading = headings[side] or 0.0

    local min, max = GetModelDimensions(model)
    local pos = self.coords + GetCorrectedOffset(offset.pos, side)
    local rot = baseHeading + (offset.heading or 0.0)

    local color = Builder.options.demolition and { 255, 0, 0, 155 } or { 0, 255, 25, 150 }

    local function rotatePoint(point, angle)
        local sin, cos = math.sin(math.rad(angle)), math.cos(math.rad(angle))
        return vec3(point.x * cos - point.y * sin, point.x * sin + point.y * cos, point.z)
    end

    local vertices = {
        vec3(min.x, min.y, min.z), vec3(min.x, min.y, max.z),
        vec3(min.x, max.y, min.z), vec3(min.x, max.y, max.z),
        vec3(max.x, min.y, min.z), vec3(max.x, min.y, max.z),
        vec3(max.x, max.y, min.z), vec3(max.x, max.y, max.z)
    }

    local minBB = vec3(9999, 9999, 9999)
    local maxBB = vec3(-9999, -9999, -9999)

    for i = 1, #vertices do
        local rotatedVertex = rotatePoint(vertices[i], rot) + pos
        minBB = vec3(math.min(minBB.x, rotatedVertex.x), math.min(minBB.y, rotatedVertex.y), math.min(minBB.z, rotatedVertex.z))
        maxBB = vec3(math.max(maxBB.x, rotatedVertex.x), math.max(maxBB.y, rotatedVertex.y), math.max(maxBB.z, rotatedVertex.z))
    end

    DrawBox(minBB, maxBB, table.unpack(color))
    SetModelAsNoLongerNeeded(model)
end