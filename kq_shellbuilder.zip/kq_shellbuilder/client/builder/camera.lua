local yaw = 45.0
local pitch = 20.0
local initialPitch = 25.0
local zoom = 20.0
local cameraMoveSpeed = 1.5
local cameraTarget = nil
local maxDistanceFromTarget = 20.0

function Builder:startCamera()
    cameraTarget = self.centerCoords

    self.camera = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", cameraTarget + vec3(0.0, 30.0, 20.0), vec3(0.0, 0.0, 35.0), GetGameplayCamFov(), true, 0)
    SetCamActive(self.camera, true)
    RenderScriptCams(true, false, 0, true, false, false)
    SetFocusArea(cameraTarget, 0.0, 0.0, 0.0)

    Citizen.CreateThread(function()
        while self.camera and not self.saving do
            local waitTime = 5

            if IsDisabledControlPressed(0, 241) then
                zoom = zoom - 1.6
                zoom = math.max(zoom, 0.5)
                self:handleCameraInputs(true)
            elseif IsDisabledControlPressed(0, 242) then
                zoom = zoom + 1.6
                zoom = math.min(zoom, 50.0)
                self:handleCameraInputs(true)
            end

            Citizen.Wait(waitTime)
        end
    end)

    Citizen.CreateThread(function()
        while self.camera and not self.saving do
            local waitTime = self:handleCameraInputs()
            Citizen.Wait(waitTime)
        end
    end)
end

function Builder:setThumbnailCamera()
    local thumbnailPos = self.centerCoords + vec3(30.0, 30.0, 26.0)
    local thumbnailTarget = self.centerCoords + vec3(0.0, 0.0, 2.0)

    SetCamCoord(self.camera, thumbnailPos.x, thumbnailPos.y, thumbnailPos.z)
    PointCamAtCoord(self.camera, thumbnailTarget)
    SetCamFov(self.camera, 23.0)
end

function Builder:handleCameraInputs(isForcedUpdate)
    local waitTime = 100
    if isForcedUpdate then
        waitTime = 5
    end

    if IsControlPressed(0, 25) or IsDisabledControlPressed(0, 25) then
        waitTime = 5
        DisableInputs()

        if IsControlPressed(0, 21) or IsDisabledControlPressed(0, 21) then
            local mouseX = GetDisabledControlNormal(0, 1)
            local mouseY = GetDisabledControlNormal(0, 2)
            local camRot = GetCamRot(self.camera, 2)
            local angle = math.rad(camRot.z)

            local forwardX = math.cos(angle) * -mouseY * cameraMoveSpeed
            local forwardY = math.sin(angle) * -mouseY * cameraMoveSpeed
            local rightX = math.sin(angle) * -mouseX * cameraMoveSpeed
            local rightY = -math.cos(angle) * -mouseX * cameraMoveSpeed

            local newTarget = cameraTarget + vec3(rightX + forwardX, rightY + forwardY, 0.0)

            if #(newTarget - self.centerCoords) <= maxDistanceFromTarget then
                cameraTarget = newTarget
            end
        else
            local mouseX = GetDisabledControlNormal(0, 1)
            local mouseY = GetDisabledControlNormal(0, 2)
            yaw = yaw - (mouseX * pitch)
            pitch = pitch + (mouseY * pitch)
            pitch = math.clamp(pitch, -30.0, 89.0)
        end
    end

    local newCamPos = CalculateSwivelOffset(cameraTarget, zoom, yaw, pitch)
    SetCamCoord(self.camera, newCamPos.x, newCamPos.y, newCamPos.z)
    PointCamAtCoord(self.camera, cameraTarget)
    return waitTime
end

function Builder:killCamera()
    ClearFocus()
    if self.camera then
        DestroyCam(self.camera, true)
    end
    RenderScriptCams(false, true, 0, true, true, false)
    self.camera = nil
    SetFocusEntity(PlayerPedId())
end