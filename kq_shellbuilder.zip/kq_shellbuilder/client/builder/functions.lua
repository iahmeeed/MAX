--- Generates the grid of tiles that form the building area.
function Builder.buildTiles()
    Builder.tiles = {}
    Builder.matrix = {}

    local depth = Builder.config.depth
    local width = Builder.config.width
    local maxLevels = Builder.config.maxLevels

    for level = 0, maxLevels - 1 do
        Builder.matrix[tostring(level)] = {}
        local minDepth = -math.floor(depth / 2)
        local maxDepth = math.floor((depth - 1) / 2)
        for x = minDepth, maxDepth do
            Builder.matrix[tostring(level)][tostring(x)] = {}
            local minWidth = -math.floor(width / 2)
            local maxWidth = math.floor((width - 1) / 2)
            for y = minWidth, maxWidth do
                local worldCoords = Builder.centerCoords + vec3(x * 2.0, y * 2.0, level * 3.05)
                local tileIndex = #Builder.tiles + 1
                local newTile = Tile.new(x, y, level, worldCoords, tileIndex)

                Builder.matrix[tostring(level)][tostring(x)][tostring(y)] = newTile
                table.insert(Builder.tiles, newTile)
            end
        end
    end
    Builder.refresh()
end

--- Refreshes the state and visibility of all tiles.
--- @param force boolean If true, forces a refresh even if not dirty.
--- @param allLevels boolean If true, refreshes tiles on all levels, not just the current one.
function Builder.refresh(force, allLevels)
    for _, tile in pairs(Builder.tiles) do
        if allLevels or tile.z <= Builder.options.level then
            tile:refresh(force or false)
        end
    end
    Builder.setLevel(Builder.options.level)
    Builder.refreshPropCount()
end

--- Recalculates and updates the total prop count in the NUI.
function Builder.refreshPropCount()
    local count = 0
    for _, tile in pairs(Builder.tiles) do
        count = count + #tile:getAllEntities(tile.elements)
    end
    Builder.storage.propCount = count
    Nui.setPropCount(count)
end

--- Finds a specific tile object by its grid coordinates.
--- @param x number The x-coordinate.
--- @param y number The y-coordinate.
--- @param z number The z-coordinate (level).
--- @return table | nil The tile object or nil if not found.
function Builder.findTile(x, y, z)
    local levelStr = tostring(z)
    local xStr = tostring(x)
    local yStr = tostring(y)

    if Builder.matrix[levelStr] and Builder.matrix[levelStr][xStr] then
        return Builder.matrix[levelStr][xStr][yStr] or nil
    end
    return nil
end

--- Spawns the large object that acts as the "void" or floor of the shell.
function Builder.spawnVoid()
    DoRequestModel("kq_sb_void")
    Builder.void = CreateObjectNoOffset("kq_sb_void", Builder.centerCoords, false, true, false)
    SetEntityHeading(Builder.void, 0.0)
    FreezeEntityPosition(Builder.void, true)
end

--- Renders a marker at the designated player spawn point.
function Builder.renderSpawnPoint()
    local spawnPoint = Builder.settings.spawnPoint
    if not (spawnPoint and spawnPoint.tile) then return end

    if spawnPoint.tile.elements.tile.active then
        local markerPos = spawnPoint.tile.coords + vec3(0, 0, 0.2)
        local heading = Builder.settings.spawnPoint.heading or 90.0
        DrawMarker(26, markerPos, vec3(0, 0, 0), vec3(0, 0, heading), vec3(1.0, 1.0, 1.0), 0, 255, 0, 100, true, false, 2, false, nil, nil, false)
    end
end

--- Sets the player spawn point to a specific tile and heading.
--- @param tile table The tile object to set as the spawn.
--- @param heading number The heading for the player to face on spawn.
function Builder.setSpawnPoint(tile, heading)
    Builder.settings.spawnPoint = { tile = tile, heading = heading }
end

--- Toggles NUI focus, allowing or preventing game input.
--- @param isFocused boolean True to focus NUI, false to focus game.
function Builder.setNuiFocus(isFocused)
    Builder.options.nuiFocus = isFocused
end

--- Toggles demolition mode.
--- @param isEnabled boolean True to enable demolition mode.
function Builder.setDemoMode(isEnabled)
    Gizmo.stop()
    Builder.options.demolition = isEnabled
end

--- Toggles the wall fading effect.
--- @param isEnabled boolean True to enable wall fading.
function Builder.setWallsMode(isEnabled)
    Builder.options.wallFading = isEnabled
    for _, tile in pairs(Builder.tiles) do
        tile:refreshWallVisibility(true)
    end
end

--- Sets the active building mode (e.g., place, edit, select).
--- @param modeName string The name of the mode to activate.
function Builder.setMode(modeName)
    Gizmo.stop()
    Builder.mode = Builder.modes[modeName]
    Builder.refresh(true)
end

--- Sets the active color for placing props.
--- @param colorIndex number The index of the color from the palette.
function Builder.setColor(colorIndex)
    Builder.options.color = tonumber(colorIndex)
end

--- Sets the active texture for placing props.
--- @param textureName string The name of the texture.
function Builder.setTexture(textureName)
    Builder.options.texture = textureName
end

--- Sets the currently visible building level.
--- @param level number The level to display.
function Builder.setLevel(level)
    Builder.options.level = math.max(0, math.min(Builder.config.maxLevels, level))
    for _, tile in pairs(Builder.tiles) do
        if tile.z > Builder.options.level then
            tile:hideEntities()
        else
            tile:showEntities()
        end
    end
end

--- Enters a "test mode" for the player to walk around the shell.
function Builder.enterTestMode()
    Gizmo.stop()
    Debug("enterTestMode")
    Builder.options.testMode = true
    Builder.killCamera()
    Builder.options.lastLevel = Builder.options.level
    Builder.setLevel(1000) -- Show all levels
    Nui.toggleBuilder(false)
    Builder.refresh(true, true)
    SetEntityLights(Builder.void, true)

    local playerPed = PlayerPedId()
    Builder.storage.initPlayerCoords = GetEntityCoords(playerPed)

    local spawnTile = Builder.settings.spawnPoint and Builder.settings.spawnPoint.tile
    if spawnTile and spawnTile.elements.tile.active then
        local spawnPos = spawnTile.coords + vec3(0, 0, 1.0)
        local spawnHeading = tonumber(Builder.settings.spawnPoint.heading or 90.0)
        SetEntityCoords(playerPed, spawnPos)
        SetEntityHeading(playerPed, spawnHeading)
        FreezeEntityPosition(playerPed, false)
        return
    end

    -- Fallback spawn if no spawn point is set
    for _, tile in pairs(Builder.tiles) do
        if tile.elements.tile.active then
            SetEntityCoords(playerPed, tile.coords + vec3(0, 0, 1.0))
            FreezeEntityPosition(playerPed, false)
            return
        end
    end

    Debug("^1Could not enter test mode. No tiles active?")
    exports.kq_link:Notify("Could not enter test mode, No available spawn tiles found", "error")
    Builder.exitTestMode()
end

--- Exits the "test mode" and returns to the builder interface.
function Builder.exitTestMode()
    Debug("exitTestMode")
    Builder.options.testMode = false
    Builder.startCamera()
    Nui.toggleBuilder(true)
    Builder.setLevel(Builder.options.lastLevel)
    SetEntityLights(Builder.void, false)
    ResetEntityAlpha(Builder.void)
    Builder.refresh(true, true)

    local playerPed = PlayerPedId()
    SetEntityCoords(playerPed, Builder.storage.initPlayerCoords + vec3(0, 0, 0.1))
    FreezeEntityPosition(playerPed, true)
    SetEntityVisible(playerPed, false, 0)
end

local compressionDict = {
    tiles = "t", tile = "tl", color = "c", texture = "tx", active = "a",
    light = "l", walls = "ws", wall = "w", bottom = "b", type = "tp",
    extras = "ex", stairs = "st", doorframe = "df", doorway = "dw",
    window = "wd", wall_window = "wwd", door = "d", top = "w_t", left = "w_l",
    right = "w_r", border = "br", half_wall = "hw", decor = "dc",
    ceiling = "cl", none = "nn"
}

--- Compresses the shell data by shortening JSON keys.
--- @param data table The shell data to compress.
--- @return table The compressed data.
function Builder.compress(data)
    local jsonString = json.encode(data)
    for key, shortKey in pairs(compressionDict) do
        jsonString = jsonString:gsub('"' .. key .. '"', '"@' .. shortKey .. '"')
    end
    return json.decode(jsonString)
end

--- Decompresses the shell data by expanding JSON keys.
--- @param data table The compressed data.
--- @return table The decompressed data.
function Builder.decompress(data)
    local jsonString = json.encode(data)
    local reverseDict = {}
    for key, shortKey in pairs(compressionDict) do
        reverseDict[shortKey] = key
    end
    for shortKey, key in pairs(reverseDict) do
        jsonString = jsonString:gsub('"@' .. shortKey .. '"', '"' .. key .. '"')
    end
    return json.decode(jsonString)
end