function GetGlobalShells()
    local shells = {}
    local shellIds = GlobalState[CONSTS.SHELL_IDS_STATE_KEY] or {}

    for _, shellId in pairs(shellIds) do
        local key = CONSTS.SHELL_PREFIX_KEY .. shellId
        local shellData = GlobalState[key]
        if shellData then
            table.insert(shells, shellData)
        end
    end

    return shells
end

function FindGlobalShellById(shellId)
    local allShells = GetGlobalShells()
    for _, shell in pairs(allShells) do
        if shell.id == shellId then
            return shell
        end
    end
    return nil
end

function GetCorrectedOffset(offset, side)
    if side == "top" then
        return offset
    elseif side == "bottom" then
        return vector3(-offset.x, -offset.y, offset.z)
    elseif side == "left" then
        return vector3(-offset.y, offset.x, offset.z)
    elseif side == "right" then
        return vector3(offset.y, -offset.x, offset.z)
    else
        Debug("Invalid side! Use 'top', 'bottom', 'left', or 'right'.")
        return vector3(0.0, 0.0, 0.0)
    end
end

function CalculateSwivelOffset(centerPos, distance, yaw, pitch)
    local yawRad = math.rad(yaw)
    local pitchRad = math.rad(pitch)

    local x = math.cos(yawRad) * math.cos(pitchRad) * distance
    local y = math.sin(yawRad) * math.cos(pitchRad) * distance
    local z = math.sin(pitchRad) * distance

    return centerPos + vec3(x, y, z)
end

function IsRotationWithinRange(angle1, angle2, tolerance)
    if angle1 > 180 then angle1 = angle1 - 360 end
    if angle1 < -180 then angle1 = angle1 + 360 end
    if angle2 > 180 then angle2 = angle2 - 360 end
    if angle2 < -180 then angle2 = angle2 + 360 end

    local diff = math.abs(angle1 - angle2)
    if diff > 180 then
        diff = 360 - diff
    end

    return tolerance >= diff
end

function GetCursorCoordinates()
    local x = GetDisabledControlNormal(0, 239)
    local y = GetDisabledControlNormal(0, 240)
    return x, y
end

function CompressVector(vector)
    local function roundToPrecision(num, precision)
        precision = precision or 0.001
        local rounded = math.floor((num / precision) + 0.5) * precision
        if rounded == math.floor(rounded) then
            return math.floor(rounded)
        end
        return rounded
    end

    local compressed = {}
    local roundedX = roundToPrecision(vector.x)
    if math.abs(roundedX) > 0.0 then
        compressed.x = roundedX
    end

    local roundedY = roundToPrecision(vector.y)
    if math.abs(roundedY) > 0.0 then
        compressed.y = roundedY
    end

    local roundedZ = roundToPrecision(vector.z)
    if math.abs(roundedZ) > 0.0 then
        compressed.z = roundedZ
    end

    return compressed
end

function GetCursorHitCoords()
    local screenX, screenY = GetCursorCoordinates()
    local camPos, camDir = GetWorldCoordFromScreenCoord(screenX, screenY)

    local rayStart = camPos + (camDir * 2.0)
    local rayEnd = camPos + (camDir * 120.0)

    local shapeHandle = StartShapeTestSweptSphere(rayStart, rayEnd, 0.05, -1, PlayerPedId(), 1)
    local _, didHit, hitCoords, _, entityHit = GetShapeTestResult(shapeHandle)

    if not didHit then
        return nil
    end

    return hitCoords, screenX, screenY, entityHit
end

function math.clamp(value, min, max)
    if value < min then
        return min
    end
    if value > max then
        return max
    end
    return value
end