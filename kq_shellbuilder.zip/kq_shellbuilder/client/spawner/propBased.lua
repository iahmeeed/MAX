PropBased = {}
PropBased.__index = PropBased

local activeShells = {}
local objectPoolCount = 0

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(250)
        local objectPool = GetGamePool("CObject")

        if #objectPool ~= objectPoolCount then
            local shellPropCount = 0
            for _, objectHandle in pairs(objectPool) do
                local modelHash = GetEntityModel(objectHandle)
                local shellId = Spawner.archetypes[modelHash]

                if shellId then
                    shellPropCount = shellPropCount + 1
                    if not activeShells[objectHandle] then
                        Debug("New shell object spawned!", GetEntityCoords(objectHandle), objectHandle)
                        local shellData = FindGlobalShellById(shellId)
                        if shellData then
                            local propInstance = PropBased:init(shellData, objectHandle)
                            activeShells[objectHandle] = propInstance
                        end
                    end
                end
            end
            if shellPropCount > 0 then
                Debug("Found " .. shellPropCount .. " shell props")
            end
        end
        objectPoolCount = #objectPool
    end
end)

function PropBased:init(shellData, originObject)
    local instance = setmetatable({}, self)
    instance.active = true
    instance.id = shellData.id
    instance.origin = originObject
    instance.spawnData = Spawner.decodeSpawnData(shellData.spawnData.entities)
    instance.settings = shellData.settings
    instance.objects = { base = {}, spawned = {} }
    instance.entityData = {}

    AddStateBagChangeHandler(CONSTS.SHELL_PREFIX_KEY .. instance.id, nil, function(bagName, key, value)
        instance.spawnData = Spawner.decodeSpawnData(value.spawnData.entities)
        instance.settings = value.settings
        Citizen.Wait(100)
        if instance.spawned then
            instance:despawn()
            instance:spawn()
        end
    end)

    instance:spawnThread()
    return instance
end

function PropBased:spawnThread()
    Citizen.CreateThread(function()
        while self.active do
            local playerCoords = GetEntityCoords(PlayerPedId())
            local originCoords = GetEntityCoords(self.origin)
            local camCoords = GetCamCoord(GetRenderingCam())

            local distToPlayer = #(originCoords - playerCoords)
            local distToCam = #(originCoords - camCoords)
            local zDistCheck = math.abs((originCoords.z + 6.0) - playerCoords.z)

            if self.spawned then
                if (distToPlayer > 45.0 or zDistCheck > 10.0) and distToCam > 50.0 then
                    self:despawn()
                end
            elseif (distToPlayer <= 45.0 and zDistCheck <= 10.0) or distToCam <= 50.0 then
                self:spawn()
            end

            if not DoesEntityExist(self.origin) then
                Debug("Detected deletion", self.origin)
                self:delete()
            end
            Citizen.Wait(1000)
        end
    end)

    Citizen.CreateThread(function()
        local lastMoveCheckTime = GetGameTimer()
        while self.active do
            local waitTime = 1000
            if (lastMoveCheckTime + 60000) < GetGameTimer() then
                waitTime = 5000
            end

            if (lastMoveCheckTime + 3000) > GetGameTimer() then
                waitTime = 30
            elseif not IsEntityVisible(self.objects.base.mask) then
                if self.settings.hideVoid ~= 1 then
                    SetEntityVisible(self.objects.base.mask, true, 0)
                end
            end

            if self.spawned then
                local posDiff = #(self.spawnCoords - GetEntityCoords(self.origin))
                local rotDiff = #(self.spawnRot - GetEntityRotation(self.origin))

                if posDiff > 0.03 or rotDiff > 1.0 then
                    self:updatePositions()
                    waitTime = 30
                    lastMoveCheckTime = GetGameTimer()
                    SetEntityVisible(self.objects.base.mask, false, 0)
                end
            end
            Citizen.Wait(waitTime)
        end
    end)
end

function PropBased:spawnMask()
    if self.settings.hideVoid == 1 then
        return
    end

    DoRequestModel("kq_sb_shadow_mask")
    local mask = CreateObjectNoOffset("kq_sb_shadow_mask", GetEntityCoords(self.origin), false, true, false)
    SetEntityHeading(mask, 0.0)
    FreezeEntityPosition(mask, true)
    self.objects.base.mask = mask

    local relativePos = GetEntityCoords(mask) - GetEntityCoords(self.origin)
    AttachEntityToEntity(mask, self.origin, 0, relativePos, vec3(0.0, 0.0, 0.0), false, true, true, false, 2, true)
end

function PropBased:spawn()
    if self.spawned then return end
    Debug("do spawn")

    self.spawnCoords = GetEntityCoords(self.origin)
    self.spawnRot = GetEntityRotation(self.origin)
    self:spawnMask()
    Debug("spawn")

    InitializeCustomTextures()
    SetEntityCollision(self.origin, false, false)
    self.spawned = true

    local batchSize = 16
    for i = 1, #self.spawnData, batchSize do
        Citizen.CreateThread(function()
            local startIndex = i
            local endIndex = math.min(i + batchSize - 1, #self.spawnData)
            for j = startIndex, endIndex do
                Debug("Spawning entity", j .. "/" .. #self.spawnData, self.origin)
                self:spawnEntity(self.spawnData[j])
            end
        end)
    end

    Citizen.CreateThread(function()
        if self.settings.timecycle then
            Citizen.Wait(500)
            ClearTimecycleModifier()
            Citizen.Wait(50)
            SetTimecycleModifier(self.settings.timecycle)
        end
    end)
end

function PropBased:despawn()
    if not self.spawned then return end
    Debug("despawn")

    self.spawned = false
    for _, entity in pairs(self.objects.spawned) do
        SetEntityAsMissionEntity(entity, true, true)
        DeleteEntity(entity)
    end

    if self.objects.base.mask then
        DeleteEntity(self.objects.base.mask)
    end
    self.objects.base.mask = nil
    self.objects.spawned = {}

    Citizen.Wait(50)
    ClearTimecycleModifier()
end

function PropBased:delete()
    self:despawn()
    self.active = false
end

function PropBased:spawnEntity(entityData)
    DoRequestModel(entityData.model)
    local pos = entityData.pos + GetEntityCoords(self.origin)
    local obj = CreateObjectNoOffset(entityData.model, pos, false, true, false)

    SetEntityRotation(obj, entityData.rot)
    FreezeEntityPosition(obj, entityData.frozen)
    SetObjectTextureVariation(obj, entityData.color or 0)
    SetEntityAsMissionEntity(obj, true, true)

    local colorData = Settings.colors[entityData.color]
    SetObjectLightColor(obj, 1, colorData.r, colorData.g, colorData.b)
    SetModelAsNoLongerNeeded(entityData.model)

    local relativeCoords = GetEntityCoords(obj) - GetEntityCoords(self.origin)
    AttachEntityToEntity(obj, self.origin, 0, relativeCoords, entityData.rot, false, true, true, false, 2, true)
    DetachEntity(obj, true, true)

    self.entityData[obj] = {
        coords = relativeCoords,
        rot = entityData.rot
    }
    table.insert(self.objects.spawned, obj)
end

function PropBased:updatePositions()
    for _, obj in pairs(self.objects.spawned or {}) do
        local data = self.entityData[obj]
        AttachEntityToEntity(obj, self.origin, 0, data.coords, data.rot, false, true, true, false, 2, true)
        DetachEntity(obj, true, true)
    end
    self.spawnCoords = GetEntityCoords(self.origin)
    self.spawnRot = GetEntityRotation(self.origin)
end

function PropBased:isModelADoor(modelHash)
    for _, doorInfo in pairs(Settings.doors or {}) do
        if GetHashKey(doorInfo.model) == modelHash then
            return true
        end
    end
    return false
end