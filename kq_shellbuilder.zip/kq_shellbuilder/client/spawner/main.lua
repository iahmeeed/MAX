Spawner = {
    shells = {},
    inside = false,
    archetypes = {}
}

--- Initializes the spawner by creating Shell objects for all globally available shells.
--- @return table The table of global shells that were processed.
function Spawner.init()
    local globalShells = GetGlobalShells()
    for _, shellData in pairs(globalShells) do
        if shellData.spawnData and shellData.coords then
            local shellInstance = Shell.init(shellData)
            table.insert(Spawner.shells, shellInstance)
        end
    end
    return globalShells
end

--- Refreshes which shells are spawned based on player proximity.
--- Also manages indoor/outdoor environmental effects.
--- @return table | boolean The shell object the player is inside, or false.
function Spawner.refreshSpawns()
    if Builder.active then return end

    local playerPed = PlayerPedId()
    local camCoords = GetCamCoord(GetRenderingCam())
    local playerCoords = GetEntityCoords(playerPed)
    local currentlyInsideShell = false

    for _, shell in ipairs(Spawner.shells) do
        local distToPlayer = #(playerCoords - shell.coords)
        local distToCam = #(camCoords - shell.coords)

        if distToPlayer <= 40.0 or distToCam <= 40.0 then
            shell:spawn()
            currentlyInsideShell = shell
        else
            shell:despawn()
        end
    end

    local wasInside = Spawner.inside
    Spawner.inside = currentlyInsideShell

    if currentlyInsideShell and not wasInside then
        Spawner.applyIndoorModifiers(currentlyInsideShell)
    elseif not currentlyInsideShell and wasInside then
        Spawner.applyOutdoorModifiers(currentlyInsideShell)
    end

    return currentlyInsideShell
end

--- Checks if the player is near any shell teleporters.
--- @return boolean True if the player is near a teleporter.
function Spawner.teleportersThread()
    if Builder.active or IsPlayerUnreachable() then
        return false
    end

    local isNearTeleporter = false
    for _, shell in ipairs(Spawner.shells) do
        if shell:teleportersThread() then
            Debug("Near a shell", shell.id)
            isNearTeleporter = true
        end
    end
    return isNearTeleporter
end

--- Finds a loaded shell instance by its ID.
--- @param shellId number The ID of the shell to find.
--- @return table | nil The shell object or nil if not found.
function Spawner.findShellById(shellId)
    for _, shell in ipairs(Spawner.shells) do
        if shell.id == shellId then
            return shell
        end
    end
    return nil
end

--- Teleports the player to a specific shell.
--- @param shellId number The ID of the shell to teleport to.
function Spawner.teleportToShell(shellId)
    local shell = Spawner.findShellById(shellId)
    if not shell then
        print(string.format("^1Shell not found: %s", shellId))
        return
    end
    shell:teleport()
end

--- Triggers a server event to update a shell's coordinates.
--- @param shellId number The ID of the shell.
--- @param coords vector3 The new coordinates.
function Spawner.updateCoords(shellId, coords)
    TriggerServerEvent("kq_shellbuilder:server:setCoords", shellId, coords)
end

--- Triggers a server event to update a shell's teleporter settings.
--- @param shellId number The ID of the shell.
--- @param isActive boolean Whether the teleporter is active.
--- @param coords vector4 The teleporter's coordinates and heading.
--- @param allowVehicles boolean Whether vehicles are allowed.
function Spawner.updateTeleporter(shellId, isActive, coords, allowVehicles)
    TriggerServerEvent("kq_shellbuilder:server:setTeleporter", shellId, isActive, coords, allowVehicles)
end

--- Applies environmental changes for being inside a shell (e.g., stops rain).
--- @param shell table The shell the player is entering.
function Spawner.applyIndoorModifiers(shell)
    SetRainLevel(0.0)
end

--- Reverts environmental changes when leaving a shell.
function Spawner.applyOutdoorModifiers(shell)
    SetRainLevel(-1.0) -- Resets to default weather behavior
end

--- Decodes the compressed spawn data string/table into a usable format.
--- @param spawnData table The raw spawn data.
--- @return table A list of prop data tables.
function Spawner.decodeSpawnData(spawnData)
    if not spawnData then return {} end

    local function parseVectorString(str)
        if not str or str == 0 then return vec3(0, 0, 0) end
        local parts = {}
        for part in string.gmatch(str, "([^,]+)") do
            table.insert(parts, tonumber(part))
        end
        return vec3(parts[1] or 0, parts[2] or 0, parts[3] or 0)
    end

    local decoded = {}
    for _, propData in ipairs(spawnData) do
        table.insert(decoded, {
            model = tonumber(propData[1]),
            color = tonumber(propData[2] or 0),
            pos = parseVectorString(propData[3]),
            rot = parseVectorString(propData[4]),
            frozen = propData[5] or false
        })
    end
    return decoded
end

-- Exported function for other resources to check if the player is inside a shell.
function IsInsideIPL()
    Debug("External script called: IsInsideIPL")
    return Spawner.inside ~= false
end
exports("IsInsideIPL", IsInsideIPL)
exports("isInsideIPL", IsInsideIPL) -- Common alias

-- State bag handler to dynamically update shells when server data changes.
AddStateBagChangeHandler(CONSTS.SHELL_IDS_STATE_KEY, nil, function(bagName, key, value)
    Citizen.SetTimeout(500, function()
        local globalShells = GetGlobalShells()
        for _, shellData in pairs(globalShells) do
            if shellData.spawnData and shellData.coords then
                if not Spawner.findShellById(shellData.id) then
                    local shellInstance = Shell.init(shellData)
                    table.insert(Spawner.shells, shellInstance)
                end
            end
        end
    end)
end)

-- Main threads for managing shell states.
CreateThread(function()
    local lastPlayerCoords = vec3(0, 0, 0)
    local teleportThreshold = 20.0

    -- Thread to detect player teleports and force a refresh.
    CreateThread(function()
        while true do
            Citizen.Wait(50)
            local currentCoords = GetEntityCoords(PlayerPedId())
            if #(currentCoords - lastPlayerCoords) > teleportThreshold then
                Debug("Player has teleported")
                Spawner.refreshSpawns()
            end
            lastPlayerCoords = currentCoords
        end
    end)

    -- Regular refresh thread.
    CreateThread(function()
        while true do
            Citizen.Wait(2000)
            Spawner.refreshSpawns()
        end
    end)

    -- Teleporter check thread (runs more frequently when near a teleporter).
    CreateThread(function()
        while true do
            local sleep = 2000
            if Spawner.teleportersThread() then
                sleep = 1
            end
            Citizen.Wait(sleep)
        end
    end)
end)

-- Initial load of all shells.
Spawner.init()