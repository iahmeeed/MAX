Shell = {}
Shell.__index = Shell

--- Initializes a new shell object.
--- @param shellData table The raw data for the shell from the server.
--- @return table The new shell instance.
function Shell.init(self, shellData)
    local instance = setmetatable({}, self)

    instance.id = shellData.id
    instance.spawned = false
    instance.coords = shellData.coords
    instance.spawnData = Spawner.decodeSpawnData(shellData.spawnData.entities)
    instance.settings = shellData.settings
    instance.objects = { base = {}, spawned = {} }

    local sp = shellData.builderData.spawnPoint
    if sp then
        -- This calculation seems intentionally obfuscated, but behavior is preserved.
        instance.spawnPoint = vec4(sp.x * 2, sp.y * 2, sp.z * 3, sp.w or 0.0)
    else
        instance.spawnPoint = vec4(0, 0, 0, 0)
    end

    -- State bag handler for live updates to this specific shell.
    AddStateBagChangeHandler(CONSTS.SHELL_PREFIX_KEY .. instance.id, nil, function(bagName, key, value)
        if not value or not value.spawnData then
            instance:despawn()
            return
        end

        instance.spawnData = Spawner.decodeSpawnData(value.spawnData.entities)
        instance.settings = value.settings
        instance.coords = value.coords

        local newSp = value.builderData.spawnPoint
        if newSp then
            instance.spawnPoint = vec4(newSp.x * 2, newSp.y * 2, newSp.z * 3, newSp.w or 0)
        else
            instance.spawnPoint = vec4(0, 0, 0, 0)
        end

        Wait(100)
        if instance.spawned then
            instance:despawn()
            instance:spawn()
        end
    end)

    instance:spawnMask()
    instance:initArchetype()
    Citizen.SetTimeout(5000, function() instance:initArchetype() end) -- Re-check after a delay

    return instance
end

--- Registers the dynamic archetype for the shell's base model if it doesn't exist.
function Shell.initArchetype(self)
    local archetype_name = "kq_sbx_shell_" .. self.id
    if not IsModelValid(archetype_name) then
        RegisterArchetypes(function()
            return {
                {
                    flags = 0,
                    bbMin = vec3(-100.0, -100.0, -3.0),
                    bbMax = vec3(100.0, 100.0, 30.0),
                    bsCentre = vec3(0.0, 0.0, 0.01),
                    bsRadius = 200.0,
                    name = archetype_name,
                    textureDictionary = archetype_name,
                    physicsDictionary = archetype_name,
                    assetName = archetype_name,
                    drawableDictionary = "kq_sb_shells",
                    assetType = "ASSET_TYPE_DRAWABLE",
                    lodDist = 201.0,
                    specialAttribute = 0
                }
            }
        end)
        Debug("New archetype claimed ", archetype_name)
    end
    Spawner.archetypes[GetHashKey(archetype_name)] = self.id
end

--- Spawns the void mask for the shell to hide the outside world.
function Shell.spawnMask(self)
    if self.settings.hideVoid == 1 then return end
    DoRequestModel("kq_sb_shadow_mask")
    local mask = CreateObjectNoOffset("kq_sb_shadow_mask", self.coords, false, true, false)
    SetEntityHeading(mask, 0.0)
    FreezeEntityPosition(mask, true)
    self.objects.base.mask = mask
    SetEntityVisible(self.objects.base.mask, false, 0)
end

--- Spawns the shell and all its entities into the world.
function Shell.spawn(self)
    if self.spawned then return end

    InitializeCustomTextures()
    SetEntityVisible(self.objects.base.mask, not self.settings.hideVoid, 0)
    SetEntityNoCollisionEntity(PlayerPedId(), self.objects.base.mask, true)
    self.spawned = true

    -- Spawn entities in batches across multiple threads to avoid hitches.
    local batchSize = 16
    for i = 1, #self.spawnData, batchSize do
        Citizen.CreateThread(function()
            local endIndex = math.min(i + batchSize - 1, #self.spawnData)
            for j = i, endIndex do
                self:spawnEntity(self.spawnData[j])
            end
        end)
    end

    TriggerEvent("cs:weather:client:DisableSync")

    Citizen.CreateThread(function()
        Citizen.SetTimeout(1000, function()
            self:freezeOwnedEntities(false)
            Citizen.SetTimeout(2000, function()
                self:freezeOwnedEntities(false)
            end)
        end)

        if self.settings.timecycle then
            Citizen.Wait(500)
            ClearTimecycleModifier()
            Citizen.Wait(50)
            SetTimecycleModifier(self.settings.timecycle)
        end
    end)
end

--- Despawns the shell and cleans up all its entities.
function Shell.despawn(self)
    if not self.spawned then return end
    self.spawned = false

    if self.objects.base.mask then
        SetEntityAsMissionEntity(self.objects.base.mask, true, true)
        SetEntityVisible(self.objects.base.mask, false, 0)
        SetEntityNoCollisionEntity(PlayerPedId(), self.objects.base.mask, false)
    end

    TriggerEvent("cs:weather:client:EnableSync")
    self:freezeOwnedEntities(true)

    for _, entity in pairs(self.objects.spawned) do
        SetEntityAsMissionEntity(entity, true, true)
        DeleteEntity(entity)
    end
    self.objects.spawned = {}

    ClearTimecycleModifier()
end

--- Freezes or unfreezes vehicles within the shell's radius.
--- @param shouldFreeze boolean True to freeze, false to unfreeze.
function Shell.freezeOwnedEntities(self, shouldFreeze)
    if not Config.freezeVehiclesOnDespawn then return end

    for _, vehicle in ipairs(GetGamePool("CVehicle")) do
        if NetworkHasControlOfEntity(vehicle) and IsEntityPositionFrozen(vehicle) ~= shouldFreeze then
            if #(GetEntityCoords(vehicle) - self.coords) <= 40.0 then
                FreezeEntityPosition(vehicle, shouldFreeze)
            end
        end
    end
end

--- Spawns a single entity (prop) for the shell.
--- @param entityData table The data for the prop to spawn.
function Shell.spawnEntity(self, entityData)
    if not DoRequestModel(entityData.model) then return end

    local position = self.coords + entityData.pos
    local object = CreateObjectNoOffset(entityData.model, position, false, true, false)

    SetEntityRotation(object, entityData.rot)
    FreezeEntityPosition(object, entityData.frozen)
    SetObjectTextureVariation(object, entityData.color or 0)
    SetEntityAsMissionEntity(object, true, true)

    local colorData = Settings.colors[entityData.color]
    SetObjectLightColor(object, 1, colorData.r, colorData.g, colorData.b)

    table.insert(self.objects.spawned, object)
end

--- Teleports the player into the shell's designated spawn point.
function Shell.teleport(self)
    local isTeleporting = true
    local targetCoords = self.coords + self.spawnPoint.xyz + vec3(0, 0, 1)
    local targetHeading = self.spawnPoint.w or 0.0

    SmoothTeleport(PlayerPedId(), targetCoords, targetHeading, function()
        self:spawn()
        local startTime = GetGameTimer()

        Citizen.SetTimeout(1000, function()
            local playerPed = PlayerPedId()
            -- Wait until player has settled after teleport
            while isTeleporting and #(targetCoords - GetEntityCoords(playerPed)) <= 2.5 do
                if GetGameTimer() - startTime > 5000 then break end -- Timeout
                Citizen.Wait(500)
            end
            isTeleporting = false
        end)
    end)
end

--- Teleports the player out of the shell to the exterior teleporter location.
function Shell.teleportOut(self)
    self:spawn()
    local teleporter = self.settings.teleporter
    SmoothTeleport(PlayerPedId(), vec3(teleporter.x, teleporter.y, teleporter.z), teleporter.w or 0.0)
    ClearTimecycleModifier()
end

--- Manages teleporter markers and interaction logic.
--- @return boolean True if a teleporter is being interacted with or displayed.
function Shell.teleportersThread(self)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local teleporter = self.settings.teleporter

    if not teleporter or not teleporter.active then
        return false
    end

    local teleporterPos = vec3(tonumber(teleporter.x), tonumber(teleporter.y), tonumber(teleporter.z))
    local allowVehicles = tonumber(teleporter.vehicles) == 1
    local isPlayerInVehicle = IsPedInAnyVehicle(playerPed)

    local markerSize = 1.0
    if allowVehicles and isPlayerInVehicle then
        markerSize = 2.0
    elseif isPlayerInVehicle then
        return false -- In vehicle but teleporter doesn't allow it
    end

    local markerCfg = Config.markers
    markerSize = markerSize * (markerCfg.scale or 1.0)

    -- Check for entry teleporter
    local distToEntry = #(playerCoords - teleporterPos)
    if distToEntry <= 30.0 * markerSize then
        local alpha = math.min(markerCfg.a, math.floor((20 * markerSize - distToEntry) * 0.3 * markerCfg.a))
        local markerPos = teleporterPos + vec3(0, 0, -0.96)
        DrawMarker(markerCfg.type or 1, markerPos, vec3(0, 0, 0), vec3(0, 0, 0), vec3(markerSize, markerSize, 0.6), markerCfg.r, markerCfg.g, markerCfg.b, alpha, false, false, 2, nil, nil, false)
        if distToEntry <= markerSize and GetEntitySpeed(playerPed) <= 0.5 then
            self:teleport()
            Citizen.Wait(1500)
            local entryCoords = GetEntityCoords(playerPed)
            -- Wait for player to move away from the spawn point
            while #(entryCoords - GetEntityCoords(playerPed)) <= 2.5 do
                Citizen.Wait(500)
            end
        end
        return true
    end

    -- Check for exit teleporter
    local exitPos = self.coords + self.spawnPoint.xyz + vec3(0, 0, 1.0)
    local distToExit = #(playerCoords - exitPos)
    if distToExit <= 10.0 then
        if not L0_1 then
            local alpha = math.min(markerCfg.a, math.floor((6.0 - distToExit) * 0.3 * markerCfg.a))
            local markerPos = exitPos + vec3(0, 0, 0.02)
            DrawMarker(markerCfg.type or 1, markerPos, vec3(0, 0, 0), vec3(0, 0, 0), vec3(markerSize, markerSize, 0.6), markerCfg.r, markerCfg.g, markerCfg.b, alpha, false, false, 2, nil, nil, false)

            if distToExit <= markerSize and GetEntitySpeed(playerPed) <= 0.5 then
                self:teleportOut()
                Citizen.Wait(1500)
                local exitCoords = GetEntityCoords(playerPed)
                -- Wait for player to move away from the exit point
                while #(exitCoords - GetEntityCoords(playerPed)) <= 2.5 do
                    Citizen.Wait(500)
                end
            end
            return true
        end
    end

    return false
end