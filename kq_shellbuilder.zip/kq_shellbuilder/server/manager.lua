--- Handles the creation of a new shell after passing policy checks.
--- @param source number The source ID of the player saving the shell.
--- @param shellData table The data for the new shell.
--- @return number The ID of the newly created shell.
local function saveNewShell(source, shellData)
    Debug("Perform new save checks", source, shellData ~= nil)

    if not POLICY.CanPlayerCreateShell(source, shellData) then
        TriggerClientEvent("kq_link:client:notify", source, "You may not save this shell", "error")
        return
    end

    if not shellData.title or #shellData.title <= 0 then
        TriggerClientEvent("kq_link:client:notify", source, "The title may not be empty", "error")
        return
    end

    print(string.format("^3Saving a new shell %s", shellData.title))

    local newShellId = DB.SaveNewShell(
        source,
        shellData.title,
        CalculateShellCoords(GetLastId() + 1),
        shellData.settings,
        shellData.builderData,
        shellData.spawnData,
        shellData.thumbnail
    )

    print("^3New shell saved", newShellId)
    TriggerClientEvent("kq_shellbuilder:client:quit", source)
    FetchShells()
    return newShellId
end

--- Main handler to save or update a shell based on whether an ID is provided.
--- @param source number The source ID of the player.
--- @param shellData table The data for the shell being saved.
local function saveShell(source, shellData)
    print(string.format("^0Save Shell triggered by %s", source), shellData ~= nil)

    if not shellData.id then
        Debug("Saving new shell", source)
        saveNewShell(source, shellData)
        return
    end

    Debug("Shell exists. Update checks")

    if not POLICY.CanPlayerUpdateShell(source, shellData.id) then
        TriggerClientEvent("kq_link:client:notify", source, "You may not save this shell", "error")
        return
    end

    if not shellData.title or #shellData.title <= 0 then
        TriggerClientEvent("kq_link:client:notify", source, "The title may not be empty", "error")
        return
    end

    print(string.format("^3Updating a shell [%s] %s", shellData.id, shellData.title))

    local existingShell = GetShellById(shellData.id)
    existingShell.settings.timecycle = shellData.settings.timecycle
    existingShell.settings.hideVoid = shellData.settings.hideVoid

    DB.UpdateShell(
        shellData.id,
        shellData.title,
        existingShell.settings,
        shellData.builderData,
        shellData.spawnData,
        shellData.thumbnail
    )

    TriggerClientEvent("kq_shellbuilder:client:quit", source)
    FetchShells()
end

--- Sets the world coordinates for a given shell.
--- @param source number The source ID of the player.
--- @param shellId number The ID of the shell to move.
--- @param coords vector3 The new coordinates for the shell.
local function setShellCoordinates(source, shellId, coords)
    print(string.format("^0SetShellCoordinates triggered by %s", source))
    if not shellId then return end

    if not POLICY.CanPlayerMoveShell(source, shellId, coords) then
        TriggerClientEvent("kq_link:client:notify", source, "You may not move this shell", "error")
        return
    end

    print(string.format("^3Moving shell [%s] ", shellId))
    DB.SetShellCoordinates(shellId, coords)
    FetchShells()
end

--- Configures the teleporter settings for a shell.
--- @param source number The source ID of the player.
--- @param shellId number The ID of the shell.
--- @param isActive boolean Whether the teleporter is active.
--- @param teleporterCoords vector4 The coordinates and heading for the teleporter.
--- @param areVehiclesAllowed boolean Whether vehicles can use the teleporter.
local function setShellTeleporter(source, shellId, isActive, teleporterCoords, areVehiclesAllowed)
    print(string.format("^SetShellTeleporter triggered by %s", source))
    if not shellId then return end

    if not POLICY.CanPlayerManageTeleporters(source, shellId) then
        TriggerClientEvent("kq_link:client:notify", source, "You may not configure the teleporter of this shell", "error")
        return
    end

    print(string.format("^3Setting teleporter for shell [%s] ", shellId))
    local shell = GetShellById(shellId)
    shell.settings.teleporter = {
        active = isActive,
        vehicles = areVehiclesAllowed,
        x = teleporterCoords.x,
        y = teleporterCoords.y,
        z = teleporterCoords.z,
        w = teleporterCoords.w
    }
    DB.UpdateShell(shell.id, shell.title, shell.settings, shell.builderData, shell.spawnData, shell.thumbnail)
    FetchShells()
end

--- Marks a shell as deleted.
--- @param source number The source ID of the player.
--- @param shellId number The ID of the shell to delete.
local function deleteShell(source, shellId)
    print(string.format("^DeleteShell triggered by %s", source))
    if not shellId then return end

    if not POLICY.CanPlayerDeleteShells(source) then
        TriggerClientEvent("kq_link:client:notify", source, "You may not delete this shell", "error")
        return
    end

    print(string.format("^3Deleting shell [%s] ", shellId))
    DB.SetShellDeleted(shellId)
    FetchShells()
end

RegisterServerEvent("kq_shellbuilder:server:saveShell")
AddEventHandler("kq_shellbuilder:server:saveShell", function(shellData)
    saveShell(source, shellData)
end)

RegisterServerEvent("kq_shellbuilder:server:setCoords")
AddEventHandler("kq_shellbuilder:server:setCoords", function(shellId, coords)
    setShellCoordinates(source, shellId, coords)
end)

RegisterServerEvent("kq_shellbuilder:server:setTeleporter")
AddEventHandler("kq_shellbuilder:server:setTeleporter", function(shellId, isActive, coords, areVehiclesAllowed)
    setShellTeleporter(source, shellId, isActive, coords, areVehiclesAllowed)
end)

RegisterServerEvent("kq_shellbuilder:server:deleteShell")
AddEventHandler("kq_shellbuilder:server:deleteShell", function(shellId)
    deleteShell(source, shellId)
end)