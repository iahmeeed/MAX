local shells = {}
local shellIds = {}
local lastShellId = 0

local function syncToGlobalState()
    GlobalState[CONSTS.SHELL_IDS_STATE_KEY] = shellIds

    for _, shellId in pairs(shellIds) do
        local key = CONSTS.SHELL_PREFIX_KEY .. shellId
        GlobalState[key] = shells[shellId]
        Citizen.Wait(10)
    end
end

function GetAllShellIds()
    return shellIds
end

function GetShellById(shellId)
    return shells[shellId] or nil
end

function GetLastId()
    return lastShellId
end

function CalculateShellCoords(shellId)
    local baseX = -3500.0
    local baseY = -4100.0
    local baseZ = 700.0

    local spacingX = 50.0
    local spacingY = 50.0
    local spacingZ = 50.0

    local itemsPerRow = 10
    local rowsPerLayer = 150

    local index = shellId - 1
    local zIndex = index % itemsPerRow
    local tempIndex = math.floor(index / itemsPerRow)
    local xIndex = tempIndex % rowsPerLayer
    local yIndex = math.floor(tempIndex / rowsPerLayer)

    local coordX = baseX + (xIndex * spacingX)
    local coordY = baseY + (yIndex * spacingY)
    local coordZ = baseZ + (zIndex * spacingZ)

    return vec3(coordX, coordY, coordZ)
end

function FetchShells()
    shells = {}
    shellIds = {}
    local dbResults = DB.FetchShells()

    for _, shellData in pairs(dbResults) do
        local coordsJson = json.decode(shellData.coords)
        local coordsVec = vec3(coordsJson.x, coordsJson.y, coordsJson.z)

        table.insert(shellIds, shellData.id)
        shells[shellData.id] = {
            id = shellData.id,
            title = shellData.title,
            user = json.decode(shellData.user or "{}"),
            coords = coordsVec,
            settings = json.decode(shellData.settings),
            builderData = json.decode(shellData.builder_data),
            spawnData = json.decode(shellData.spawn_data),
            thumbnail = shellData.thumbnail,
            createdAt = shellData.created_at,
            updatedAt = shellData.updated_at
        }

        if shellData.id > lastShellId then
            lastShellId = shellData.id
        end
    end

    print("^2Loaded in " .. #shellIds .. " shells. ^3[Shell creator by KuzQuality.com]^0")
    TriggerEvent("kq_shellbuilder:updated")
    syncToGlobalState()
end

local function getShellsExport()
    local exportData = {}
    for id, shell in pairs(shells) do
        local spawnPoint = vec4(0.0, 0.0, 0.0, 0.0)
        if shell.builderData and shell.builderData.spawnPoint then
            local sp = shell.builderData.spawnPoint
            spawnPoint = vec4(sp.x * 2, sp.y * 2, sp.z * 2, sp.w or 0.0)
        end

        exportData[id] = {
            id = shell.id,
            title = shell.title,
            coords = shell.coords,
            spawnPoint = spawnPoint
        }
    end
    return exportData
end

exports("GetShells", getShellsExport)
exports("getShells", getShellsExport)

Citizen.SetTimeout(1200, function()
    FetchShells()
end)